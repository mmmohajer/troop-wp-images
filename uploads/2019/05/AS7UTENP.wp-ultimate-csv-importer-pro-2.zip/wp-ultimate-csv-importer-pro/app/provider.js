import React, {Component} from 'react';
import { AppContext } from './context';
import axios from 'axios';
import { parse } from 'path';
import Cookies from 'universal-cookie';

export class AppProvider extends Component {
    state = {
        selectedTab: '',
        activateMappingSection : false,
        activateDragAndDropSection: false,
        activateXmlFileMappingSection: false,
        wordPressCoreFields: [],
        showWordPressDefaultCoreFieldsState: false,
        acfGroupFields: [],
        showAcfGroupFieldsState: false,
        acfProFields: [],
        showAcfProFieldsState: false,
        acfRepeaterFields: [],
        showAcfRepeaterFieldsState: false,
        termsAndTaxonomiesFields: [],
        showTermsAndTaxonomiesState: false,
        typesFields: [],
        showTypesFieldsState: false,
        podsFields: [],
        showPodsFieldsState: false,
        customFieldSuiteFields: [],
        showCustomFieldSuiteState: false,
        allInOneSeoFields: [],
        showAllInOneSeoFieldsState: false,
        billingAndShippingInformation: [],
        showBillingAndShippingInformationState: false,
        wordPressCustomFields: [],
        wordPressUserCustomFields: [],
        wordPressUserCustomFieldsLabel: [],
        showWordPressCustomFieldsState: false,
        customFieldsWpMembersFields: [],
        showCustomFieldsWpMembersState: false,
        customFieldsMembersFields: [],
        showCustomFieldsMembersState: false,
        productMetaFields: [],
        showProductMetaFieldsState: false,
        wpEcomCustomFields: [],
        showWpEcomCustomFieldsState: false,
        eventsManagerFields: [],
        showEventsManagerFieldsState: false,
        acfFreeFields:[],
        showAcfFreeFieldsState: false,
        cmb2CustomFields: [],
        showCmb2CustomFieldsState: false,
        termsAndTaxonomiesFields: [],
        csvHeaderFields: [],
        fileName: '',
        templateName: '',
        saveTemplateNames: '',
        editTemplateName: '',
        selectedTemplateNameInManagerSection: '',
        selectedModuleNameInManagerSection: '',
        editedTemplateNameInManagerSection: '',
        hashKey: '',
        selectedType: '',
        csvFileNames: [],
        csvFileUrls: [],
        csvFileServer: [],
        selectedFileUrl: '',
        selectedFileServer: '',
        saveSelectedMappedFields: [],
        activateMediaHandlingSection: false,
        activateDashboard: true,
        fromMediaHandlingState: false,
        activateExportDataFilter: false,
        activateExportDownloadOptionSection: false,
        activateImportConfigurationSection: false,
        activateSaveMappingTemplateSection: false,
        activateProgressDisplaySection: false,
        activateUseExistingMappingState: false,
        activateCreateNewMappingState: false,
        activateTemplateSectionState: false,
        fromTemplateMappingSection: false,
        fromDragAndDropSection: false,
        activateLargeState: false,
        mode: 'Insert',
        exportModule: '',
        optionalType: '',
        templateNameArray: [],
        modulesNameArray: [],
        createdTimeArray: [],
        matchedCountsArray: [],
        activateUseAlreadyMediaImageState: false,
        activateOverwriteExistingImageState: false,
        activateThumbnailState: false,
        activateMediumState: false,
        activateMediumLargeState: false,
        activateCustomState: false,
        mediaImageTitle: '',
        mediaImageCaption: '',
        mediaImageAltText: '',
        mediaImageDescription: '',
        mediaImageFileName: '',
        updateFields: [],
        duplicateHandleField: '',
        countryLists: [],
        timeZones: [],
        selectedCountryTime: '',
        receivedExportedFilePath: '',
        importLogDataLink: '',
        rollBackMode: false,
        maintenanceMode: false,
        loaderText: <div className="btn ajax-loader loading">Please Wait</div>,
        totalCustomFields: [],
        totalRows: 0,
        translateLanguage: {},
        uploadedFileType: '',
        
        setSelectedTab: (selectedMenu) => {
            this.setState({selectedTab: selectedMenu})
        },
        setSelectedTabCookies: (selectedCookie) => {
            const cookies = new Cookies();
            cookies.set('selectedTab', selectedCookie, { path: '/' });
            console.log('cookeis', cookies.get('selectedTab'));
        },
        changeActivateMappingSectionState: (newValue) => { 
            console.log('activate mapping');
            this.setState({ activateMappingSection: newValue }) 
        },
        changeActivateDragAndDropSectionState: (dragAndDropState) => {
            this.setState({activateDragAndDropSection: dragAndDropState})
        },
        changeActivateXmlFileMappingSectionState: (xmlFileMappingState) => {
            this.setState({activateXmlFileMappingSection: xmlFileMappingState})
        },
        setWordPressDefaultCoreFields: (responseValue) => {
            this.setState({wordPressCoreFields: responseValue})
        },
        showWordPressDefaultCoreFields: (stateWordPressDefaultCoreFields) => {
            this.setState({showWordPressDefaultCoreFieldsState: stateWordPressDefaultCoreFields})
        },
        setAcfFreeFields: (freeAcfFields) => {
            this.setState({acfFreeFields: freeAcfFields})
        },
        showAcfFreeFields: (stateAcfFreeFields) => {
            this.setState({showAcfFreeFieldsState: stateAcfFreeFields})
        },
        setAcfGroupFields: (groupAcfFields) => {
            this.setState({acfGroupFields: groupAcfFields})
        },
        showAcfGroupFields: (stateAcfGroupFields) => {
            this.setState({showAcfGroupFieldsState: stateAcfGroupFields})
        },
        setAcfProFields: (acfFields) => {
            this.setState({acfProFields: acfFields})
        },
        showAcfProFields: (stateAcfProFields) => {
            this.setState({showAcfProFieldsState: stateAcfProFields})
        },
        setAcfRepeaterFields: (repeaterAcfFields) => {
            this.setState({acfRepeaterFields: repeaterAcfFields})
        },
        showAcfRepeaterFields: (stateAcfRepeaterFieldsState) => {
            this.setState({showAcfRepeaterFieldsState: stateAcfRepeaterFieldsState})
        },
        setTermsAndTaxonomies: (termsAndTaxonomies) => {
            this.setState({termsAndTaxonomiesFields: termsAndTaxonomies})
        },
        showTermsAndTaxonomies: (stateTermsAndTaxonomies) => {
            this.setState({showTermsAndTaxonomiesState: stateTermsAndTaxonomies})
        },
        setTypesFields: (types) => {
            this.setState({typesFields: types})
        },
        showTypesFields: (stateTypesFields) => {
            this.setState({showTypesFieldsState: stateTypesFields})
        },
        setPodsFields: (pods) => {
            this.setState({podsFields: pods})
        },
        showPodsFields: (statePodsFields) => {
            this.setState({showPodsFieldsState: statePodsFields})
        },
        setCustomFieldSuite: (customFieldSuite) => {
            this.setState({customFieldSuiteFields: customFieldSuite})
        },
        showCustomFieldSuite: (stateCustomFieldSuite) => {
            this.setState({showCustomFieldSuiteState: stateCustomFieldSuite})
        },
        setAllInOneSeoFields: (allInOneSeo) => {
            this.setState({allInOneSeoFields: allInOneSeo})
        },
        showAllInOneSeoFields: (stateAllInOneSeoFields) => {
            this.setState({showAllInOneSeoFieldsState: stateAllInOneSeoFields})
        },
        setYoastSeoFields: (yoastSeo) => {
            this.setState({yoastSeoFields: yoastSeo})
        },
        showYoastSeoFields: (stateYoastSeoFields) => {
            this.setState({showYoastSeoFieldsState: stateYoastSeoFields})
        },
        setBillingAndShippingInformation: (billingAndShipping) => {
            this.setState({billingAndShippingInformation: billingAndShipping})
        },
        showBillingAndShippingInformation: (stateBillingAndShippingInformation) => {
            this.setState({showBillingAndShippingInformationState: stateBillingAndShippingInformation})
        },
        setWordPressCustomFields: (receivedWordPressCustomFields) => {
            this.setState({wordPressCustomFields: receivedWordPressCustomFields})
        },
        setWordPressUserCustomFields: (receivedWordPressUserCustomFields) => {
            this.setState({wordPressUserCustomFields: receivedWordPressUserCustomFields})
        },
        setWordPressUserCustomFieldsLabel: (receivedWWordPressUserCustomFieldsLabel) => {
            this.setState({wordPressUserCustomFieldsLabel: receivedWordPressUserCustomFieldsLabel})
        },
        showWordPressCustomFields: (stateWordPressCustomFields) => {
            this.setState({showWordPressCustomFieldsState: stateWordPressCustomFields})
        },
        setCustomFieldsWpMembers: (customFieldsWpMembers) => {
            this.setState({customFieldsWpMembersFields: customFieldsWpMembers})
        },
        showCustomFieldsWpMembers: (stateCustomFieldsWpMembers) => {
            this.setState({showCustomFieldsWpMembersState: stateCustomFieldsWpMembers})
        },
        setCustomFieldsMembers: (customFieldsMembers) => {
            this.setState({customFieldsMembersFields: customFieldsMembers})
        },
        showCustomFieldsMembers: (stateCustomFieldsMembers) => {
            this.setState({showCustomFieldsMembersState: stateCustomFieldsMembers})
        },
        setProductMetaFields: (productMeta) => {
            this.setState({productMetaFields: productMeta})
        },
        showProductMetaFields: (stateProductMetaFields) => {
            this.setState({showProductMetaFieldsState: stateProductMetaFields})
        },
        setWpEcomCustomFields: (wpEcomCustom) => {
            this.setState({wpEcomCustomFields: wpEcomCustom})
        },
        showWpEcomCustomFields: (stateWpEcomCustomFields) => {
            this.setState({showWpEcomCustomFieldsState: stateWpEcomCustomFields})
        },
        setEventsManagerFields: (eventsManager) => {
            this.setState({eventsManagerFields: eventsManager})
        },
        showEventsManagerFields: (stateEventsManagerFields) => {
            this.setState({showEventsManagerFieldsState: stateEventsManagerFields})
        },
        setNextgenGalleryFields: (nextgenGallery) => {
            this.setState({nextgenGalleryFields: nextgenGallery})
        },
        showNextgenGalleryFields: (stateNextgenGalleryFields) => {
            this.setState({showNextgenGalleryFieldsState: stateNextgenGalleryFields})
        },
        setCmb2CustomFields: (cmb2Fields) => {
            this.setState({cmb2CustomFields: cmb2Fields})
        },
        showCmb2CustomFields: (cmb2CustomFields) => {
            this.setState({showCmb2CustomFieldsState: cmb2CustomFields})
        },
        setCsvHeaderFields: (csvValue) => {
            this.setState({csvHeaderFields: csvValue})
        },
        getFileName: (file) => {
            this.setState({fileName: file});
        },
        getTemplateName: (file) => {
            this.setState({templateName: file})
        },
        saveTemplateName: (file) => {
            this.setState({saveTemplateNames: file})
        },
        editedTemplateName: (file) => {
            this.setState({editTemplateName: file})
        },
        selectedTemplateInManager: (templateNameInManager) => {
            this.setState({selectedTemplateNameInManagerSection: templateNameInManager})
        },
        selectedEditedTemplateInManager: (editedTemplateNameInManager) => {
            this.setState({editedTemplateNameInManagerSection: editedTemplateNameInManager})
        },
        selectedModuleInManager: (moduleNameInManager) => {
            this.setState({selectedModuleNameInManagerSection: moduleNameInManager})
        },
        setHashKey: (receivedHashKey) => {
            this.setState({hashKey: receivedHashKey})
        },
        setSelectedType: (receivedSelectedType) => {
            this.setState({selectedType: receivedSelectedType})
        },
        setMode: (receivedMode) => {
            this.setState({mode: receivedMode})
        }, 
        getCsvFileNames: (fileNames) => {
            this.setState({csvFileNames: fileNames})
        }, 
        getCsvFilesUrl: (fileUrls) =>  {
            this.setState({csvFileUrls: fileUrls})   
        },
        getCsvFilesServer: (fileServer) =>  {
            this.setState({csvFileServer: fileServer})   
        },
        setSelectedFileUrl: (fileUrl) => {
            this.setState({selectedFileUrl: fileUrl})
        },
        setSelectedFileServer: (fileServerone) => {
            this.setState({selectedFileServer: fileServerone})
        }, 
        saveMappedFields: (savedMappedFields) => {
            this.setState({saveSelectedMappedFields: savedMappedFields.slice() });
        },
        changeActivateMediaHandlingSection: (activateMediaHandling) => {
            this.setState({activateMediaHandlingSection: activateMediaHandling})
        },
        setActivateDashboard: (setDashboard) => {
            this.setState({activateDashboard: setDashboard })
        },
        backFromMediaHandlingState: (mediaHandlingState) => {
             this.setState({fromMediaHandlingState: mediaHandlingState})
        },
        setExportDataFilterSection: (setExportDataFilter) => {
            this.setState({activateExportDataFilter: setExportDataFilter})
        },
        changeActivateExportDownloadOption: (activateExportDownloadOption) => {
            this.setState({activateExportDownloadOptionSection: activateExportDownloadOption})
        },
        changeActivateImportConfiguration: (activateImportConfiguration) => {
          this.setState({activateImportConfigurationSection: activateImportConfiguration})  
        },
        changeActivateProgressDisplay: (activateProgressDisplay) => {
            this.setState({activateProgressDisplaySection: activateProgressDisplay})
        },
        changeActivateSaveMappingTemplateSectionState: (activateSaveMappingTemplate) => {
            this.setState({activateSaveMappingTemplateSection: activateSaveMappingTemplate})
        },
        changeUseExistingMappingState: (useExistingMapping) => {
            this.setState({activateUseExistingMappingState: useExistingMapping})
        },
        changeCreateNewMappingState: (createNewMapping) => {
            this.setState({activateCreateNewMappingState: createNewMapping})
        },
        changeActivateTemplateSectionState: (templateSectionState) => {
            this.setState({activateTemplateSectionState: templateSectionState})
        },
        fromTemplateMappingSectionState: (fromTemplateMapping) => {
            this.setState({fromTemplateMappingSection : fromTemplateMapping})
        }, 
        fromDragAndDropMappingSection: (fromDragAndDrop) => {
            this.setState({fromDragAndDropSection : fromDragAndDrop})
        },
        setMode: (setModeInsert) => {
            this.setState({mode: setModeInsert})
        },
        setExportModule: (setModule) => {
            this.setState({exportModule: setModule})
        },
        setOptionalType: (setType) => {
            this.setState({optionalType: setType})
        },
        setTemplateNameArray: (templateNames) => {
            this.setState({templateNameArray: templateNames})
        },
        setModulesArray: (modulesName) => {
            this.setState({modulesNameArray: modulesName})
        },
        setCreatedTimeArray: (createdTime) => {
            this.setState({createdTimeArray: createdTime})
        },
        setMatchedCounts: (matchedCounts) => {
            this.setState({matchedCountsArray: matchedCounts})
        },
        activateUseAlreadyMediaImage: (useAlreadyMediaImage) => {
            this.setState({activateUseAlreadyMediaImageState: useAlreadyMediaImage})
        },
        activateOverwriteExistingImage: (overwriteExistingImage) => {
            this.setState({activateOverwriteExistingImageState: overwriteExistingImage})
        },
        activateThumbnail: (thumbnail) => {
            this.setState({activateThumbnailState: thumbnail})
        },
        activateMedium: (medium) => {
            this.setState({activateMediumState: medium})
        },
        activateMediumLarge: (mediumlarge) => {
            this.setState({activateMediumLargeState: mediumlarge})
        },
        activateLarge: (large) => {
            this.setState({activateLargeState: large})
        },
        activateCustom: (custom) => {
            this.setState({activateCustomState: custom})
        },
        setImageTitle: (imageTitle) => {
            this.setState({mediaImageTitle: imageTitle})
        },
        setImageCaption: (imageCaption) => {
            this.setState({mediaImageCaption: imageCaption})
        },
        setImageAltText: (imageAltText) => {
            this.setState({mediaImageAltText: imageAltText})
        },
        setImageDescription: (imageDescription) => {
            this.setState({mediaImageDescription: imageDescription})
        },
        changeImageFileName: (imageFileName) => {
            this.setState({mediaImageFileName: imageFileName})
        },
        setUpdateFields: (updateField) => {
            this.setState({updateFields: updateField})
        },
        fieldHandleDuplicate: (handleDuplicate) => {
            this.setState({duplicateHandleField: handleDuplicate})
        },
        setCountryList: (countryList) => {
            this.setState({countryLists: countryList})
        },
        setTimeZones: (timeZone) => {
            this.setState({timeZones: timeZone})
        },
        selectedCountryTimeZone: (countryTimeZone) => {
            this.setState({selectedCountryTime: countryTimeZone})
        },
        exportedFileUrl: (fileUrl) => {
            this.setState({receivedExportedFileUrl: fileUrl})
        },
        importLogData: (logData) => {
            this.setState({importLogDataLink:logData})
        },
        setRollBackMode: (value) => {
            this.setState({rollBackMode:value})
        },
        setMaintenanceMode: (mode) => {
            this.setState({maintenanceMode:mode})
        },
        setTotalCustomFields: (customFieldsTotal) => {
            this.setState({totalCustomFields: customFieldsTotal})
        },
        setTotalRows: (rowsTotal) => {
            this.setState({totalRows: rowsTotal})
        },
        languageTranslation: (language) => {
            this.setState({translateLanguage: language})
        },
        uploadFileType: (fileType) => {
            this.setState({uploadedFileType: fileType})
        },
        // this.context.getUtcTimeZones.blind(this.context)()
        // async getUtcTimeZones () {
        //     var formData = new FormData();
        //     formData.set('action','timezone');
    
        //     // this.setState({
        //     //     loading : true, });
    
        //     const response = await axios({
        //         method: 'post',
        //         url: ajaxurl,
        //         data: formData,
        //         config: { headers: {'Content-Type': 'multipart/form-data' }}
        //     });
    
        //     if (response.status == 200)	{
        //         // this.setState({
        //         //     loading : false, });
        //         console.log(response);
        //         // this.context.setCountryList(response.data.offset);
        //         // this.context.setTimeZones(response.data.timezone);

        //         console.log("checking",this)

        //         this.setState({
        //             countryLists:response.data.offset,
        //             timeZones:response.data.timezone
        //         })
        //     }
        // },
    }

    render() {
        return <AppContext.Provider value={this.state} >{this.props.children}</AppContext.Provider>
    }

}