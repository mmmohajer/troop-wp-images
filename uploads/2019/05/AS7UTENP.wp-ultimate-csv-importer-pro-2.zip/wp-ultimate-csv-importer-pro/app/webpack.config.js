const path = require('path');

module.exports = (env, argv) => {
  let production = argv.mode === 'production'

  return {
    watch: true,
    entry: {
      'js/admin': path.resolve(__dirname, 'admin.js')
    },

    output: {
      filename: '[name].js',
      path: path.resolve(__dirname, '../assets'),
    },

    optimization: {
        splitChunks: {
          chunks: 'all',
        },
    },

    devtool: production ? '' : 'source-map',
  
    resolve: {
      extensions: [".js", ".jsx", ".json"],
    },
  
    module: {
      rules: [
        {
          test: /\.jsx?$/,
          exclude: /node_modules/,
          loader: 'babel-loader',
        },
        {
          test: /\.css$/,
        use: [
          { loader: 'style-loader' },
          {
            loader: 'css-loader',
            options: {
              modules: true
            }
          }
        ]
      }
      ],
    },
  };
}
