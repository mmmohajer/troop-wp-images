import React, { Component } from 'react';
import {AppContext} from '../../../context.js'
import DatePicker from "react-datepicker";
import { toast } from 'react-toastify';
import axios from 'axios';

import "react-datepicker/dist/react-datepicker.css";


var moment = require('moment');


class ImportConfiguration extends Component {
    static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
            selectedDate: new Date(),
            loading: false,
            display: "none",
            displayRollback: "block",
            displayMaintenance: "block",
            displayDuplicateRecords: "none",
            displayExistingRecords: "none",
            displayDuplicateRecordsBlock : "none",
            displayExistingRecordsBlock : "none",
            displaySchedule: "none",
            block: "block",
            none: "none",
            block1: "block",
            none1: "none",
            scheduleFrequency: "OneTime",
            scheduleTime: '',           
            enableMaintenanceMode: ''
        }
        this.handleChange = this.handleChange.bind(this);
        this.updateFields = [];
    }

    componentDidMount() {
        this.context.setSelectedTabCookies("import-update");
        (this.context.mode === "Update") ? this.setState({displayExistingRecordsBlock: "block", displayExistingRecords: "block"}) : this.setState({displayDuplicateRecordsBlock: "block"})
        this.updateFieldsConfiguration();
        this.getUtcTimeZones();
    }

    handleChange(date) {
        this.setState({
          selectedDate: date
        });
    }

    async updateFieldsConfiguration() {
        var formData = new FormData();
        formData.set('action','updatefields');
        formData.set('Types', this.context.selectedType);
        formData.set('Mode', this.context.mode);
        
        this.setState({
            loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        if (response.status == 200)	{
            this.setState({
                loading : false, });
            console.log(response);
            // for(var i=0; i<response.data.update_fields.length; i++) {
            //     this.updateFields.push(response.data.update_fields[i]);
            // }    
            this.context.setUpdateFields(response.data.update_fields);
            //this.context.fieldHandleDuplicate(response.data.update_fields[0]);
        }
    }

    async getUtcTimeZones() {
        var formData = new FormData();
        formData.set('action','timezone');

        this.setState({
            loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        if (response.status == 200)	{
            this.setState({
                loading : false, });
            console.log(response);
            this.context.setCountryList(response.data.offset);
            this.context.setTimeZones(response.data.timezone);
        }
    }

    async scheduleConfiguration() {
        console.log(this.context.selectedType);
        var formData = new FormData();
        console.log(this.context.selectedCountryTime);
        formData.set('action','save_schedule_info');
        formData.set('file_name', this.context.fileName);
        formData.set('file_type','csv');
        formData.set('method','desktop');
        formData.set('module',this.context.selectedType);
        formData.set('date', moment(this.state.selectedDate).format('MM/DD/YYYY'));
        formData.set('time', this.state.scheduleTime);
        formData.set('frequency',this.state.scheduleFrequency);
        formData.set('eventkey', this.context.hashKey);
        formData.set('duplicate_header', this.context.duplicateHandleField);
        formData.set('UTC', this.context.selectedCountryTime);
                
        this.setState({
            loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        }); 

        if (response.status == 200)	{
            this.setState({
                loading : false, });
            
            console.log(response.data);
            toast.success(response.data.notification)
            this.context.changeActivateImportConfiguration(false);
            this.context.setSelectedTab('import-update');
            this.context.setActivateDashboard(true);
            if(response.data.success) {
                
                
            }
        }
    }

    async importConfiguration() {
        var formData = new FormData();
        formData.set('action','StartImport');

        var rollBack = "";

        (this.context.rollBackMode) ? rollBack = "true" : rollBack = "false";
        // formData.set('use_ExistingImage',this.context.activateUseAlreadyMediaImageState);
        // formData.set('overwriteImage', this.context.activateOverwriteExistingImageState);
        // formData.set('thumbnail', this.context.activateThumbnailState);
        // formData.set('medium', this.context.activateMediumState);
        // formData.set('medium_large', this.context.activateMediumLargeState);
        // formData.set('large', this.context.activateLargeState);
        // formData.set('title', this.context.mediaImageTitle);
        // formData.set('caption', this.context.mediaImageCaption);
        // formData.set('alttext', this.context.mediaImageAltText);
        // formData.set('description', this.context.mediaImageDescription);
        // formData.set('imagename', this.context.mediaImageFileName);
        formData.set('HashKey', this.context.hashKey);
        formData.set('Check', this.context.duplicateHandleField);
        formData.set('RollBack', rollBack);

        // this.setState({
        //     loading : true, });

        const response = await axios({
                method: 'post',
                url: ajaxurl,
                data: formData,
                config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        if (response.status == 200)	{
            console.log(response.data);             
            if(response.data.success) {
                this.context.importLogData(response.data.log_link)
             }
        }
    }

    async sMaintenanceMode(status){
        console.log(status)
        var formData = new FormData();
        formData.set('action','settings_options');
        formData.set('option', "enable_main_mode");
        formData.set('value', status);        
            
        const response = await axios({
                method: 'post',
                url: ajaxurl,
                data: formData,
                config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response)

        this.context.setMaintenanceMode(status)
        
    }

    render() {
        return(
        <div id="import-configuration">
                <div className="card csv-importer-panel mt20 pt30 pb30">
                    {/* <!-- Wordpress Fields Starts--> */}

                    <div className="row export">
                        <h1 className="main-heading pr15 pl15 mb20 col-md-12">{this.context.translateLanguage.ImportconfigurationSection}</h1>
                        <div className="advanced-filter col-md-12" style={{display: "" + this.state.displayRollback}}>
                            <label>
                                <input type="checkbox"  checked={this.context.rollBackMode} onClick={(event)=>{this.context.setRollBackMode(event.target.checked);}} />
                                {this.context.translateLanguage.EnablesafeprestateRollback} <b> ({this.context.translateLanguage.Backupbeforeimport})</b>
                            </label>
                        </div>
                        <div className="advanced-filter col-md-12" style={{display: "" + this.state.displayMaintenance}}>
                            <label>
                                <input type="checkbox" checked={this.context.maintenanceMode} onClick={(event)=>{ this.sMaintenanceMode(event.target.checked)} }/>
                                {this.context.translateLanguage.DoyouwanttoSWITCHONMaintenancemodewhileimport} ?
                            </label>
                        </div>
                        {((this.context.selectedType !== "Users") && (this.context.mode === "Insert")) ? 
                        <div className="advanced-filter col-md-12" style={{display: "" + this.state.displayDuplicateRecordsBlock}}>
                            <label>
                                <input type="checkbox" class="" id="checkbox3" onClick={(event)=>{var checkBox = document.getElementById("checkbox3"); if(checkBox.checked){this.setState({displayDuplicateRecords: "block"})} else{this.setState({displayDuplicateRecords: "none"})}}} />
                                {this.context.translateLanguage.Doyouwanttohandletheduplicateonexistingrecords} ?
                            </label>
                            <div className="row mt20 col-md-6" style={{display: "" + this.state.displayDuplicateRecords}}>
                                
                                <div className="form-group col">
                                    <label for="">{this.context.translateLanguage.Mentionthefieldswhichyouwanttohandleduplicates} </label>
                                    <select className="select form-control" name="" id="" onChange={(event)=>{this.context.fieldHandleDuplicate(event.target.value)}}>
                                    <option value ="">--select--</option>
                                    {this.context.updateFields.map((fields, index) => {
                                        return <option value={fields}>{fields}</option>
                                    })}
                                    </select>
                                </div>
                            </div>
                        </div>
                        : ((this.context.selectedType !== "Users") && (this.context.mode === 'Update')) ?
                        <div className="advanced-filter col-md-12" style={{display: "" + this.state.displayExistingRecordsBlock}}>
                            <label>
                                <input type="checkbox" class="" id="checkbox5" checked={((this.context.mode === 'Update') && (this.state.displayExistingRecords === "block")) ? true : false}  onClick={(event)=>{var checkBox = document.getElementById("checkbox5"); if(checkBox.checked){this.setState({displayExistingRecords: "block"});} else{this.setState({displayExistingRecords: "none"})} if(event.target.checked){this.setState({displayExistingRecords: "block"});} else{this.setState({displayExistingRecords: "none"})}}} />
                                {this.context.translateLanguage.DoyouwanttoUpdateanexistingrecords} ?
                            </label>
                            <div className="row mt20 col-md-6" style={{display: "" + this.state.displayExistingRecords}}>
                                
                                <div className="form-group col">
                                    <label for="">"{this.context.translateLanguage.Updaterecordsbasedon}"</label>
                                    <select className="select form-control" name="" id="" onChange={(event)=>{this.context.fieldHandleDuplicate(event.target.value)}}>
                                    <option value ="">--select--</option>
                                    {this.context.updateFields.map((fields, index) => {
                                        return <option value={fields}>{fields}</option>
                                    })}
                                    </select>
                                </div>
                            </div>
                        </div>
                        :  "" }
                        <div className="advanced-filter col-md-12">
                            <label>
                                <input type="checkbox" class="" id="checkbox4" onClick={(event)=>{var checkBox = document.getElementById("checkbox4"); if(checkBox.checked){this.setState({displaySchedule: "block", displayMaintenance: "none", displayRollback: "none"})} else{this.setState({displaySchedule: "none", displayMaintenance: "block", displayRollback: "block"})}}} />
                                {this.context.translateLanguage.DoyouwanttoSchedulethisImport} ?
                            </label>
                            <div className="mt20 col-md-12" style={{display: "" + this.state.displaySchedule}}>
                                <div className="row">
                                
                                    <div className="form-group col-md-4">
                                        <label for="">{this.context.translateLanguage.ScheduleDate}</label>
                                        {/* <input type="text" data-type="date" name="" className="form-control" /> */}
                                        <DatePicker className="form-control" selected={this.state.selectedDate} onChange={this.handleChange} />
                                        <i className="csv-icon-calendar2 input-icon"></i>
                                    </div>
                                    <div className="form-group col-md-4">
                                        <label for="">{this.context.translateLanguage.ScheduleFrequency}</label>
                                        <select className="select form-control" name="" id="" onChange={(event)=>{this.setState({scheduleFrequency: event.target.value})}} >
                                                <option value="OneTime">{this.context.translateLanguage.OneTime}</option>
                                                <option value="Daily">{this.context.translateLanguage.Daily}</option>
                                                <option value="Weekly">{this.context.translateLanguage.Weekly}</option>
                                                <option value="Monthly">{this.context.translateLanguage.Monthly}</option>
                                                <option value="Hourly">{this.context.translateLanguage.Hourly}</option>
                                                <option value="Every 30 mins">{this.context.translateLanguage.Every30mins}</option>
                                                <option value="Every 15 mins">{this.context.translateLanguage.Every15mins}</option>
                                                <option value="Every 10 mins">{this.context.translateLanguage.Every10mins}</option>
                                                <option value="Every 5 mins">{this.context.translateLanguage.Every5mins}</option>
                                        </select>
                                    </div>
                                    <div className="form-group col-md-4">
                                        <label for="">{this.context.translateLanguage.TimeZone}</label>
                                        <select className="select form-control" name="" id="" onChange={(event)=>{this.context.selectedCountryTimeZone(event.target.value)}} >
                                        {this.context.countryLists.map((timezones, index) => {
                                            return <option value={this.context.timeZones[index]}>{timezones}</option>
                                        })}
                                        </select>

                                                                                       
                                                    {/* <SelectTimezone /> */}
                                    </div>
                                    <div className="form-group col-md-4">
                                        <label for="">{this.context.translateLanguage.ScheduleTime}</label>
                                        {/* <TimezonePicker
                                                value="Asia/Yerevan"
                                                onChange={timezone => console.log('New Timezone Selected:', timezone) }
                                                inputProps={{
                                                    placeholder: 'Select Timezone...',
                                                    name: 'timezone',
                                                    label: 'name',
                                                    offset: 'offset'
                                            }} 
                                        /> */}
                                        {/* http://react-component.github.io/time-picker/examples/12hours.html */}
                                        <input type="text" name="" className="form-control" onChange={(event)=>{this.setState({scheduleTime: event.target.value})}}/> 
                                        <small className="form-text text-muted">{this.context.translateLanguage.Format} : 21: 30</small>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                         <div className="form-group col-md-12 mt30">
                            <div className="float-left">
                                <button type="button" className="smack-btn btn-default" onClick={(event)=>{this.context.changeActivateImportConfiguration(false); this.context.changeActivateMappingSectionState(false); this.context.changeActivateMediaHandlingSection(true); this.context.setActivateDashboard(false);}}>{this.context.translateLanguage.Back}</button>
                            </div>
                            <div class="float-right">
                            {(this.state.loading) ? 
                                this.context.loaderText
                                :
                                <React.Fragment>
                                <button type="button" className="smack-btn smack-btn-primary" style={{display: "" + this.state.displaySchedule}} onClick={(event)=>{this.scheduleConfiguration();}}>{this.context.translateLanguage.Schedule}</button>
                                <button type="button" className="smack-btn smack-btn-primary" style={{display: "" + this.state.displayRollback}} onClick={(event)=>{this.importConfiguration(); this.context.changeActivateProgressDisplay(true); this.context.changeActivateImportConfiguration(false); this.context.changeActivateMappingSectionState(false); this.context.changeActivateMediaHandlingSection(false); this.context.setActivateDashboard(false);}} >{this.context.translateLanguage.Import}</button>
                                </React.Fragment>
                                }
                                
                            </div>
                        </div>
                    </div>

                </div> 
                {/* <!-- Wordpress Fields End--> */}

            </div>
        


        )

    }



}

export default ImportConfiguration;
