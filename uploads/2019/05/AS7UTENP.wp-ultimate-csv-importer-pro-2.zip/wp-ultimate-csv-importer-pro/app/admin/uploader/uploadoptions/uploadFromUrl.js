import React, { Component } from 'react';
import axios from 'axios';
import {AppContext} from '../../../context.js'

class UploadFromUrl extends Component {
	static contextType = AppContext;
	static csvFilesName = [];
	static csvFilesUrl = [];

    constructor(props) {
		super(props);
		this.state = {
			fileUrl: '',
			loading: false,
			postType: [],
			taxonomy: [],
			showImportRecord: false,
			newItem:true,
			existingItem:false,
			showUploadUrlSection: true,
			showUploadModal: false,
			file_name:'',
			file_size: ''
		}		
	}

	componentDidMount() {
		this.context.setSelectedTabCookies("import-update");
	}
	
async sendFileUrl() {
	var formData = new FormData();
    formData.set('action','get_csv_url');
		formData.set('url',(this.state.showUploadModal) ? this.context.selectedFileUrl  : this.state.fileUrl);
	
	this.setState({
		loading : true, })
		
	const response = await axios({
		method: 'post',
		url: ajaxurl,
		data: formData,
		config: { headers: {'Content-Type': 'multipart/form-data' }}
	});

	if (response.status == 200)	{
		console.log(response.data);
		
		if(response.data.success) {
			this.setState({
				loading : false, })
			if(response.data.file_type === 'csv') {
				document.getElementById('csv-url-modal-close').click();
					this.context.setHashKey(response.data.hashkey);
					this.context.setSelectedType(response.data.selectedtype);
					this.setState({postType: response.data.posttype});
					this.setState({
						file_name:response.data.filename,
						file_size:response.data.file_size
				})
					this.setState({taxonomy: response.data.taxonomy});
					this.setState({showImportRecord: true, showUploadUrlSection: false });
			}
			if(response.data.file_type === 'xml') {
				document.getElementById('csv-url-modal-close').click();
					this.context.setHashKey(response.data.hashkey);
					this.context.setSelectedType(response.data.selectedtype);
					this.setState({postType: response.data.posttype});
					this.setState({
						file_name:response.data.filename,
						file_size:response.data.file_size
				});
				if (response.data.file_type === "xml") {
					this.context.uploadFileType("xml");
				}
					this.setState({taxonomy: response.data.taxonomy});
					this.setState({showImportRecord: true, showUploadUrlSection: false });
			}
			if(response.data.file_type === 'zip') {
				document.getElementById('csv-url-modal').click();
					UploadFromUrl.csvFilesName = [];
					UploadFromUrl.csvFilesUrl = [];
						for(var i=0; i<response.data.info.length; i++) {
								UploadFromUrl.csvFilesName.push(response.data.info[i].name);
								UploadFromUrl.csvFilesUrl.push(response.data.info[i].path);
						}
						this.setState({
							file_name:response.data.filename,							
					})
						this.context.getCsvFileNames(UploadFromUrl.csvFilesName);
						this.context.getCsvFilesUrl(UploadFromUrl.csvFilesUrl);
						this.setState({showUploadModal: true, showImportRecord: false, showUploadUrlSection: true});
						console.log(this.context.csvFileNames);
						console.log(this.context.csvFileUrls);
			}
			
		}
	} 
}

getAcfFreeFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if(fields[i]['acf_fields'] != undefined && fields[i]['acf_fields'] != null) {
			return fields[i].acf_fields;
		}
	}
}

getAcfGroupFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['acf_group_fields'] != undefined && fields[i]['acf_group_fields'] != null) {
			return fields[i].acf_group_fields;
		}
	}
}

getAcfProFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['acf_pro_fields'] != undefined && fields[i]['acf_pro_fields'] != null) {
			return fields[i].acf_pro_fields;
		}
	}

}

getAcfRepeaterFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['acf_repeater_fields'] != undefined && fields[i]['acf_repeater_fields'] != null) {
			return fields[i].acf_repeater_fields;
		}
	}

}

getWordPressDefaultCoreFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['core_fields'] != undefined && fields[i]['core_fields'] != null) {
			return fields[i].core_fields;
		}
	}
}

getTermsAndTaxonomies(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['terms_and_taxonomies'] != undefined && fields[i]['terms_and_taxonomies'] != null) {
			return fields[i].terms_and_taxonomies
		}
	}
}

getTypesFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['types_fields'] != undefined && fields[i]['types_fields'] != null) {
			return fields[i].types_fields
		}
	}
}

getPodsFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['pods_fields'] != undefined && fields[i]['pods_fields'] != null) {
			return fields[i].pods_fields
		}
	}
}

getCustomFieldSuite(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['custom_fields_suite_fields'] != undefined && fields[i]['custom_fields_suite_fields'] != null) {
			return fields[i].custom_fields_suite_fields
		}
	}
}

getAllInOneSeoFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['all_in_one_seo_fields'] != undefined && fields[i]['all_in_one_seo_fields'] != null) {
			return fields[i].all_in_one_seo_fields
		}
	}
}

getYoastSeoFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['yoast_seo_fields'] != undefined && fields[i]['yoast_seo_fields'] != null) {
			return fields[i].yoast_seo_fields
		}
	}
}

getBillingAndShippingInformation(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['billing_and_shipping_information'] != undefined && fields[i]['billing_and_shipping_information'] != null) {
			return fields[i].billing_and_shipping_information
		}
	}
}

getWordPressCustomFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['wordpress_custom_fields'] != undefined && fields[i]['wordpress_custom_fields'] != null) {
			return fields[i].wordpress_custom_fields
		}
	}
}

getProductMetaFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['product_meta_fields'] != undefined && fields[i]['product_meta_fields'] != null) {
			return fields[i].product_meta_fields
		}
	}
}

getCsvHeaderFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['csv_fields'] != undefined && fields[i]['csv_fields'] != null) {
			return fields[i].csv_fields
		}
	}
}

getCustomFieldsWpMembers(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['custom_fields_wp_members'] != undefined && fields[i]['custom_fields_wp_members'] != null) {
			return fields[i].custom_fields_wp_members
		}
	}
}

getCustomFieldsMembers(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['custom_fields_members'] != undefined && fields[i]['custom_fields_members'] != null) {
			return fields[i].custom_fields_members
		}
	}
}

getWpEcomCustomFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['wp_ecom_custom_fields'] != undefined && fields[i]['wp_ecom_custom_fields'] != null) {
			return fields[i].wp_ecom_custom_fields
		}
	}
}

getEventsManagerFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['events_manager_fields'] != undefined && fields[i]['events_manager_fields'] != null) {
			return fields[i].events_manager_fields
		}
	}
}

getNextgenGalleryFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['nextgen_gallery_fields'] != undefined && fields[i]['nextgen_gallery_fields'] != null) {
			return fields[i].nextgen_gallery_fields
		}
	}
}

getCmb2CustomFields(fields) {
	for(var i=0; i<fields.length; i++) {
		if (fields[i]['cmb2_fields'] != undefined && fields[i]['cmb2_fields'] != null) {
			return fields[i].cmb2_fields
		}
	}
}

async sendConfiguration() {
	var formData = new FormData();
	formData.set('action','mappingfields');
	formData.set('HashKey',this.context.hashKey);
	formData.set('Types', this.context.selectedType);
	formData.set('Mode', this.context.mode);
	
	this.setState({
		loading : true, });
		
	const response = await axios({
		method: 'post',
		url: ajaxurl,
		data: formData,
		config: { headers: {'Content-Type': 'multipart/form-data' }}
	});

	if (response.status == 200)	{
		if(response.data.success) {
			console.log(response.data);
			this.setState({ showImportRecord:false });
			if(response.data.show_template === true) {
					for(var i=0; i<response.data.info.length; i++)
					{
						this.templateName.push(response.data.info[i].template_name);
						this.module.push(response.data.info[i].module);
						this.createdTime.push(response.data.info[i].created_time);
						this.matchedCounts.push(response.data.info[i].count);
					}
					this.context.setTemplateNameArray(this.templateName);
					this.context.setModulesArray(this.module);
					this.context.setCreatedTimeArray(this.createdTime);
					this.context.setMatchedCounts(this.matchedCounts);
					this.context.setCsvHeaderFields(response.data.csv_fields);
					this.context.changeActivateSaveMappingTemplateSectionState(true);
					this.context.setActivateDashboard(false);
			}
			else {
				var acf_fields = this.getAcfFreeFields(response.data.fields);
				if(acf_fields != undefined) {
					this.context.showAcfFreeFields(true);
					this.context.setAcfFreeFields(acf_fields);
				}
				var acf_group_fields = this.getAcfGroupFields(response.data.fields);
				if (acf_group_fields  != undefined) {
					this.context.showAcfGroupFields(true);
					this.context.setAcfGroupFields(acf_group_fields);
				}

				var acf_pro_fields = this.getAcfProFields(response.data.fields);
				if (acf_pro_fields != undefined) {
					this.context.showAcfProFields(true);
					this.context.setAcfProFields(acf_pro_fields);
				}

				var acf_repeater_fields = this.getAcfRepeaterFields(response.data.fields);
				if (acf_repeater_fields != undefined) {
					this.context.showAcfRepeaterFields(true);
					this.context.setAcfRepeaterFields(acf_repeater_fields);
				}

				var wordpress_default_corefields= this.getWordPressDefaultCoreFields(response.data.fields);
				if (wordpress_default_corefields != undefined) {
					this.context.showWordPressDefaultCoreFields(true);
					this.context.setWordPressDefaultCoreFields(wordpress_default_corefields);
				}
				
				var terms_and_taxonomies = this.getTermsAndTaxonomies(response.data.fields);
				if (terms_and_taxonomies != undefined) {
					this.context.showTermsAndTaxonomies(true);
					this.context.setTermsAndTaxonomies(terms_and_taxonomies);
				}

				var types_fields = this.getTypesFields(response.data.fields);
				if (types_fields != undefined) {
					this.context.showTypesFields(true);
					this.context.setTypesFields(types_fields);
				}

				var pods_fields = this.getPodsFields(response.data.fields);
				if (pods_fields != undefined) {
					this.context.showPodsFields(true);
					this.context.setPodsFields(pods_fields);
				}

				var custom_fields_suite_fields = this.getCustomFieldSuite(response.data.fields);
				if (custom_fields_suite_fields != undefined) {
					this.context.showCustomFieldSuite(true);
					this.context.setCustomFieldSuite(custom_fields_suite_fields);
				}

				var all_in_one_seo_fields = this.getAllInOneSeoFields(response.data.fields);
				if (all_in_one_seo_fields != undefined) {
					this.context.showAllInOneSeoFields(true);
					this.context.setAllInOneSeoFields(all_in_one_seo_fields)
				}

				var yoast_seo_fields = this.getYoastSeoFields(response.data.fields);
				if (yoast_seo_fields != undefined) {
					this.context.showYoastSeoFields(true);
					this.context.setYoastSeoFields(yoast_seo_fields)
				}

				var billing_and_shipping_information = this.getBillingAndShippingInformation(response.data.fields);
				if (billing_and_shipping_information != undefined) {
					this.context.showBillingAndShippingInformation(true);
					this.context.setBillingAndShippingInformation(billing_and_shipping_information);
				}
				
				var wordpress_custom_fields = this.getWordPressCustomFields(response.data.fields);
				if (wordpress_custom_fields != undefined) {
					this.context.showWordPressCustomFields(true);
					this.context.setWordPressCustomFields(wordpress_custom_fields);
				}
				if (wordpress_custom_fields == undefined) {
					this.context.showWordPressCustomFields(true);
					this.context.setWordPressCustomFields(wordpress_custom_fields);
				}

				var product_meta_fields = this.getProductMetaFields(response.data.fields);
				if (product_meta_fields != undefined) {
						this.context.showProductMetaFields(true);
						this.context.setProductMetaFields(product_meta_fields);
				}

				var custom_fields_wp_members = this.getCustomFieldsWpMembers(response.data.fields);
				if (custom_fields_wp_members != undefined) {
						this.context.showCustomFieldsWpMembers(true);
						this.context.setCustomFieldsWpMembers(custom_fields_wp_members);
				}

				var custom_fields_members = this.getCustomFieldsMembers(response.data.fields);
				if (custom_fields_members != undefined) {
						this.context.showCustomFieldsMembers(true);
						this.context.setCustomFieldsMembers(custom_fields_members);
				}

				var wp_ecom_custom_fields = this.getWpEcomCustomFields(response.data.fields);
				if(wp_ecom_custom_fields != undefined) {
						this.context.showWpEcomCustomFields(true);
						this.context.setWpEcomCustomFields(wp_ecom_custom_fields);
				}

				var events_manager_fields = this.getEventsManagerFields(response.data.fields);
				if(events_manager_fields != undefined) {
						this.context.showEventsManagerFields(true);
						this.context.setEventsManagerFields(events_manager_fields);
				}

				var nextgen_gallery_fields = this.getNextgenGalleryFields(response.data.fields);
				if(nextgen_gallery_fields != undefined) {
						this.context.showNextgenGalleryFields(true);
						this.context.setNextgenGalleryFields(nextgen_gallery_fields);
				}

				var cmb2_fields = this.getCmb2CustomFields(response.data.fields);
				if(cmb2_fields != undefined) {
						this.context.showCmb2CustomFields(true);
						this.context.setCmb2CustomFields(cmb2_fields);
				}
				
				this.context.setCsvHeaderFields(response.data.csv_fields);
			if(this.context.uploadedFileType === 'xml') {
					this.context.changeActivateXmlFileMappingSectionState(true);
			}
			else{
			this.context.changeActivateMappingSectionState(true);
			}
				this.context.setActivateDashboard(false);
		}
	} 
}
}

render() {
	console.log('file url' + ajaxurl);

	const loaderPosition = {
		position: "absolute",
		right: '150px'
	}
    return(
        <div className="col-md-9">
				{(this.state.showUploadUrlSection) ?
					<div className="tab-content" id="v-pills-tabContent">
						<div className="tab-pane fade show active" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
							<div className="row mt30">
								<div className="form-group col-md-12">
									<label for="file-path">File Path</label>
									<input type="text" className="form-control" onChange={(event)=>{this.setState({fileUrl: event.target.value})}} id="file-path" placeholder="" />
									<small className="form-text text-muted">http://example.com/sample.csv (or) https://goo.gl/SX2tNf (or) http://bit.ly/2hXvlAQ</small>
								</div>
							</div>
							<div class="float-right mt50">
							
							{/* <div className="loader loader-1 mt15" style={loaderPosition}></div> */}
							{/* <div className="btn ajax-loader loading mr10">Please Wait</div> */}
								{/* <input type="button" className="smack-btn smack-btn-primary  mb20" onClick={this.sendFileUrl.bind(this)}  value="Continue" /> */}
								{(this.state.loading) ? 
									this.context.loaderText
									:
									<input type="button" className="smack-btn smack-btn-primary  mb20" onClick={this.sendFileUrl.bind(this)}  value="Continue" />
									}
							</div>
						</div>	
					</div>
					
				: (this.state.showImportRecord)  ? 
				<div className="file-info-container">
				<h3 className="file-name">{this.state.file_name} - <span className="size">{this.state.file_size}</span></h3>
				<div class="d-flex justify-content-center mt40">
									<div className="form-check form-check-inline">
										<label class="form-check-label">
											<input className="form-check-input" onClick={(event)=>{this.setState({newItem: true, existingItem: false}); this.context.setMode(event.target.id)}} type="radio" name="post-item" id="Insert" checked={this.state.newItem} /> New Item
										</label>
									</div>
									<div className="form-check form-check-inline">
										<label className="form-check-label">
											<input className="form-check-input" onClick={(event)=>{this.setState({existingItem: true, newItem: false}); this.context.setMode(event.target.id)}} type="radio" name="post-item" id="Update" checked={this.state.existingItem} /> Existing Items
										</label>
									</div>
								</div>

								<div className="d-flex justify-content-center mt40">
									<div className="form-group">
										<label>{this.context.translateLanguage.ImportEachRecordAs}</label>
										{(this.state.showImportRecord) ?
										<div>
										<select value={this.context.selectedType} className="select" onChange={(event)=>{this.context.setSelectedType(event.target.value)}} name="" id="">
											<optgroup label="PostType">
											{this.state.postType.map((posttype, index) => {
											return <option value={posttype}>{posttype}</option>
											
										})}
											</optgroup>
											<optgroup label="Taxonomy">
											{this.state.taxonomy.map((taxonomy, index) => {
											return <option value={taxonomy}>{taxonomy}</option>
										})}
											</optgroup>
										</select>
										</div> :
										<div> {this.context.translateLanguage.NoRecord} </div> }
								</div>
								</div>
								<div className="float-right">
								{(this.state.loading) ? 
									this.context.loaderText
									:
									<input type="button" className="smack-btn smack-btn-primary mb20" onClick={(event)=>{this.sendConfiguration();}} value="Continue" />
									}
								
									
								</div>
				</div>
				: 
				// (this.state.showUploadModal) ?
				// 					:
					""}
					<a href="#" className="smack-btn smack-btn-primary d-none" id="csv-url-modal" data-toggle="modal" data-target="#upload_csv">{this.context.translateLanguage.UploadedCSVFileLists}</a>
					<div id="upload_csv" className="modal fade payment_modal" role="dialog">
            <div className="modal-dialog modal-lg modal-dialog-centered">
          
              {/* <!-- Modal content--> */}
              <div className="modal-content">
                <div className="modal-header">
								<h1 className="main-heading text-center">{this.state.file_name}</h1>
                  <button type="button" id="csv-url-modal-close" className="close" data-dismiss="modal">&times;</button>
                </div>
                <div className="modal-body my-2">
                  
                  <ul>
                {this.context.csvFileNames.map((filename,index) => {
                    return(
										<li>
											<div className="form-check form-check-inline">
											<label class="form-check-label">
												<input className="form-check-input"  onClick={(event)=>{if(event.target.checked) { this.context.setSelectedFileUrl(this.context.csvFileUrls[index]); console.log(this.context.selectedFileUrl);}}} type="radio" name="post-item" id="" /> {filename}
											</label>
										</div>
										</li>
										)})}
										</ul>
										<div className="float-right">
											<input type="button" className="smack-btn smack-btn-primary mb20" onClick={(event)=>{this.sendFileUrl();}} value="Continue" />
										</div>
                       
                  
                </div>
              </div>
          
            </div>
          </div>
            {/* <!-- upload Zipped CSV model closed --> */} 


			</div>
		)
    }
}


export default UploadFromUrl;

