import React, { Component } from 'react';
import {AppContext} from '../../context.js'
import UploadOptions from './uploadoptions/uploadOptions.js';
import ManagerOptions from '../manager/manageroptions/managerOptions.js';
import ExportOptions from '../export/exportoptions/exportOptions.js';
import SettingsOptions from '../settings/settingsoptions/settingsOptions.js';
import SupportDisplay from '../support/supportoptions/supportDisplay.js';
import DashboardGraphDisplay from '../dashboard/dashboardoptions/dashboardGraphDisplay.js';
import Cookies from 'universal-cookie';
import axios from 'axios';

export default class TabNavigator extends Component {
	static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
			showMaintenanceMode : false,
			displayTabNavigator : "block",
		}
		this.language = {};
	}


	componentDidMount() {
		this.checkMaintenanceMode();
		//((!this.context.activateMappingSection) && (this.context.fromTemplateMappingSection)) ? this.setState({displayTabNavigator: "none"}) : this.setState({displayTabNavigator: "block"})		

		

		
const cookies = new Cookies();
//cookies.set('selec', 'Pacman', { path: '/' });
// Pacman

if (cookies.get('selectedTab') == "" || cookies.get('selectedTab') == undefined){
	cookies.set('selectedTab', 'import-update', { path: '/' });
}

console.log("TabCookies",cookies.get('selectedTab')); 
this.context.setSelectedTab(cookies.get('selectedTab'))

		this.context.languageTranslation(JSON.parse(window.wpr_object.file));
		this.forceUpdate();
	}


	async checkMaintenanceMode(){
		var formData = new FormData();
        formData.set('action','checkmain_mode');
            
        const response = await axios({
                method: 'post',
                url: ajaxurl,
                data: formData,
                config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

		console.log('Mode',response)

		var status = false;
		
		(response.data.success)  ? status = true : status = false

		(response.data == 0) ? status = false : ''
		
		this.setState({showMaintenanceMode:status}); 
		this.context.setMaintenanceMode(status) 
	}

	async disableMaintenanceMode(){
		var formData = new FormData();
        formData.set('action','settings_options');
        formData.set('option', "enable_main_mode");
        formData.set('value', false);        
            
        const response = await axios({
                method: 'post',
                url: ajaxurl,
                data: formData,
                config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

		console.log(response)
		
			if (response.data.success){
				this.context.setMaintenanceMode(false)
				location.reload();
			}

	}
	
	
	
    render() {
		return(
				
                <div className=" container">					
			      	<div className="row tab-section justify-content-center" >
			            <ul class="tabs col-sm-12 col-md-12">
						<li className={`tab-list col-xs-6 col-sm-4 col-md-2 ${(this.context.selectedTab === 'dashboard') ? 'active' : ''}`} onClick={() => this.context.setSelectedTab('dashboard') }  >{this.context.translateLanguage.Dashboard}</li>
						<li className={`tab-list col-xs-6 col-sm-4 col-md-2 ${(this.context.selectedTab === 'import-update') ? 'active' : ''}`} onClick={() => this.context.setSelectedTab('import-update')  } >{this.context.translateLanguage.ImportUpdate}</li>
						<li className={`tab-list col-xs-6 col-sm-4 col-md-2 ${(this.context.selectedTab === 'manager') ? 'active' : ''}`} onClick={() => this.context.setSelectedTab('manager') } >{this.context.translateLanguage.Manager}</li>
						<li className={`tab-list col-xs-6 col-sm-4 col-md-2 ${(this.context.selectedTab === 'export') ? 'active' : ''}`} onClick={() => this.context.setSelectedTab('export') } >{this.context.translateLanguage.Export}</li>
						<li className={`tab-list col-xs-6 col-sm-4 col-md-2 ${(this.context.selectedTab === 'settings') ? 'active' : ''}`} onClick={() => this.context.setSelectedTab('settings') } >{this.context.translateLanguage.Settings}</li>
						<li className={`tab-list col-xs-6 col-sm-4 col-md-2 ${(this.context.selectedTab === 'support') ? 'active' : ''}`} onClick={() => this.context.setSelectedTab('support') } >{this.context.translateLanguage.Support}</li>
				        </ul>
			    	</div>
					{ (this.state.showMaintenanceMode) ?
					<div className="maintenance-mode">
						<span><img src={`${window.wpr_object.imagePath}alert.png`}></img></span>maintenance mode is enabled <button type="button" class="csv-link" onClick={() => this.disableMaintenanceMode() }>Disable</button>
					</div> : ""					
					}
					
						{(this.context.selectedTab === 'import-update') ?
						<UploadOptions /> :
						(this.context.selectedTab === 'manager') ?
						<ManagerOptions /> :
						(this.context.selectedTab === 'export') ?
						<ExportOptions /> :
						(this.context.selectedTab === 'settings') ?
						<SettingsOptions /> :
						(this.context.selectedTab === 'support') ?
						<SupportDisplay /> :
						(this.context.selectedTab === 'dashboard') ?
						<DashboardGraphDisplay /> :
						""
					}
				</div>
				
			
	    );
    }
}
