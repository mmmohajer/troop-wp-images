import React, { Component } from 'react';
import TabNavigator from './tabNavigator';

export default class MainTabs extends Component {
    render() {
        return (<TabNavigator />);                
    }
}