import React, { Component } from 'react';
import { FilePond } from 'react-filepond';
import {AppContext} from '../../../context.js'
import axios from 'axios';

class MappingSection extends Component {
    static imageUploadResponse = '';
    static activateMediaHandling = false;
    static showUploadedImageList = false;
    static imageFileNames = [];
    static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
            loading: false,
            acfGroupFieldsActive:"",
            display: "none",
            display1: true,
            advancedMode: "active",
            templateName: '',
            dragAndDrop: "",
            showUploadedFiles: false,
            isDefaultFieldsMapped: true,
        }
        this.matchedCondition = true;
        this.select = '--select--';
        this.mappedFields = [];
        this.mandatoryFilled = false;
        this.nonMappedFieldsState = false;
        this.mappedFieldsState = false;
        this.count;
        this.hintNoteHeaderManipulation = "Specify the CSV header to be added in between the curley braces({ }).";
        this.exampleNoteHeaderManipulation = "{post_title}";
        this.hintMathNoteHeaderManipulation = "Specify operator(+,-,*,/) and CSV header as operand in MATH() within {}";
        this.exampleMathNoteHeaderManipulation = "MATH ({product_quantity}/{discount_price})";
        this.coreHeaderManipulation = [];
        this.coreMathHeaderManipulation = [];
        this.coreManipulatedCsvHeader = [];
        this.coreChoosedHeaderManipulation = [];
        this.acffreeHeaderManipulation = [];
        this.acffreeMathHeaderManipulation = [];
        this.acffreeManipulatedCsvHeader = [];
        this.acffreeChoosedHeaderManipulation = [];
        this.acfgroupHeaderManipulation = [],
        this.acfgroupMathHeaderManipulation = [],
        this.acfgroupManipulatedCsvHeader = [];
        this.acfgroupChoosedHeaderManipulation = [];
        this.acfproHeaderManipulation = [];
        this.acfproMathHeaderManipulation = [];
        this.acfproManipulatedCsvHeader = [];
        this.acfproChoosedHeaderManipulation = [];
        this.acfrepeaterHeaderManipulation = [];
        this.acfrepeaterMathHeaderManipulation = [];
        this.acfrepeaterManipulatedCsvHeader = [];
        this.acfrepeaterChoosedHeaderManipulation = [];
        this.toolsetHeaderManipulation = [];
        this.toolsetMathHeaderManipulation = [];
        this.toolsetManipulatedCsvHeader = [];
        this.toolsetChoosedHeaderManipulation = [];
        this.podsHeaderManipulation = [];
        this.podsMathHeaderManipulation = [];
        this.podsManipulatedCsvHeader = [];
        this.podsChoosedHeaderManipulation = [];
        this.customfieldsuiteHeaderManipulation = [];
        this.customfieldsuiteMathHeaderManipulation = [];
        this.customfieldsuiteManipulatedCsvHeader = [];
        this.customfieldsuiteChoosedHeaderManipulation = [];
        this.allinoneseoHeaderManipulation = [];
        this.allinoneseoMathHeaderManipulation = [];
        this.allinoneseoManipulatedCsvHeader = [];
        this.allinoneseoChoosedHeaderManipulation = [];
        this.yoastseoHeaderManipulation = [];
        this.yoastseoMathHeaderManipulation = [];
        this.yoastseoManipulatedCsvHeader = [];
        this.yoastseoChoosedHeaderManipulation = [];
        this.billingandshippingHeaderManipulation = [];
        this.billingandshippingMathHeaderManipulation = [];
        this.billingandshippingManipulatedCsvHeader = [];
        this.billingandshippingChoosedHeaderManipulation = [];
        this.wpmembersHeaderManipulation = [];
        this.wpmembersMathHeaderManipulation = [];
        this.wpmembersManipulatedCsvHeader = [];
        this.wpmembersChoosedHeaderManipulation = [];
        this.membersHeaderManipulation = [];
        this.membersMathHeaderManipulation = [];
        this.membersManipulatedCsvHeader = [];
        this.membersChoosedHeaderManipulation = [];
        this.productmetaHeaderManipulation = [];
        this.productmetaMathHeaderManipulation = [];
        this.productmetaManipulatedCsvHeader = [];
        this.productmetaChoosedHeaderManipulation = [];
        this.wpecomHeaderManipulation = [];
        this.wpecomMathHeaderManipulation = [];
        this.wpecomManipulatedCsvHeader = [];
        this.wpecomChoosedHeaderManipulation = [];
        this.eventsmanagerHeaderManipulation = [];
        this.eventsmanagerMathHeaderManipulation = [];
        this.eventsmanagerManipulatedCsvHeader = [];
        this.eventsmanagerChoosedHeaderManipulation = [];
        this.nextgengalleryHeaderManipulation = [];
        this.nextgengalleryMathHeaderManipulation = [];
        this.nextgengalleryManipulatedCsvHeader = [];
        this.nextgengalleryChoosedHeaderManipulation = [];
        this.cmb2HeaderManipulation = [];
        this.cmb2MathHeaderManipulation = [];
        this.cmb2ManipulatedCsvHeader = [];
        this.cmb2ChoosedHeaderManipulation = [];
        this.wordpresscustomfieldsHeaderManipulation = [];
        this.wordpresscustomfieldsMathHeaderManipulation = [];
        this.wordpresscustomfieldsManipulatedCsvHeader = [];
        this.wordpresscustomfieldsChoosedHeaderManipulation = [];
        this.wordpressusercustomfieldsHeaderManipulation = [];
        this.wordpressusercustomfieldsMathHeaderManipulation = [];
        this.wordpressusercustomfieldsManipulatedCsvHeader = [];
        this.wordpressusercustomfieldsChoosedHeaderManipulation = [];
        this.termsandtaxonomiesHeaderManipulation = [];
        this.termsandtaxonomiesMathHeaderManipulation = [];
        this.termsandtaxonomiesManipulatedCsvHeader = [];
        this.termsandtaxonomiesChoosedHeaderManipulation = [];
        this.inputOpenFileRef = React.createRef()
    }

    showFileloading() {
		this.inputOpenFileRef.current.click();
	}

	fileHandle(fieldname, file) {
		
	}

    componentDidMount() {
        this.context.setSelectedTabCookies("import-update");
        this.mappedFields = this.context.saveSelectedMappedFields.slice();
        console.log("from mapping", this.mappedFields);
        this.setState({ templateName: this.context.saveTemplateNames })
        if((this.mappedFields.length > 0) && (this.context.fromMediaHandlingState || this.context.activateUseExistingMappingState)){
            this.context.editedTemplateName(this.context.saveTemplateNames);
            this.forceUpdate();
        }        
    }

    componentWillUnmount() {
        if(this.context.fromTemplateMappingSection) {
            window.alert("Changes thay you made on template may not be saved");
            this.context.changeUseExistingMappingState(true);
				this.context.changeCreateNewMappingState(false);
				this.context.changeActivateMappingSectionState(false);
                this.context.changeActivateDragAndDropSectionState(false);
                this.context.fromDragAndDropMappingSection(true);
                this.context.setActivateDashboard(true);
                this.context.changeActivateTemplateSectionState(true);
            //this.context.fromTemplateMappingSection = false;
            this.context.fromTemplateMappingSectionState(false);
            console.log('From Mapping to Templates', this.context.fromTemplateMappingSection);
        }
    }

    addCustomFields() {
        this.context.totalRows = this.context.totalRows + 1;
        this.context.totalCustomFields.push(this.context.totalRows);
        this.forceUpdate();
    }

    onChangeWordPressUserCustomFieldsLabel(value, index) {
        this.context.wordPressUserCustomFieldsLabel[index] = value;
        this.context.wordPressUserCustomFields[index] =value; 
        this.context.wordPressUserCustomFields[index] = this.context.wordPressUserCustomFields[index].split(' ').join('_').toLowerCase(); 
        this.forceUpdate();
        return this.context.wordPressUserCustomFieldsLabel[index];
    }

    deleteUserCustomFields(i) {
        console.log(this.context.wordPressUserCustomFields);
        this.context.totalCustomFields.splice(i,1);
        this.context.wordPressUserCustomFields.splice(i,1);
        this.context.wordPressUserCustomFieldsLabel.splice(i,1);
        console.log(this.context.wordPressUserCustomFields);
        console.log(this.context.wordPressUserCustomFieldsLabel);
        this.forceUpdate();
      }
   
   /* async useExistingTemplateConfiguration() {
		//this.context.saveTemplateName(this.context.templateNameArray[index]);
		var formData = new FormData();
		formData.set('action','templateinfo');
		formData.set('TemplateName',this.context.saveTemplateNames);
		formData.set('Types', this.context.selectedType);
		formData.set('HashKey',this.context.hashKey);

		this.setState({
			loading : true, });
			
		const response = await axios({
			method: 'post',
			url: ajaxurl,
			data: formData,
			config: { headers: {'Content-Type': 'multipart/form-data' }}
		});

		if (response.status == 200)	{
			this.setState({
				loading : false, });
			console.log(response.data);
			if(response.data.success) {
                console.log("hai");
                if(response.data.mapping_type === "advanced") {
					if(response.data.already_mapped['CORE']) {
                        var fieldname = response.data.already_mapped.CORE;
                        var alreadyMappedFields={};
                        for(var i=0; i<this.context.wordPressCoreFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								if(this.context.wordPressCoreFields[i].name === key) {
									this.alreadyMappedState = true;
                                    this.context.wordPressCoreFields[i]["csvheader"] = fieldname[key];
                                    alreadyMappedFields =`{"wp_name":"${this.context.wordPressCoreFields[i].name}","csv_header":"${fieldname[key]}","type":"core"}`
									mappedFields.push(JSON.parse(alreadyMappedFields));
								}
                                   //this.forceUpdate();
                            }
                        }
                        if(!this.alreadyMappedState) {
                            this.context.wordPressCoreFields[i]["csvheader"] = "";
                            alreadyMappedFields =`{"wp_name":"${this.context.wordPressCoreFields[i].name}","csv_header":"","type":"core"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
                            //this.forceUpdate();
                        }
                        console.log("core fields",this.context.wordPressCoreFields[i]);
                    }
                }
                this.context.saveMappedFields(mappedFields);
            }
        }
    } */


    setDefaultMappedFields(value) {
        console.log("setting Default Fields");
        console.log(this.mappedFields);
        let jsonvalue = JSON.parse(value);
        if(this.mappedFields.length == 0) {
            this.mappedFields.push(jsonvalue);
            return;
        }
        else {
            for(var i=0; i<this.mappedFields.length; i++) {
                
                //if((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].csv_header === jsonvalue.csv_header) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    return;
                }
            }
            this.mappedFields.push(jsonvalue);
        }
    }

    onSelectMappedFields(value, index, type) {
        if (type === "core") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.coreChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.coreManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.coreChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = "";
                        return;
                        
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.coreChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.coreManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.coreChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }

            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.coreChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.coreManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.coreChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.coreChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.coreChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "acffree") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.acffreeChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.acffreeManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.acffreeChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = "";
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.acffreeChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.acffreeManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.acffreeChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }

            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.acffreeChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.acffreeManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.acffreeChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.acffreeChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.acfreeChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "acfgroupfields") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.acfgroupChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.acfgroupManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.acfgroupChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.acfgroupChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.acfgroupManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.acfgroupChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }

            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.acfgroupChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.acfgroupManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.acfgroupChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.acfgroupChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.acfgroupChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "acf") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.acfproChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.acfproManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.acfproChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.acfproChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.acfproManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.acfproChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.acfproChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.acfproManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.acfproChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.acfproChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.acfproChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "acfrepeater") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.acfrepeaterChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.acfrepeaterManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.acfrepeaterChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.acfrepeaterChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.acfrepeaterManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.acfrepeaterChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.acfrepeaterChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.acfrepeaterManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.acfrepeaterChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.acfrepeaterChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.acfrepeaterChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "toolsettypes") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.toolsetChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.toolsetManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.toolsetChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = "";
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.toolsetChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.toolsetManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.toolsetChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.toolsetChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.toolsetManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.toolsetChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.toolsetChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.toolsetChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "podstypesfields") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        // if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                        //     this.podsChoosedHeaderManipulation[index] = true;
                        //     this.mappedFields[i].csv_header = this.podsManipulatedCsvHeader[index];
                        //     this.forceUpdate();
                        // }
                        // else {
                        //     this.podsChoosedHeaderManipulation[index] = false;
                        //     this.forceUpdate();
                        // }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.podsChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.podsManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.podsChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.podsChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.podsManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.podsChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.podsChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.podsChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "customfieldsuitefields") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.customfieldsuiteChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.customfieldsuiteManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.customfieldsuiteChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.customfieldsuiteChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.customfieldsuiteManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.customfieldsuiteChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.customfieldsuiteChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.customfieldsuiteManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.customfieldsuiteChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.customfieldsuiteChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.customfieldsuiteChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "allinoneseo") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.allinoneseoChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.allinoneseoManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.allinoneseoChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.allinoneseoChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.allinoneseoManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.allinoneseoChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.allinoneseoChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.allinoneseoManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.allinoneseoChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.allinoneseoChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.allinoneseoChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "yoastseo") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.yoastseoChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.yoastseoManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.yoastseoChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.yoastseoChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.yoastseoManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.yoastseoChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.yoastseoChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.yoastseoManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.yoastseoChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.yoastseoChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.yoastseoChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "billingandshippinginformation") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.billingandshippingChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.billingandshippingManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.billingandshippingChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.billingandshippingChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.billingandshippingManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.billingandshippingChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.billingandshippingChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.billingandshippingManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.billingandshippingChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.billingandshippingChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.billingandshippingChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "customfieldswpmember") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.wpmembersChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.wpmembersManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.wpmembersChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.wpmembersChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.wpmembersManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.wpmembersChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.wpmembersChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.wpmembersManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.wpmembersChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.wpmembersChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.wpmembersChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "customfieldsmember") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.membersChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.membersManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.membersChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.membersChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.membersManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.membersChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.membersChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.membersManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.membersChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.membersChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.membersChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "productmetafields") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.productmetaChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.productmetaManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.productmetaChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.productmetaChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.productmetaManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.productmetaChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.productmetaChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.productmetaManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.productmetaChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.productmetaChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.ChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "wpecomcustomfields") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.wpecomChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.wpecomManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.wpecomChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = "";
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.wpecomChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.wpecomManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.wpecomChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.wpecomChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.wpecomManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.wpecomChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.wpecomChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.wpecomChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "eventsmanagerfields") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.eventsmanagerChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.eventsmanagerManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.eventsmanagerChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.eventsmanagerChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.eventsmanagerManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.eventsmanagerChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.eventsmanagerChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.eventsmanagerManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.eventsmanagerChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.eventsmanagerChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.eventsmanagerChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "nextgengalleryfields") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.nextgengalleryChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.nextgengalleryManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.nextgengalleryChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.nextgengalleryChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.nextgengalleryManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.nextgengalleryChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.nextgengalleryChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.nextgengalleryManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.nextgengalleryChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.nextgengalleryChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.nextgengalleryChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "cmb2customfields") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.cmb2ChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.cmb2ManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.cmb2ChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.cmb2ChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.cmb2ManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.cmb2ChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.cmb2ChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.cmb2ManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.cmb2ChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.cmb2ChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.cmb2ChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "wordpresscustomfields") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.wordpresscustomfieldsChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.wordpresscustomfieldsManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.wordpresscustomfieldsChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.wordpresscustomfieldsChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.wordpresscustomfieldsManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.wordpresscustomfieldsChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            } 
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.wordpresscustomfieldsChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.wordpresscustomfieldsManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.wordpresscustomfieldsChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.wordpresscustomfieldsChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.wordpresscustomfieldsChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "wordpressusercustomfields") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            // for (var i=0; i<this.mappedFields.length; i++) {
            //     if (this.mappedFields[i].wp_name === jsonvalue.wp_name) {
            //         if (jsonvalue.csv_header === "") {
            //             if (jsonvalue.selected_csv_header_type === "headermanipulation") {
            //                 this.wordpressusercustomfieldsChoosedHeaderManipulation[index] = true;
            //                 this.mappedFields[i].csv_header = this.wordpressusercustomfieldsManipulatedCsvHeader[index];
            //                 this.forceUpdate();
            //             }
            //             else {
            //                 this.wordpressusercustomfieldsChoosedHeaderManipulation[index] = false;
            //                 this.forceUpdate();
            //             }
            //             this.mappedFields[i].csv_header = ""; 
            //             return;
            //         }
            //         else {
            //             if(jsonvalue.selected_csv_header_type === "headermanipulation") {
            //                 this.wordpresscustomfieldsChoosedHeaderManipulation[index] = true;
            //                 this.mappedFields[i].csv_header = this.wordpressusercustomfieldsManipulatedCsvHeader[index];
            //                 this.forceUpdate();
            //             } 
            //             else {   
            //                 this.wordpressusercustomfieldsChoosedHeaderManipulation[index] = false; 
            //                 this.forceUpdate();            
            //             }
            //             this.mappedFields[i].csv_header = jsonvalue.csv_header;
            //             return;
            //         }
            //     }
            // } 
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.wordpressusercustomfieldsChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.wordpressusercustomfieldsManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.wordpressusercustomfieldsChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.wordpressusercustomfieldsChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.wordpressusercustomfieldsChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
        if (type === "termsandtaxonomies") {
            let jsonvalue = JSON.parse(value);
            console.log(jsonvalue);
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === jsonvalue.wp_name) && (this.mappedFields[i].type === jsonvalue.type)) {
                    if (jsonvalue.csv_header === "") {
                        if (jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.termsandtaxonomiesChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.termsandtaxonomiesManipulatedCsvHeader[index];
                            this.forceUpdate();
                        }
                        else {
                            this.termsandtaxonomiesChoosedHeaderManipulation[index] = false;
                            this.forceUpdate();
                        }
                        this.mappedFields[i].csv_header = ""; 
                        return;
                    }
                    else {
                        if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                            this.termsandtaxonomiesChoosedHeaderManipulation[index] = true;
                            this.mappedFields[i].csv_header = this.termsandtaxonomiesManipulatedCsvHeader[index];
                            this.forceUpdate();
                        } 
                        else {   
                            this.termsandtaxonomiesChoosedHeaderManipulation[index] = false; 
                            this.forceUpdate();            
                        }
                        this.mappedFields[i].csv_header = jsonvalue.csv_header;
                        return;
                    }
                }
            }
            if (jsonvalue.csv_header !== "") {
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.termsandtaxonomiesChoosedHeaderManipulation[index] = true;
                    jsonvalue.csv_header = this.termsandtaxonomiesManipulatedCsvHeader[index];
                    this.forceUpdate();
                }
                else {
                    this.termsandtaxonomiesChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                this.mappedFields.push(jsonvalue);
                return;
            }
            if (jsonvalue.csv_header === "") {  
                if(jsonvalue.selected_csv_header_type === "headermanipulation") {
                    this.termsandtaxonomiesChoosedHeaderManipulation[index] = true;
                    this.forceUpdate();
                }
                else {
                    this.termsandtaxonomiesChoosedHeaderManipulation[index] = false;
                    this.forceUpdate();
                }
                return;
            }   
        }
    }

    async deleteImage(filename, index) {
        var formData = new FormData();
        formData.set('action','delete_image');
        formData.set('image', filename);

        this.setState({ loading : true, });
        
        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);
        if (response.status == 200)	{
            if(response.data.success) {
                console.log(response.data);
            }
        }
    }

    async sendMappedFields() {
        var core = {};
        var acffree = {};
        var acf = {};
        var acfrepeater = {};
        var acfgroup = {};
        var toolsettypes = {};
        var podsfields = {};
        var customfieldsuite = {};
        var allinoneseo = {};
        var yoastseo = {};
        var billingandshipping = {};
        var customfieldswpmember = {};
        var customfieldsmember = {};
        var productmeta = {};
        var wpecomcustomfields = {};
        var eventsmanager = {};
        var nextgengallery = {};
        var cmb2fields = {};
        var wordpresscustomfields = {};
        var wordpressusercustomfields = {};
        var termsandtaxonomies = {};
        var mappedElements = {};

        this.count = 0;
        console.log("mappeed Fields", this.mappedFields);
        console.log(this.mappedFields.length);
        for(var i=0;i<this.mappedFields.length; i++)  {
            if(this.mappedFields[i].type == 'core') {
                if(this.context.selectedType === "Users") {
                    if(((this.mappedFields[i].wp_name === "user_login") && (this.mappedFields[i].csv_header !== "")) || ((this.mappedFields[i].wp_name === "user_email") && (this.mappedFields[i].csv_header !== ""))) { 
                        this.count=this.count+1;  
                    }
                }
            }
            if((this.context.selectedType === "Users") && (i == this.mappedFields.length-1) && (this.count !== 2)) {
                window.alert("User Login and User Email are Mandatory Fields");
                return;
            }
            
            if(this.mappedFields[i].type === 'core') {
                core[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['CORE'] = core;
                continue;
            }
            if(this.mappedFields[i].type === 'acffree') {
                acffree[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['ACF'] = acffree;
                continue;
            }
            if(this.mappedFields[i].type === 'acf') {
                acf[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['ACF'] = acf;
                continue;
            }
            if(this.mappedFields[i].type == 'acfrepeater') {
                acfrepeater[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['RF'] = acfrepeater;
                continue;
            }
            if(this.mappedFields[i].type == 'acfgroupfields') {
                acfgroup[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['GF'] = acfgroup;
                continue;
            }
            if(this.mappedFields[i].type == 'toolsettypes') {
                toolsettypes[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['TYPES'] = toolsettypes;
                continue;
            }
            if(this.mappedFields[i].type == 'podstypesfields') {
                podsfields[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['PODS'] = podsfields;
                continue;
            }
            if(this.mappedFields[i].type == 'customfieldsuitefields') {
                customfieldsuite[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['CFS'] = customfieldsuite;
                continue;
            }
            if(this.mappedFields[i].type == 'allinoneseo') {
                allinoneseo[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['AIOSEO'] = allinoneseo;
                continue;
            }
            if(this.mappedFields[i].type == 'yoastseo') {
                yoastseo[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['YOASTSEO'] = yoastseo;
                continue;
            }
            if(this.mappedFields[i].type == 'billingandshippinginformation') {
                billingandshipping[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['BSI'] = billingandshipping;
                continue;
            }
            if(this.mappedFields[i].type == 'customfieldswpmember') {
                customfieldswpmember[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['WPMEMBERS'] = customfieldswpmember;
                continue;
            }
            if(this.mappedFields[i].type == 'customfieldsmember') {
                customfieldsmember[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['MULTIROLE'] = customfieldsmember;
                continue;
            }
            if(this.mappedFields[i].type == 'productmetafields') {
                productmeta[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['ECOMMETA'] = productmeta;
                continue;
            }
            
            if(this.mappedFields[i].type == 'wpecomcustomfields') {
                wpecomcustomfields[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['WPECOMMETA'] = wpecomcustomfields;
                continue;
            }

            if(this.mappedFields[i].type == 'eventsmanagerfields') {
                eventsmanager[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['EVENTS'] = eventsmanager;
                continue;
            }

            if(this.mappedFields[i].type == 'nextgengalleryfields') {
                nextgengallery[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['NEXTGEN'] = nextgengallery;
                continue;
            }

            if(this.mappedFields[i].type == 'cmb2customfields') {
                cmb2fields[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['CMB2'] = cmb2fields;
                continue;
            }
            if(this.mappedFields[i].type == 'wordpresscustomfields') {
                wordpresscustomfields[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header
                mappedElements['CORECUSTFIELDS'] = wordpresscustomfields;
                continue;
            }
            if(this.mappedFields[i].type == 'wordpressusercustomfields') {
                wordpressusercustomfields[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header
                mappedElements['COREUSERCUSTFIELDS'] = wordpressusercustomfields;
                continue;
            }
            if(this.mappedFields[i].type == 'termsandtaxonomies') {
                termsandtaxonomies[this.mappedFields[i].wp_name] = this.mappedFields[i].csv_header;
                mappedElements['TERMS'] = termsandtaxonomies;
                continue;
            }
        }
        
        console.log('Sent Element');
        console.log(this.context.selectedType);
        console.log((this.context.activateUseExistingMappingState)? this.context.saveTemplateNames : this.state.templateName);
        console.log(JSON.stringify(this.context.activateUseExistingMappingState));
        console.log(  (this.state.display1) ? this.state.templateName : "");
        console.log(mappedElements);
        console.log(JSON.stringify(mappedElements));
        if(!this.context.fromTemplateMappingSection) {
            var mappedMethod = "normal"
            var formData = new FormData();
            formData.set('action','saveMappedFields');
            formData.set('HashKey',this.context.hashKey);
            formData.set('Types', this.context.selectedType);
            formData.set('TemplateName', (this.context.activateUseExistingMappingState) ? this.context.saveTemplateNames : (this.state.display1) ? this.state.templateName : "");
            formData.set('UseTemplateState', JSON.stringify(this.context.activateUseExistingMappingState));
            formData.set('NewTemplate', (!this.context.activateUseExistingMappingState) ? "" : (this.state.display1) ? this.state.templateName  : "");
            formData.set('MappedFields', JSON.stringify(mappedElements));
            formData.set('MappingType', mappedMethod);
        }
        if(this.context.fromTemplateMappingSection) {
            var mappedMethod = "normal"
            var formData = new FormData();
            formData.set('action', 'saveTemplate');
            formData.set('Types', this.context.selectedModuleNameInManagerSection);
            formData.set('TemplateName', this.context.selectedTemplateNameInManagerSection);
            formData.set('NewTemplate', (this.context.editedTemplateNameInManagerSection === "") ? this.context.selectedTemplateNameInManagerSection : this.context.editedTemplateNameInManagerSection);
            formData.set('MappedFields', JSON.stringify(mappedElements));
            formData.set('MappingType', mappedMethod);
        }                   
        
        this.setState({ loading : true, });
        
        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);
        
        if (response.status == 200)	{
            if(response.data.success) {
                this.context.saveMappedFields(this.mappedFields);
                this.mappedFields = [];
                this.context.changeActivateMappingSectionState(false);
                this.context.setActivateDashboard(false);
                if(this.context.fromTemplateMappingSection) {
                    this.context.changeActivateTemplateSectionState(true);
                    //this.context.fromTemplateMappingSection = false;
                    this.context.fromTemplateMappingSectionState(false);
                    console.log('From Mapping to Templates', this.context.fromTemplateMappingSection);
                }
                else {
                    this.context.changeActivateMediaHandlingSection(true)
                }
            }
            else {
                alert(response.data.message);
            } 
        }

    }

    isHeaderManipulation(fieldname, index, type) {
        if(type === "core") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        // if (isAvailableInAllFields) {
                        //   return false;
                        // }
                        this.coreManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.coreChoosedHeaderManipulation[index] = true;
                        console.log(this.coreManipulatedCsvHeader[i]);
                        return true;

                    }
                }
            }
        }  
        if(type === "acffree") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.acffreeManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.acffreeChoosedHeaderManipulation[index] = true;
                        console.log(this.acffreeManipulatedCsvHeader[i]);
                        return true;

                    }
                }
            }
        }
        if(type === "acfgroupfields") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.acfgroupManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.acfgroupChoosedHeaderManipulation[index] = true;
                        console.log(this.acfgroupManipulatedCsvHeader[i]);
                        return true;

                    }
                }
            }
        }  
        if(type === "acf") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.acfproManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.acfproChoosedHeaderManipulation[index] = true;
                        console.log(this.acfproManipulatedCsvHeader[i]);
                        return true;

                    }
                }
            }
        } 
        if(type === "acfrepeater") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.acfrepeaterManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.acfrepeaterChoosedHeaderManipulation[index] = true;
                        console.log(this.acfrepeaterManipulatedCsvHeader[i]);
                        return true;

                    }
                }
            }
        } 
        if(type === "toolsettypes") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.toolsetManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.toolsetChoosedHeaderManipulation[index] = true;
                        console.log(this.toolsetManipulatedCsvHeader[i]);
                        return true;

                    }
                }
            }
        }  
        if(type === "podstypesfields") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.customfieldsuiteManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.customfieldsuiteChoosedHeaderManipulation[index] = true;
                        console.log(this.customfieldsuiteManipulatedCsvHeader[i]);
                        return true;

                    }
                }
            }
        }
        if(type === "customfieldsuitefields") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.customfieldsuiteManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.customfieldsuiteChoosedHeaderManipulation[index] = true;
                        console.log(this.customfieldsuiteManipulatedCsvHeader[i]);
                        return true;

                    }
                }
            }
        }  
        if(type === "allinoneseo") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.allinoneseoManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.allinoneseoChoosedHeaderManipulation[index] = true;
                        console.log(this.allinoneseoManipulatedCsvHeader[i]);
                        return true;

                    }
                }
            }
        }   
        if(type === "yoastseo") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.yoastseoManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.yoastseoChoosedHeaderManipulation[index] = true;
                        console.log(this.yoastseoManipulatedCsvHeader[i]);
                        return true;

                    }
                }
            }
        }  
        if(type === "billingandshippinginformation") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.billingandshippingManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.billingandshippingChoosedHeaderManipulation[index] = true;
                        console.log(this.billingandshippingManipulatedCsvHeader[i]);
                        return true;
                    }
                }
            }
        } 
        if(type === "customfieldswpmember") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.wpmembersManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.wpmembersChoosedHeaderManipulation[index] = true;
                        console.log(this.wpmembersManipulatedCsvHeader[i]);
                        return true;
                    }
                }
            }
        }  
        if(type === "customfieldsmember") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.membersManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.membersChoosedHeaderManipulation[index] = true;
                        console.log(this.membersManipulatedCsvHeader[i]);
                        return true;
                    }
                }
            }
        }   
        if(type === "productmetafields") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.productmetaManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.productmetaChoosedHeaderManipulation[index] = true;
                        console.log(this.productmetaManipulatedCsvHeader[i]);
                        return true;
                    }
                }
            }
        }  
        if(type === "wpecomcustomfields") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.wpecomManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.wpecomChoosedHeaderManipulation[index] = true;
                        console.log(this.wpecomManipulatedCsvHeader[i]);
                        return true;
                    }
                }
            }
        }  
        if(type === "eventsmanagerfields") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.eventsmanagerManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.eventsmanagerChoosedHeaderManipulation[index] = true;
                        console.log(this.eventsmanagerManipulatedCsvHeader[i]);
                        return true;
                    }
                }
            }
        }  
        if(type === "nextgengalleryfields") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.nextgengalleryManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.nextgengalleryChoosedHeaderManipulation[index] = true;
                        console.log(this.nextgengalleryManipulatedCsvHeader[i]);
                        return true;
                    }
                }
            }
        } 
        if(type === "cmb2customfields") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.cmb2ManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.cmb2ChoosedHeaderManipulation[index] = true;
                        console.log(this.cmb2ManipulatedCsvHeader[i]);
                        return true;
                    }
                }
            }
        } 
        if(type === "wordpresscustomfields") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.wordpresscustomfieldsManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.wordpresscustomfieldsChoosedHeaderManipulation[index] = true;
                        console.log(this.wordpresscustomfieldsManipulatedCsvHeader[i]);
                        return true;
                    }
                }
            }
        }  
        if(type === "wordpressusercustomfields") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.wordpressusercustomfieldsManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.wordpressusercustomfieldsChoosedHeaderManipulation[index] = true;
                        console.log(this.wordpressusercustomfieldsManipulatedCsvHeader[i]);
                        return true;
                    }
                }
            }
        }  
        if(type === "termsandtaxonomies") {
            for(var i=0; i<this.mappedFields.length; i++) {
                if(this.mappedFields[i].wp_name === fieldname) {
                    for(var j=0; j<this.context.csvHeaderFields.length; j++) {
                        if(this.mappedFields[i].csv_header === this.context.csvHeaderFields[j]) {
                            return false;
                        }     
                    }
                    if(this.mappedFields[i].csv_header === "") {
                        return false;
                    }
                    else {
                        this.termsandtaxonomiesManipulatedCsvHeader[index] = this.mappedFields[i].csv_header;
                        this.termsandtaxonomiesChoosedHeaderManipulation[index] = true;
                        console.log(this.termsandtaxonomiesManipulatedCsvHeader[i]);
                        return true;
                    }
                }
            }
        }                                                                                                                                                                                                                                                                                                                        
    }



    isMapped(fieldname, csvHeader, type) {
        console.log('kumar Raja');
        if (this.context.fromMediaHandlingState || this.context.activateUseExistingMappingState) {
            for (var i=0; i<this.mappedFields.length; i++) {
                if ((this.mappedFields[i].wp_name === fieldname) && (this.mappedFields[i].csv_header === csvHeader) && (this.mappedFields[i].type === type)) { 
                    return true; 
                } 
                /* else {
                    if (fieldname === csvHeader && !this.context.activateUseExistingMappingState) {
                        var matchedfields =`{ "wp_name": "${fieldname}", "csv_header": "${csvHeader}", "type": "${type}" }`;
                        this.setDefaultMappedFields(matchedfields); 
                        return true;
                    }
                } */
            }

        } else {
            if (fieldname === csvHeader) {
                var matchedfields =`{ "wp_name": "${fieldname}", "csv_header": "${csvHeader}", "type": "${type}" }`;
                this.setDefaultMappedFields(matchedfields); 
                return true;
            }
        }
        return false;
    }
    
    render() {
        return(
            <div className=" container">
            <div className="col-md-6 offset-md-3">
            {/* <!-- mapping tab menu start--> */}
                <ul className="mapping-switcher">
                    <li className={`map ${this.state.advancedMode}`} onClick={(event)=>{this.setState({advancedMode: "active", dragAndDrop: ""}); this.context.changeActivateMappingSectionState(true); this.context.changeActivateDragAndDropSectionState(false); }} data-form="create">{this.context.translateLanguage.ADVANCEDMODE}</li>
                    <li className={`map ${this.state.dragAndDrop}`} onClick={(event)=>{this.setState({advancedMode: "", dragAndDrop: "active"}); this.context.changeActivateDragAndDropSectionState(true); this.context.changeActivateMappingSectionState(false);}} data-form="existing">{this.context.translateLanguage.DRAGDROPMODE}</li>
                </ul>
            </div>

            {/* <!-- mapping tab menu End--> */}
            <div className="clearfix"></div>

            <div id="mapping-accordion">
            <div className="card csv-importer-panel mt50">

                {/* <!-- Wordpress Fields Starts--> */}
                <h1 className="card-header main-heading active" id="wordpress-fields" onClick={() => {toggle_func('wordpress-fields')}}>{this.context.translateLanguage.WordpressFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="wordpress-fields-body" >
                    <table className="table table-mapping">
                        <thead><tr><th>{this.context.translateLanguage.WPFIELDS}</th><th>{this.context.translateLanguage.CSVHEADER}</th><th>{this.context.translateLanguage.Action}</th></tr></thead>
                        <tbody>
                        { (this.context.wordPressCoreFields != null) ? this.context.wordPressCoreFields.map((corefields, index) => {   
                            return(
                             <tr>                    
                                <td>
                                    <div>
                                        <label className="wpfields">{corefields.label}</label>
                                        <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                    </div>
                                </td>
                                <td>
                                <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "core");}} name="" id="">
                                    <optgroup label="Core Fields">
                                    <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "core", "selected_csv_header_type": "select"}`}>--select--</option>
                                        {this.context.csvHeaderFields.map((csvheaders) => {
                                                return (<option selected={this.isMapped(corefields.name, csvheaders, "core")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "core", "selected_csv_header_type": "normal"}`}>
                                                        {csvheaders}
                                                        </option>);
                                        })}
                                    
                                    <option selected={this.isHeaderManipulation(corefields.name, index, "core")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.coreManipulatedCsvHeader[index]}", "type": "core", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                    
                                   </optgroup>
                                </select>
                                </td>
                                <td className="action">
                                    <a className="action-icon" data-toggle="tooltip" title="Static">
                                        <i className="csv-icon-plus-square" onClick={(event)=>{if(this.coreChoosedHeaderManipulation[index]) { this.coreHeaderManipulation[index]="active"; this.coreMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                        <div className={`manipulation-screen ${(this.coreHeaderManipulation[index])}`}>
                                            <span className="close" onClick={(event)=>{this.coreHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                            <div className="form-group">
                                                <textarea className="form-control" value={(this.coreManipulatedCsvHeader[index] == "undefined") ? this.coreManipulatedCsvHeader[index] = "" : this.coreManipulatedCsvHeader[index]} onChange={(event)=>{this.coreManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.coreManipulatedCsvHeader[index]}", "type": "core", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "core");}} rows={index}></textarea>
                                            </div>
                                            <div className="csv-hint">
                                                <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                            </div>
                                        </div>
                                    </a>
                                    <a className="action-icon" data-toggle="tooltip" title="Formula">
                                        <i className="csv-icon-sum" onClick={(event)=>{if(this.coreChoosedHeaderManipulation[index]) { this.coreMathHeaderManipulation[index]="active"; this.coreHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                        <div className={`manipulation-screen ${(this.coreMathHeaderManipulation[index])}`}>
                                            <span className="close" onClick={(event)=>{this.coreMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                            <div className="form-group">
                                                <textarea class="form-control" value={(this.coreManipulatedCsvHeader[index] == "undefined") ? this.coreManipulatedCsvHeader[index] = "" : this.coreManipulatedCsvHeader[index]} onChange={(event)=>{this.coreManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.coreManipulatedCsvHeader[index]}", "type": "core", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "core");}} rows={index}></textarea>
                                            </div>
                                            <div className="csv-hint">
                                                <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                            </div>
                                        </div>
                                    </a>
                                </td>
                                </tr>
                                )}) : "" }
                        </tbody>
                    </table>

                </div>
            </div> 
            </div>
            <div className="clearfix"></div>

            {(this.context.showAcfFreeFieldsState) ?
    <div id="mapping-accordion">
        <div className="card csv-importer-panel mt50">
            {/* <!-- ACF Free Fields Starts--> */}
            <h1 className= "card-header main-heading active"  id="acffree-fields" onClick={()=>toggle_func('acffree-fields')}>{this.context.translateLanguage.ACFFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="acffree-fields-body"  data-display={this.state.display}>
            <div className="card-body" id="acffree-fields-body" >
                <table className="table table-mapping">
                    <thead>
                        <tr>
                            <th>{this.context.translateLanguage.WPFIELDS}</th>
                            <th>{this.context.translateLanguage.CSVHEADER}</th>
                            <th>{this.context.translateLanguage.Action}</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        {(this.context.acfFreeFields != null) ? 
                        this.context.acfFreeFields.map((corefields, index) => {
                            return(
                        <tr>
                            <td>
                                <label className="wpfields">{corefields.label}</label>
                                <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                            </td> 
                            <td>
                            <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "acffree");}} name="" id="">
                                <optgroup label="Acf Free Fields">
                                <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "acffree", "selected_csv_header_type": "select"}`}>--select--</option>
                                {this.context.csvHeaderFields.map((csvheaders) => {
                                                return (<option selected={this.isMapped(corefields.name, csvheaders, "acffree")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "acffree", "selected_csv_header_type": "normal"}`}>
                                                        {csvheaders}
                                                        </option>);
                                })}
                               <option selected={this.isHeaderManipulation(corefields.name, index, "acffree")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.acffreeManipulatedCsvHeader[index]}", "type": "acffree", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                </optgroup>
                                </select>
                            </td>
                            <td className="action">
                                    <a className="action-icon" data-toggle="tooltip" title="Static">
                                        <i className="csv-icon-plus-square" onClick={(event)=>{if(this.acffreeChoosedHeaderManipulation[index]) { this.acffreeHeaderManipulation[index]="active"; this.acffreeMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                        <div className={`manipulation-screen ${(this.acffreeHeaderManipulation[index])}`}>
                                            <span className="close" onClick={(event)=>{this.acffreeHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                            <div className="form-group">
                                                <textarea className="form-control" value={(this.acffreeManipulatedCsvHeader[index] == "undefined") ? this.acffreeManipulatedCsvHeader[index] = "" : this.acffreeManipulatedCsvHeader[index]} onChange={(event)=>{this.acffreeManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.acffreeManipulatedCsvHeader[index]}", "type": "acffree", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "acffree");}} rows={index}></textarea>
                                            </div>
                                            <div className="csv-hint">
                                                <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                            </div>
                                        </div>
                                    </a>
                                    <a className="action-icon" data-toggle="tooltip" title="Formula">
                                        <i className="csv-icon-sum" onClick={(event)=>{if(this.acffreeChoosedHeaderManipulation[index]) { this.acffreeMathHeaderManipulation[index]="active"; this.acffreeHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                        <div className={`manipulation-screen ${(this.acffreeMathHeaderManipulation[index])}`}>
                                            <span className="close" onClick={(event)=>{this.acffreeMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                            <div className="form-group">
                                                <textarea class="form-control" value={(this.acffreeManipulatedCsvHeader[index] == "undefined") ? this.acffreeManipulatedCsvHeader[index] = "" : this.acffreeManipulatedCsvHeader[index]} onChange={(event)=>{this.acffreeManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.acffreeManipulatedCsvHeader[index]}", "type": "acffree", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "acffree");}} rows={index}></textarea>
                                            </div>
                                            <div className="csv-hint">
                                                <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                            </div>
                                        </div>
                                    </a>
                                </td>
                        </tr>
                        )}) : ""}
                    </tbody>
                </table>

            </div>
        </div> 
    </div> 
    </div>
    : "" }    
            {/* <!-- ACF Free Fields End--> */}

            <div className="clearfix"></div>

    {(this.context.showAcfGroupFieldsState) ?
    <div id="mapping-accordion">
        <div className="card csv-importer-panel mt50">
            {/* <!-- ACF Group Fields Starts--> */}
            <h1 className= "card-header main-heading active"  id="acfgroup-fields" onClick={()=>toggle_func('acfgroup-fields')}>{this.context.translateLanguage.ACFGroupFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="acfgroup-fields-body"  data-display={this.state.display}>
            <div className="card-body" id="acfgroup-fields-body" >
                <table className="table table-mapping">
                    <thead>
                        <tr>
                            <th>{this.context.translateLanguage.WPFIELDS}</th>
                            <th>{this.context.translateLanguage.CSVHEADER}</th>
                            <th>{this.context.translateLanguage.Action}</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        {(this.context.acfGroupFields != null) ? 
                        this.context.acfGroupFields.map((corefields, index) => {
                            return(
                                <tr>
                                <td>
                                    <label className="wpfields">{corefields.label}</label>
                                    <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                </td> 
                                <td>
                                <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "acfgroupfields");}} name="" id="">
                                    <optgroup label="Acf Group Fields">
                                    <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "acfgroupfields", "selected_csv_header_type": "select"}`}>--select--</option>
                                    {this.context.csvHeaderFields.map((csvheaders) => {
                                                    return (<option selected={this.isMapped(corefields.name, csvheaders, "acfgroupfields")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "acfgroupfields", "selected_csv_header_type": "normal"}`}>
                                                            {csvheaders}
                                                            </option>);
                                    })}
                                   <option selected={this.isHeaderManipulation(corefields.name, index, "acfgroupfields")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.acfgroupManipulatedCsvHeader[index]}", "type": "acfgroupfields", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                    </optgroup>
                                    </select>
                                </td>
                                <td className="action">
                                        <a className="action-icon" data-toggle="tooltip" title="Static">
                                            <i className="csv-icon-plus-square" onClick={(event)=>{if(this.acfgroupChoosedHeaderManipulation[index]) { this.acfgroupHeaderManipulation[index]="active"; this.acfgroupMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.acfgroupHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.acfgroupHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea className="form-control" value={(this.acfgroupManipulatedCsvHeader[index] == "undefined") ? this.acfgroupManipulatedCsvHeader[index] = "" : this.acfgroupManipulatedCsvHeader[index]} onChange={(event)=>{this.acfgroupManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.acfgroupManipulatedCsvHeader[index]}", "type": "acfgroupfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "acfgroupfields");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                    <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                        <a className="action-icon" data-toggle="tooltip" title="Formula">
                                            <i className="csv-icon-sum" onClick={(event)=>{if(this.acfgroupChoosedHeaderManipulation[index]) { this.acfgroupMathHeaderManipulation[index]="active"; this.acfgroupHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.acfgroupMathHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.acfgroupMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea class="form-control" value={(this.acfgroupManipulatedCsvHeader[index] == "undefined") ? this.acfgroupManipulatedCsvHeader[index] = "" : this.acfgroupManipulatedCsvHeader[index]} onChange={(event)=>{this.acfgroupManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.acfgroupManipulatedCsvHeader[index]}", "type": "acfgroupfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "acfgroupfields");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                    <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                    </td>
                            </tr>
                        )}) : ""}
                    </tbody>
                </table>

            </div>
        </div> 
    </div> 
    </div>
    : "" }    
            {/* <!-- ACF Group Fields End--> */}

            <div className="clearfix"></div>
    {(this.context.showAcfProFieldsState) ?
    <div id="mapping-accordion">
        <div className="card csv-importer-panel mt50">
            {/* <!-- ACF Pro Fields Starts--> */}
            <h1 className="card-header main-heading active" id="acfpro-fields" onClick={()=>toggle_func('acfpro-fields')}>{this.context.translateLanguage.ACFProFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="acfpro-fields-body"  data-display={this.state.display}>
            <div className="card-body" id="acfpro-fields-body" >
                <table className="table table-mapping">
                    <thead>
                        <tr>
                            <th>{this.context.translateLanguage.WPFIELDS}</th>
                            <th>{this.context.translateLanguage.CSVHEADER}</th>
                            <th>{this.context.translateLanguage.Action}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {(this.context.acfProFields != null) ?
                        this.context.acfProFields.map((corefields, index) => {
                            return(
                                <tr>
                                <td>
                                    <label className="wpfields">{corefields.label}</label>
                                    <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                </td> 
                                <td>
                                <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "acf");}} name="" id="">
                                    <optgroup label="Acf Pro Fields">
                                    <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "acf", "selected_csv_header_type": "select"}`}>--select--</option>
                                    {this.context.csvHeaderFields.map((csvheaders) => {
                                                    return (<option selected={this.isMapped(corefields.name, csvheaders, "acf")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "acf", "selected_csv_header_type": "normal"}`}>
                                                            {csvheaders}
                                                            </option>);
                                    })}
                                   <option selected={this.isHeaderManipulation(corefields.name, index, "acf")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.acfproManipulatedCsvHeader[index]}", "type": "acf", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                    </optgroup>
                                    </select>
                                </td>
                                <td className="action">
                                        <a className="action-icon" data-toggle="tooltip" title="Static">
                                            <i className="csv-icon-plus-square" onClick={(event)=>{if(this.acfproChoosedHeaderManipulation[index]) { this.acfproHeaderManipulation[index]="active"; this.acfproMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.acfproHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.acfproHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea className="form-control" value={(this.acfproManipulatedCsvHeader[index] == "undefined") ? this.acfproManipulatedCsvHeader[index] = "" : this.acfproManipulatedCsvHeader[index]} onChange={(event)=>{this.acfproManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.acfproManipulatedCsvHeader[index]}", "type": "acf", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "acf");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                    <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                        <a className="action-icon" data-toggle="tooltip" title="Formula">
                                            <i className="csv-icon-sum" onClick={(event)=>{if(this.acfproChoosedHeaderManipulation[index]) { this.acfproMathHeaderManipulation[index]="active"; this.acfproHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.acfproMathHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.acfproMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea class="form-control" value={(this.acfproManipulatedCsvHeader[index] == "undefined") ? this.acfproManipulatedCsvHeader[index] = "" : this.acfproManipulatedCsvHeader[index]} onChange={(event)=>{this.acfproManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.acfproManipulatedCsvHeader[index]}", "type": "acf", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "acf");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                    <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                    </td>
                            </tr>
                        )}) : ''}
                    </tbody>
                </table>

            </div>
        </div> 
    </div>
    </div>
    : "" }
            {/* <!-- ACF Pro Fields End--> */}
        
    <div className="clearfix"></div>

    {(this.context.showAcfRepeaterFieldsState) ?
    <div id="mapping-accordion">
        <div className="card csv-importer-panel mt50">
            {/* <!-- ACF Repeater Fields Starts--> */}
            <h1 className="card-header main-heading active" id="acfrepeater-fields" onClick={()=>toggle_func('acfrepeater-fields')}>{this.context.translateLanguage.ACFRepeaterFields}<span className="csv-icon-angle-down float-right"></span></h1>
            <div className="card-body" id="acfrepeater-fields-body"  data-display={this.state.display}>
                <table className="table table-mapping">
                    <thead>
                        <tr>
                            <th>{this.context.translateLanguage.WPFIELDS}</th>
                            <th>{this.context.translateLanguage.CSVHEADER}</th>
                            <th>{this.context.translateLanguage.Action}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {(this.context.acfRepeaterFields != null) ?
                        this.context.acfRepeaterFields.map((corefields, index) => {
                            return(
                                <tr>
                                <td>
                                    <label className="wpfields">{corefields.label}</label>
                                    <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                </td> 
                                <td>
                                <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "acfrepeater");}} name="" id="">
                                    <optgroup label="Acf Repeater Fields">
                                    <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "acfrepeater", "selected_csv_header_type": "select"}`}>--select--</option>
                                    {this.context.csvHeaderFields.map((csvheaders) => {
                                                    return (<option selected={this.isMapped(corefields.name, csvheaders, "acfrepeater")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "acfrepeater", "selected_csv_header_type": "normal"}`}>
                                                            {csvheaders}
                                                            </option>);
                                    })}
                                   <option selected={this.isHeaderManipulation(corefields.name, index, "acfrepeater")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.acfrepeaterManipulatedCsvHeader[index]}", "type": "acfrepeater", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                    </optgroup>
                                    </select>
                                </td>
                                <td className="action">
                                        <a className="action-icon" data-toggle="tooltip" title="Static">
                                            <i className="csv-icon-plus-square" onClick={(event)=>{if(this.acfrepeaterChoosedHeaderManipulation[index]) { this.acfrepeaterHeaderManipulation[index]="active"; this.acfrepeaterMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.acfrepeaterHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.acfrepeaterHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea className="form-control" value={(this.acfrepeaterManipulatedCsvHeader[index] == "undefined") ? this.acfrepeaterManipulatedCsvHeader[index] = "" : this.acfrepeaterManipulatedCsvHeader[index]} onChange={(event)=>{this.acfrepeaterManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.acfrepeaterManipulatedCsvHeader[index]}", "type": "acfrepeater", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "acfrepeater");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                    <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                        <a className="action-icon" data-toggle="tooltip" title="Formula">
                                            <i className="csv-icon-sum" onClick={(event)=>{if(this.acfrepeaterChoosedHeaderManipulation[index]) { this.acfrepeaterMathHeaderManipulation[index]="active"; this.acfrepeaterHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.acfrepeaterMathHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.acfrepeaterMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea class="form-control" value={(this.acfrepeaterManipulatedCsvHeader[index] == "undefined") ? this.acfrepeaterManipulatedCsvHeader[index] = "" : this.acfrepeaterManipulatedCsvHeader[index]} onChange={(event)=>{this.acfrepeaterManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.acfrepeaterManipulatedCsvHeader[index]}", "type": "acfrepeater", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "acfrepeater");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                    <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                    </td>
                            </tr>
                        )}) : '' }
                    </tbody>
                </table>

            </div>
        </div> 
    </div>
    : "" }
                
            {/* <!-- Acf Repeater Types Fields End--> */}
    <div className="clearfix"></div>

    {(this.context.showTypesFieldsState) ?
    <div id="mapping-accordion">
        <div className="card csv-importer-panel mt50">
            {/* <!-- Tool Set Types Fields Starts--> */}
            <h1 className="card-header main-heading active" id="toolsettypes-fields" onClick={()=>toggle_func('toolsettypes-fields')}>{this.context.translateLanguage.TypesCustomFields}<span className="csv-icon-angle-down float-right"></span></h1>
            <div className="card-body" id="toolsettypes-fields-body"  data-display={this.state.display}>
                <table className="table table-mapping">
                    <thead>
                        <tr>
                            <th>{this.context.translateLanguage.WPFIELDS}</th>
                            <th>{this.context.translateLanguage.CSVHEADER}</th>
                            <th>{this.context.translateLanguage.Action}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {(this.context.typesFields != null) ?
                        this.context.typesFields.map((corefields, index) => {
                            return(
                                <tr>
                                <td>
                                    <label className="wpfields">{corefields.label}</label>
                                    <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                 </td> 
                                 <td>
                                
                                <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "toolsettypes");}} name="" id="">
                                    <optgroup label="Tool Set Types Fields">
                                    <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "toolsettypes", "selected_csv_header_type": "select"}`}>--select--</option>
                                    {this.context.csvHeaderFields.map((csvheaders) => {
                                                    return (<option selected={this.isMapped(corefields.name, csvheaders, "toolsettypes")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "toolsettypes", "selected_csv_header_type": "normal"}`}>
                                                            {csvheaders}
                                                            </option>);
                                    })}
                                   <option selected={this.isHeaderManipulation(corefields.name, index, "toolsettypes")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.toolsetManipulatedCsvHeader[index]}", "type": "toolsettypes", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                    </optgroup>
                                    </select>
                                </td>
                                <td className="action">
                                        <a className="action-icon" data-toggle="tooltip" title="Static">
                                            <i className="csv-icon-plus-square" onClick={(event)=>{if(this.toolsetChoosedHeaderManipulation[index]) { this.toolsetHeaderManipulation[index]="active"; this.toolsetMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.toolsetHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.toolsetHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea className="form-control" value={(this.toolsetManipulatedCsvHeader[index] == "undefined") ? this.toolsetManipulatedCsvHeader[index] = "" : this.toolsetManipulatedCsvHeader[index]} onChange={(event)=>{this.toolsetManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.toolsetManipulatedCsvHeader[index]}", "type": "toolsettypes", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "toolsettypes");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                    <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                        <a className="action-icon" data-toggle="tooltip" title="Formula">
                                            <i className="csv-icon-sum" onClick={(event)=>{if(this.toolsetChoosedHeaderManipulation[index]) { this.toolsetMathHeaderManipulation[index]="active"; this.toolsetHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.toolsetMathHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.toolsetMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea class="form-control" value={(this.toolsetManipulatedCsvHeader[index] == "undefined") ? this.toolsetManipulatedCsvHeader[index] = "" : this.toolsetManipulatedCsvHeader[index]} onChange={(event)=>{this.toolsetManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.toolsetManipulatedCsvHeader[index]}", "type": "toolsettypes", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "toolsettypes");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                    <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                    </td>
                            </tr>
                        )}) : '' }
                    </tbody>
                </table>

            </div>
        </div> 
    </div>
    : "" }
                
            {/* <!-- Tool Set Types Fields End--> */}
    <div className="clearfix"></div>

    {(this.context.showPodsFieldsState) ?
    <div id="mapping-accordion">
        <div className="card csv-importer-panel mt50">
            {/* <!-- Pods Types Fields Starts--> */}
            <h1 className="card-header main-heading active" id="pods-fields" onClick={()=>toggle_func('pods-fields')}>{this.context.translateLanguage.PodsFields}<span className="csv-icon-angle-down float-right"></span></h1>
            <div className="card-body" id="pods-fields-body"  data-display={this.state.display}>
                <table className="table table-mapping">
                    <thead>
                        <tr>
                            <th>{this.context.translateLanguage.WPFIELDS}</th>
                            <th>{this.context.translateLanguage.CSVHEADER}</th>
                            <th>{this.context.translateLanguage.Action}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {(this.context.podsFields != null) ?
                        this.context.podsFields.map((corefields, index) => {
                            return(
                                <tr>
                                <td>
                                    <label className="wpfields">{corefields.label}</label>
                                    <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                </td> 
                                <td>
                                <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "podstypesfields");}} name="" id="">
                                    <optgroup label="Pods Fields">
                                    <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "podstypesfields", "selected_csv_header_type": "select"}`}>--select--</option>
                                    {this.context.csvHeaderFields.map((csvheaders) => {
                                                    return (<option selected={this.isMapped(corefields.name, csvheaders, "podstypesfields")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "podstypesfields", "selected_csv_header_type": "normal"}`}>
                                                            {csvheaders}
                                                            </option>);
                                    })}
                                   <option selected={this.isHeaderManipulation(corefields.name, index, "podstypesfields")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.podsManipulatedCsvHeader[index]}", "type": "podstypesfields", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                    </optgroup>
                                    </select>
                                </td>
                                <td className="action">
                                        <a className="action-icon" data-toggle="tooltip" title="Static">
                                            <i className="csv-icon-plus-square" onClick={(event)=>{if(this.podsChoosedHeaderManipulation[index]) { this.podsHeaderManipulation[index]="active"; this.podsMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.podsHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.podsHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea className="form-control" value={(this.podsManipulatedCsvHeader[index] == "undefined") ? this.podsManipulatedCsvHeader[index] = "" : this.podsManipulatedCsvHeader[index]} onChange={(event)=>{this.podsManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.podsManipulatedCsvHeader[index]}", "type": "podstypesfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "podstypesfields");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                    <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                        <a className="action-icon" data-toggle="tooltip" title="Formula">
                                            <i className="csv-icon-sum" onClick={(event)=>{if(this.podsChoosedHeaderManipulation[index]) { this.podsMathHeaderManipulation[index]="active"; this.podsHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.podsMathHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.podsMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea class="form-control" value={(this.podsManipulatedCsvHeader[index] == "undefined") ? this.podsManipulatedCsvHeader[index] = "" : this.podsManipulatedCsvHeader[index]} onChange={(event)=>{this.podsManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.podsManipulatedCsvHeader[index]}", "type": "podstypesfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "podstypesfields");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                    <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                    </td>
                            </tr>
                        )}) : '' }
                    </tbody>
                </table>

            </div>
        </div> 
    </div>
    : "" }
                
            {/* <!-- Pods Types Fields End--> */}
    <div className="clearfix"></div>

    {(this.context.showCustomFieldSuiteState) ?
        <div id="mapping-accordion">
            <div className="card csv-importer-panel mt50">
                {/* <!-- Custom Field Suite Starts--> */}
                <h1 className="card-header main-heading active" id="customfieldsuite-fields" onClick={()=>toggle_func('customfieldsuite-fields')}>{this.context.translateLanguage.CustomFieldSuite}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="customfieldsuite-fields-body"  data-display={this.state.display}>
                    <table className="table table-mapping">
                        <thead>
                            <tr>
                                <th>{this.context.translateLanguage.WPFIELDS}</th>
                                <th>{this.context.translateLanguage.CSVHEADER}</th>
                                <th>{this.context.translateLanguage.Action}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(this.context.customFieldSuiteFields != null) ?
                            this.context.customFieldSuiteFields.map((corefields, index) => {
                                return(
                                    <tr>
                                    <td>
                                        <label className="wpfields">{corefields.label}</label>
                                        <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                    </td> 
                                    <td>
                                    <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "customfieldsuitefields");}} name="" id="">
                                        <optgroup label="Custom Field Suite Fields">
                                        <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "customfieldsuitefields", "selected_csv_header_type": "select"}`}>--select--</option>
                                        {this.context.csvHeaderFields.map((csvheaders) => {
                                                        return (<option selected={this.isMapped(corefields.name, csvheaders, "customfieldsuitefields")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "customfieldsuitefields", "selected_csv_header_type": "normal"}`}>
                                                                {csvheaders}
                                                                </option>);
                                        })}
                                       <option selected={this.isHeaderManipulation(corefields.name, index, "customfieldsuitefields")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.customfieldsuiteManipulatedCsvHeader[index]}", "type": "customfieldsuitefields", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                        </optgroup>
                                        </select>
                                    </td>
                                    <td className="action">
                                            <a className="action-icon" data-toggle="tooltip" title="Static">
                                                <i className="csv-icon-plus-square" onClick={(event)=>{if(this.customfieldsuiteChoosedHeaderManipulation[index]) { this.customfieldsuiteHeaderManipulation[index]="active"; this.customfieldsuiteMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.customfieldsuiteHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.customfieldsuiteHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea className="form-control" value={(this.customfieldsuiteManipulatedCsvHeader[index] == "undefined") ? this.customfieldsuiteManipulatedCsvHeader[index] = "" : this.customfieldsuiteManipulatedCsvHeader[index]} onChange={(event)=>{this.customfieldsuiteManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.customfieldsuiteManipulatedCsvHeader[index]}", "type": "customfieldsuitefields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "customfieldsuitefields");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                        <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a className="action-icon" data-toggle="tooltip" title="Formula">
                                                <i className="csv-icon-sum" onClick={(event)=>{if(this.customfieldsuiteChoosedHeaderManipulation[index]) { this.customfieldsuiteMathHeaderManipulation[index]="active"; this.customfieldsuiteHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.customfieldsuiteMathHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.customfieldsuiteMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea class="form-control" value={(this.customfieldsuiteManipulatedCsvHeader[index] == "undefined") ? this.customfieldsuiteManipulatedCsvHeader[index] = "" : this.customfieldsuiteManipulatedCsvHeader[index]} onChange={(event)=>{this.customfieldsuiteManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.customfieldsuiteManipulatedCsvHeader[index]}", "type": "customfieldsuitefields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "customfieldsuitefields");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                        <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </td>
                                </tr>
                            )}) : '' }
                        </tbody>
                    </table>
        
                </div>
            </div> 
        </div>
        : "" }
                    
                {/* <!-- Custom Field Suite End--> */}
        <div className="clearfix"></div>

    {(this.context.showAllInOneSeoFieldsState) ?
        <div id="mapping-accordion">
            <div className="card csv-importer-panel mt50">
                {/* <!-- All In One Seo Fields Starts--> */}
                <h1 className="card-header main-heading active" id="allinoneseo-fields" onClick={()=>toggle_func('allinoneseo-fields')}>{this.context.translateLanguage.AllInOneSeoFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="allinoneseo-fields-body"  data-display={this.state.display}>
                    <table className="table table-mapping">
                        <thead>
                            <tr>
                                <th>{this.context.translateLanguage.WPFIELDS}</th>
                                <th>{this.context.translateLanguage.CSVHEADER}</th>
                                <th>{this.context.translateLanguage.Action}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(this.context.allInOneSeoFields != null) ?
                            this.context.allInOneSeoFields.map((corefields, index) => {
                                return(
                                    <tr>
                                    <td>
                                        <label className="wpfields">{corefields.label}</label>
                                        <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                    </td> 
                                    <td>
                                    <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "allinoneseo");}} name="" id="">
                                        <optgroup label="All In One Seo Fields">
                                        <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "allinoneseo", "selected_csv_header_type": "select"}`}>--select--</option>
                                        {this.context.csvHeaderFields.map((csvheaders) => {
                                                        return (<option selected={this.isMapped(corefields.name, csvheaders, "allinoneseo")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "allinoneseo", "selected_csv_header_type": "normal"}`}>
                                                                {csvheaders}
                                                                </option>);
                                        })}
                                       <option selected={this.isHeaderManipulation(corefields.name, index, "allinoneseo")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.allinoneseoManipulatedCsvHeader[index]}", "type": "allinoneseo", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                        </optgroup>
                                        </select>
                                    </td>
                                    <td className="action">
                                            <a className="action-icon" data-toggle="tooltip" title="Static">
                                                <i className="csv-icon-plus-square" onClick={(event)=>{if(this.allinoneseoChoosedHeaderManipulation[index]) { this.allinoneseoHeaderManipulation[index]="active"; this.allinoneseoMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.allinoneseoHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.allinoneseoHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea className="form-control" value={(this.allinoneseoManipulatedCsvHeader[index] == "undefined") ? this.allinoneseoManipulatedCsvHeader[index] = "" : this.allinoneseoManipulatedCsvHeader[index]} onChange={(event)=>{this.allinoneseoManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.allinoneseoManipulatedCsvHeader[index]}", "type": "allinoneseo", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "allinoneseo");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                        <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a className="action-icon" data-toggle="tooltip" title="Formula">
                                                <i className="csv-icon-sum" onClick={(event)=>{if(this.allinoneseoChoosedHeaderManipulation[index]) { this.allinoneseoMathHeaderManipulation[index]="active"; this.allinoneseoHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.allinoneseoMathHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.allinoneseoMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea class="form-control" value={(this.allinoneseoManipulatedCsvHeader[index] == "undefined") ? this.allinoneseoManipulatedCsvHeader[index] = "" : this.allinoneseoManipulatedCsvHeader[index]} onChange={(event)=>{this.allinoneseoManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.allinoneseoManipulatedCsvHeader[index]}", "type": "allinoneseo", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "allinoneseo");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                        <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </td>
                                </tr>
                            )}) : '' }
                        </tbody>
                    </table>
        
                </div>
            </div> 
        </div>
        : "" }
                    
                {/* <!-- All In One Seo Fields End--> */}
        <div className="clearfix"></div>
        
    {(this.context.showYoastSeoFieldsState) ?
        <div id="mapping-accordion">
            <div className="card csv-importer-panel mt50">
                {/* <!-- Yoast Seo Fields Starts--> */}
                <h1 className="card-header main-heading active" id="yoastseo-fields" onClick={()=>toggle_func('yoastseo-fields')}>{this.context.translateLanguage.YoastSeoFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="yoastseo-fields-body"  data-display={this.state.display}>
                    <table className="table table-mapping">
                        <thead>
                            <tr>
                                <th>{this.context.translateLanguage.WPFIELDS}</th>
                                <th>{this.context.translateLanguage.CSVHEADER}</th>
                                <th>{this.context.translateLanguage.Action}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(this.context.yoastSeoFields != null) ?
                            this.context.yoastSeoFields.map((corefields, index) => {
                                return(
                                    <tr>
                                    <td>
                                        <label className="wpfields">{corefields.label}</label>
                                        <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                    </td> 
                                    <td>
                                    <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "yoastseo");}} name="" id="">
                                        <optgroup label="Yoast Seo Fields">
                                        <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "yoastseo", "selected_csv_header_type": "select"}`}>--select--</option>
                                        {this.context.csvHeaderFields.map((csvheaders) => {
                                                        return (<option selected={this.isMapped(corefields.name, csvheaders, "yoastseo")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "yoastseo", "selected_csv_header_type": "normal"}`}>
                                                                {csvheaders}
                                                                </option>);
                                        })}
                                       <option selected={this.isHeaderManipulation(corefields.name, index, "yoastseo")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.yoastseoManipulatedCsvHeader[index]}", "type": "yoastseo", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                        </optgroup>
                                        </select>
                                    </td>
                                    <td className="action">
                                            <a className="action-icon" data-toggle="tooltip" title="Static">
                                                <i className="csv-icon-plus-square" onClick={(event)=>{if(this.yoastseoChoosedHeaderManipulation[index]) { this.yoastseoHeaderManipulation[index]="active"; this.yoastseoMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.yoastseoHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.yoastseoHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea className="form-control" value={(this.yoastseoManipulatedCsvHeader[index] == "undefined") ? this.yoastseoManipulatedCsvHeader[index] = "" : this.yoastseoManipulatedCsvHeader[index]} onChange={(event)=>{this.yoastseoManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.yoastseoManipulatedCsvHeader[index]}", "type": "yoastseo", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "yoastseo");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                        <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a className="action-icon" data-toggle="tooltip" title="Formula">
                                                <i className="csv-icon-sum" onClick={(event)=>{if(this.yoastseoChoosedHeaderManipulation[index]) { this.yoastseoMathHeaderManipulation[index]="active"; this.yoastseoHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.yoastseoMathHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.yoastseoMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea class="form-control" value={(this.yoastseoManipulatedCsvHeader[index] == "undefined") ? this.yoastseoManipulatedCsvHeader[index] = "" : this.yoastseoManipulatedCsvHeader[index]} onChange={(event)=>{this.yoastseoManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.yoastseoManipulatedCsvHeader[index]}", "type": "yoastseo", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "yoastseo");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HIN} :</b> {this.hintMathNoteHeaderManipulation}
                                                        <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </td>
                                </tr>
                            )}) : '' }
                        </tbody>
                    </table>
        
                </div>
            </div> 
        </div>
        : "" }
                    
                {/* <!-- Yoast Seo Fields End--> */}
        <div className="clearfix"></div>

    {(this.context.showBillingAndShippingInformationState) ?
    <div id="mapping-accordion">
        <div className="card csv-importer-panel mt50">
            {/* <!-- Billing and Shipping Information Starts--> */}
            <h1 className="card-header main-heading active" id="billingandshipping-fields" onClick={()=>toggle_func('billingandshipping-fields')}>{this.context.translateLanguage.BillingAndShippingInformation}<span className="csv-icon-angle-down float-right"></span></h1>
            <div className="card-body" id="billingandshipping-fields-body"  data-display={this.state.display}>
                <table className="table table-mapping">
                    <thead>
                        <tr>
                            <th>{this.context.translateLanguage.WPFIELDS}</th>
                            <th>{this.context.translateLanguage.CSVHEADER}</th>
                            <th>{this.context.translateLanguage.Action}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {(this.context.billingAndShippingInformation != null) ?
                        this.context.billingAndShippingInformation.map((corefields, index) => {
                            return(
                                <tr>
                                <td>
                                    <label className="wpfields">{corefields.label}</label>
                                    <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                </td> 
                                <td>
                                <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "billingandshippinginformation");}} name="" id="">
                                    <optgroup label="Billing and Shipping Information">
                                    <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "billingandshippinginformation", "selected_csv_header_type": "select"}`}>--select--</option>
                                    {this.context.csvHeaderFields.map((csvheaders) => {
                                                    return (<option selected={this.isMapped(corefields.name, csvheaders, "billingandshippinginformation")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "billingandshippinginformation", "selected_csv_header_type": "normal"}`}>
                                                            {csvheaders}
                                                            </option>);
                                    })}
                                   <option selected={this.isHeaderManipulation(corefields.name, index, "billingandshippinginformation")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.billingandshippingManipulatedCsvHeader[index]}", "type": "billingandshippinginformation", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                    </optgroup>
                                    </select>
                                </td>
                                <td className="action">
                                        <a className="action-icon" data-toggle="tooltip" title="Static">
                                            <i className="csv-icon-plus-square" onClick={(event)=>{if(this.billingandshippingChoosedHeaderManipulation[index]) { this.billingandshippingHeaderManipulation[index]="active"; this.billingandshippingMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.billingandshippingHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.billingandshippingHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea className="form-control" value={(this.billingandshippingManipulatedCsvHeader[index] == "undefined") ? this.billingandshippingManipulatedCsvHeader[index] = "" : this.billingandshippingManipulatedCsvHeader[index]} onChange={(event)=>{this.billingandshippingManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.billingandshippingManipulatedCsvHeader[index]}", "type": "billingandshippinginformation", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "billingandshippinginformation");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                    <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                        <a className="action-icon" data-toggle="tooltip" title="Formula">
                                            <i className="csv-icon-sum" onClick={(event)=>{if(this.billingandshippingChoosedHeaderManipulation[index]) { this.billingandshippingMathHeaderManipulation[index]="active"; this.billingandshippingHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.billingandshippingMathHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.billingandshippingMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea class="form-control" value={(this.billingandshippingManipulatedCsvHeader[index] == "undefined") ? this.billingandshippingManipulatedCsvHeader[index] = "" : this.billingandshippingManipulatedCsvHeader[index]} onChange={(event)=>{this.billingandshippingManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.billingandshippingManipulatedCsvHeader[index]}", "type": "billingandshippinginformation", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "billingandshippinginformation");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                    <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                    </td>
                            </tr>
                        )}) : '' }
                    </tbody>
                </table>

            </div>
        </div> 
    </div>
    : "" }

                
            {/* <!-- Billing and Shipping Informaation End--> */}


    {(this.context.showCustomFieldsWpMembersState) ?
        <div id="mapping-accordion">
            <div className="card csv-importer-panel mt50">
                {/* <!-- Custom Fields WP Members Starts--> */}
                <h1 className="card-header main-heading active" id="customfieldswpmember-fields" onClick={()=>toggle_func('customfieldswpmember-fields')}>{this.context.translateLanguage.CustomFieldsWPMemberFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="customfieldswpmember-fields-body"  data-display={this.state.display}>
                    <table className="table table-mapping">
                        <thead>
                            <tr>
                                <th>{this.context.translateLanguage.WPFIELDS}</th>
                                <th>{this.context.translateLanguage.CSVHEADER}</th>
                                <th>{this.context.translateLanguage.Action}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(this.context.customFieldsWpMembersFields != null) ?
                            this.context.customFieldsWpMembersFields.map((corefields, index) => {
                                return(
                                    <tr>
                                    <td>
                                        <label className="wpfields">{corefields.label}</label>
                                        <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                    </td> 
                                    <td>
                                    <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "customfieldswpmember");}} name="" id="">
                                        <optgroup label="WP Member Fields">
                                        <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "customfieldswpmember", "selected_csv_header_type": "select"}`}>--select--</option>
                                        {this.context.csvHeaderFields.map((csvheaders) => {
                                                        return (<option selected={this.isMapped(corefields.name, csvheaders, "customfieldswpmember")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "customfieldswpmember", "selected_csv_header_type": "normal"}`}>
                                                                {csvheaders}
                                                                </option>);
                                        })}
                                       <option selected={this.isHeaderManipulation(corefields.name, index, "customfieldswpmember")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.wpmembersManipulatedCsvHeader[index]}", "type": "customfieldswpmember", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                        </optgroup>
                                        </select>
                                    </td>
                                    <td className="action">
                                            <a className="action-icon" data-toggle="tooltip" title="Static">
                                                <i className="csv-icon-plus-square" onClick={(event)=>{if(this.wpmembersChoosedHeaderManipulation[index]) { this.wpmembersHeaderManipulation[index]="active"; this.wpmembersMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.wpmembersHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.wpmembersHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea className="form-control" value={(this.wpmembersManipulatedCsvHeader[index] == "undefined") ? this.wpmembersManipulatedCsvHeader[index] = "" : this.wpmembersManipulatedCsvHeader[index]} onChange={(event)=>{this.wpmembersManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.wpmembersManipulatedCsvHeader[index]}", "type": "customfieldswpmember", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "customfieldswpmember");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                        <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a className="action-icon" data-toggle="tooltip" title="Formula">
                                                <i className="csv-icon-sum" onClick={(event)=>{if(this.wpmembersChoosedHeaderManipulation[index]) { this.wpmembersMathHeaderManipulation[index]="active"; this.wpmembersHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.wpmembersMathHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.wpmembersMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea class="form-control" value={(this.wpmembersManipulatedCsvHeader[index] == "undefined") ? this.wpmembersManipulatedCsvHeader[index] = "" : this.wpmembersManipulatedCsvHeader[index]} onChange={(event)=>{this.wpmembersManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.wpmembersManipulatedCsvHeader[index]}", "type": "customfieldswpmember", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "customfieldswpmember");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                        <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </td>
                                </tr>
                            )}) : '' }
                        </tbody>
                    </table>
        
                </div>
            </div> 
        </div>
        : "" }
        
                    
                {/* <!-- Custom Fields WP Member End--> */}

        {(this.context.showCustomFieldsMembersState) ?
        <div id="mapping-accordion">
            <div className="card csv-importer-panel mt50">
                {/* <!-- Custom Fields Members Starts--> */}
                <h1 className="card-header main-heading active" id="customfieldsmember-fields" onClick={()=>toggle_func('customfieldsmember-fields')}>{this.context.translateLanguage.CustomFieldsMemberFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="customfieldsmember-fields-body"  data-display={this.state.display}>
                    <table className="table table-mapping">
                        <thead>
                            <tr>
                                <th>{this.context.translateLanguage.WPFIELDS}</th>
                                <th>{this.context.translateLanguage.CSVHEADER}</th>
                                <th>{this.context.translateLanguage.Action}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(this.context.customFieldsMembersFields != null) ?
                            this.context.customFieldsMembersFields.map((corefields, index) => {
                                return(
                                    <tr>
                                    <td>
                                        <label className="wpfields">{corefields.label}</label>
                                        <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                    </td> 
                                    <td>
                                    <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "customfieldsmember");}} name="" id="">
                                        <optgroup label="WP Member Fields">
                                        <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "customfieldsmember", "selected_csv_header_type": "select"}`}>--select--</option>
                                        {this.context.csvHeaderFields.map((csvheaders) => {
                                                        return (<option selected={this.isMapped(corefields.name, csvheaders, "customfieldsmember")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "customfieldsmember", "selected_csv_header_type": "normal"}`}>
                                                                {csvheaders}
                                                                </option>);
                                        })}
                                       <option selected={this.isHeaderManipulation(corefields.name, index, "customfieldsmember")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.membersManipulatedCsvHeader[index]}", "type": "customfieldsmember", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                        </optgroup>
                                        </select>
                                    </td>
                                    <td className="action">
                                            <a className="action-icon" data-toggle="tooltip" title="Static">
                                                <i className="csv-icon-plus-square" onClick={(event)=>{if(this.membersChoosedHeaderManipulation[index]) { this.membersHeaderManipulation[index]="active"; this.membersMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.membersHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.membersHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea className="form-control" value={(this.membersManipulatedCsvHeader[index] == "undefined") ? this.membersManipulatedCsvHeader[index] = "" : this.membersManipulatedCsvHeader[index]} onChange={(event)=>{this.membersManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.membersManipulatedCsvHeader[index]}", "type": "customfieldsmember", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "customfieldsmember");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                        <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a className="action-icon" data-toggle="tooltip" title="Formula">
                                                <i className="csv-icon-sum" onClick={(event)=>{if(this.membersChoosedHeaderManipulation[index]) { this.membersMathHeaderManipulation[index]="active"; this.membersHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.membersMathHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.membersMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea class="form-control" value={(this.membersManipulatedCsvHeader[index] == "undefined") ? this.membersManipulatedCsvHeader[index] = "" : this.membersManipulatedCsvHeader[index]} onChange={(event)=>{this.membersManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.membersManipulatedCsvHeader[index]}", "type": "customfieldsmember", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "customfieldsmember");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                        <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </td>
                                </tr>
                            )}) : '' }
                        </tbody>
                    </table>
        
                </div>
            </div> 
        </div>
        : "" }
        
                    
                {/* <!-- Custom Fields Member End--> */}
        
        
        {(this.context.showProductMetaFieldsState) ?
        <div id="mapping-accordion">
            <div className="card csv-importer-panel mt50">
                {/* <!-- Product Meta Fields Starts--> */}
                <h1 className="card-header main-heading active" id="productmeta-fields" onClick={()=>toggle_func('productmeta-fields')}>{this.context.translateLanguage.ProductMetaFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="productmeta-fields-body"  data-display={this.state.display}>
                    <table className="table table-mapping">
                        <thead>
                            <tr>
                                <th>{this.context.translateLanguage.WPFIELDS}</th>
                                <th>{this.context.translateLanguage.CSVHEADER}</th>
                                <th>{this.context.translateLanguage.Action}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(this.context.productMetaFields != null) ?
                            this.context.productMetaFields.map((corefields, index) => {
                                return(
                                    <tr>
                                    <td>
                                        <label className="wpfields">{corefields.label}</label>
                                        <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                    </td> 
                                    <td>
                                    <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "productmetafields");}} name="" id="">
                                        <optgroup label="Product Meta Fields">
                                        <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "productmetafields", "selected_csv_header_type": "select"}`}>--select--</option>
                                        {this.context.csvHeaderFields.map((csvheaders) => {
                                                        return (<option selected={this.isMapped(corefields.name, csvheaders, "productmetafields")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "productmetafields", "selected_csv_header_type": "normal"}`}>
                                                                {csvheaders}
                                                                </option>);
                                        })}
                                       <option selected={this.isHeaderManipulation(corefields.name, index, "productmetafields")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.productmetaManipulatedCsvHeader[index]}", "type": "productmetafields", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                        </optgroup>
                                        </select>
                                    </td>
                                    <td className="action">
                                            <a className="action-icon" data-toggle="tooltip" title="Static">
                                                <i className="csv-icon-plus-square" onClick={(event)=>{if(this.productmetaChoosedHeaderManipulation[index]) { this.productmetaHeaderManipulation[index]="active"; this.productmetaMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.productmetaHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.productmetaHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea className="form-control" value={(this.productmetaManipulatedCsvHeader[index] == "undefined") ? this.productmetaManipulatedCsvHeader[index] = "" : this.productmetaManipulatedCsvHeader[index]} onChange={(event)=>{this.productmetaManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.productmetaManipulatedCsvHeader[index]}", "type": "productmetafields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "productmetafields");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                        <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a className="action-icon" data-toggle="tooltip" title="Formula">
                                                <i className="csv-icon-sum" onClick={(event)=>{if(this.productmetaChoosedHeaderManipulation[index]) { this.productmetaMathHeaderManipulation[index]="active"; this.productmetaHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.productmetaMathHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.productmetaMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea class="form-control" value={(this.productmetaManipulatedCsvHeader[index] == "undefined") ? this.productmetaManipulatedCsvHeader[index] = "" : this.productmetaManipulatedCsvHeader[index]} onChange={(event)=>{this.productmetaManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.productmetaManipulatedCsvHeader[index]}", "type": "productmetafields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "productmetafields");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                        <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </td>
                                </tr>
                            )}) : '' }
                        </tbody>
                    </table>
        
                </div>
            </div> 
        </div>
        : "" }
        
                    
                {/* <!-- Product Meta Fields End--> */}
        
        {(this.context.showWpEcomCustomFieldsState) ?
        <div id="mapping-accordion">
            <div className="card csv-importer-panel mt50">
                {/* <!-- Wp Ecom Custom Fields Starts--> */}
                <h1 className="card-header main-heading active" id="wpecomcustom-fields" onClick={()=>toggle_func('wpecomcustom-fields')}>{this.context.translateLanguage.WPECommerceCustomFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="wpecomcustom-fields-body"  data-display={this.state.display}>
                    <table className="table table-mapping">
                        <thead>
                            <tr>
                                <th>{this.context.translateLanguage.WPFIELDS}</th>
                                <th>{this.context.translateLanguage.CSVHEADER}</th>
                                <th>{this.context.translateLanguage.Action}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(this.context.wpEcomCustomFields != null) ?
                            this.context.wpEcomCustomFields.map((corefields, index) => {
                                return(
                                    <tr>
                                    <td>
                                        <label className="wpfields">{corefields.label}</label>
                                        <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                    </td> 
                                    <td>
                                    <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "wpecomcustomfields");}} name="" id="">
                                        <optgroup label="Wp Ecom Custom Fields">
                                        <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "wpecomcustomfields", "selected_csv_header_type": "select"}`}>--select--</option>
                                        {this.context.csvHeaderFields.map((csvheaders) => {
                                                        return (<option selected={this.isMapped(corefields.name, csvheaders, "wpecomcustomfields")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "wpecomcustomfields", "selected_csv_header_type": "normal"}`}>
                                                                {csvheaders}
                                                                </option>);
                                        })}
                                       <option selected={this.isHeaderManipulation(corefields.name, index, "wpecomcustomfields")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.wpecomManipulatedCsvHeader[index]}", "type": "wpecomcustomfields", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                        </optgroup>
                                        </select>
                                    </td>
                                    <td className="action">
                                            <a className="action-icon" data-toggle="tooltip" title="Static">
                                                <i className="csv-icon-plus-square" onClick={(event)=>{if(this.wpecomChoosedHeaderManipulation[index]) { this.wpecomHeaderManipulation[index]="active"; this.wpecomMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.wpecomHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.wpecomHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea className="form-control" value={(this.wpecomManipulatedCsvHeader[index] == "undefined") ? this.wpecomManipulatedCsvHeader[index] = "" : this.wpecomManipulatedCsvHeader[index]} onChange={(event)=>{this.wpecomManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.wpecomManipulatedCsvHeader[index]}", "type": "wpecomcustomfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "wpecomcustomfields");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                        <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a className="action-icon" data-toggle="tooltip" title="Formula">
                                                <i className="csv-icon-sum" onClick={(event)=>{if(this.wpecomChoosedHeaderManipulation[index]) { this.wpecomMathHeaderManipulation[index]="active"; this.wpecomHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.wpecomMathHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.wpecomMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea class="form-control" value={(this.wpecomManipulatedCsvHeader[index] == "undefined") ? this.wpecomManipulatedCsvHeader[index] = "" : this.wpecomManipulatedCsvHeader[index]} onChange={(event)=>{this.wpecomManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.wpecomManipulatedCsvHeader[index]}", "type": "wpecomcustomfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "wpecomcustomfields");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                        <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </td>
                                </tr>
                            )}) : '' }

                        </tbody>
                    </table>
        
                </div>
            </div> 
        </div>
        : "" }
                    
                {/* <!-- Wp Ecommerce Custom Fields End--> */}
        <div className="clearfix"></div>

        {(this.context.showEventsManagerFieldsState) ?
        <div id="mapping-accordion">
            <div className="card csv-importer-panel mt50">
                {/* <!-- Event Manager Fields Starts--> */}
                <h1 className="card-header main-heading active" id="eventsmanager-fields" onClick={()=>toggle_func('eventsmanager-fields')}>{this.context.translateLanguage.EventsManagerFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="eventsmanager-fields-body"  data-display={this.state.display}>
                    <table className="table table-mapping">
                        <thead>
                            <tr>
                                <th>{this.context.translateLanguage.WPFIELDS}</th>
                                <th>{this.context.translateLanguage.CSVHEADER}</th>
                                <th>{this.context.translateLanguage.Action}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(this.context.eventsManagerFields != null) ?
                            this.context.eventsManagerFields.map((corefields, index) => {
                                return(
                                    <tr>
                                    <td>
                                        <label className="wpfields">{corefields.label}</label>
                                        <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                    </td> 
                                    <td>
                                    <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "eventsmanagerfields");}} name="" id="">
                                        <optgroup label="Events Manager Fields">
                                        <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "eventsmanagerfields", "selected_csv_header_type": "select"}`}>--select--</option>
                                        {this.context.csvHeaderFields.map((csvheaders) => {
                                                        return (<option selected={this.isMapped(corefields.name, csvheaders, "eventsmanagerfields")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "eventsmanagerfields", "selected_csv_header_type": "normal"}`}>
                                                                {csvheaders}
                                                                </option>);
                                        })}
                                       <option selected={this.isHeaderManipulation(corefields.name, index, "eventsmanagerfields")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.eventsmanagerManipulatedCsvHeader[index]}", "type": "eventsmanagerfields", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                        </optgroup>
                                        </select>
                                    </td>
                                    <td className="action">
                                            <a className="action-icon" data-toggle="tooltip" title="Static">
                                                <i className="csv-icon-plus-square" onClick={(event)=>{if(this.eventsmanagerChoosedHeaderManipulation[index]) { this.eventsmanagerHeaderManipulation[index]="active"; this.eventsmanagerMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.eventsmanagerHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.eventsmanagerHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea className="form-control" value={(this.eventsmanagerManipulatedCsvHeader[index] == "undefined") ? this.eventsmanagerManipulatedCsvHeader[index] = "" : this.eventsmanagerManipulatedCsvHeader[index]} onChange={(event)=>{this.eventsmanagerManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.eventsmanagerManipulatedCsvHeader[index]}", "type": "eventsmanagerfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "eventsmanagerfields");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                        <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a className="action-icon" data-toggle="tooltip" title="Formula">
                                                <i className="csv-icon-sum" onClick={(event)=>{if(this.eventsmanagerChoosedHeaderManipulation[index]) { this.eventsmanagerMathHeaderManipulation[index]="active"; this.eventsmanagerHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.eventsmanagerMathHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.eventsmanagerMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea class="form-control" value={(this.eventsmanagerManipulatedCsvHeader[index] == "undefined") ? this.eventsmanagerManipulatedCsvHeader[index] = "" : this.eventsmanagerManipulatedCsvHeader[index]} onChange={(event)=>{this.eventsmanagerManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.eventsmanagerManipulatedCsvHeader[index]}", "type": "eventsmanagerfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "eventsmanagerfields");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                        <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </td>
                                </tr>
                            )}) : '' }
                        </tbody>
                    </table>
        
                </div>
            </div> 
        </div>
        : "" }
                    
                {/* <!-- Event Manager Fields End--> */}
        <div className="clearfix"></div>

        {(this.context.showNextgenGalleryFieldsState) ?
        <div id="mapping-accordion">
            <div className="card csv-importer-panel mt50">
                {/* <!-- Nextgen Gallery Fields Starts--> */}
                <h1 className="card-header main-heading active" id="nextgengallery-fields" onClick={()=>toggle_func('nextgengallery-fields')}>{this.context.translateLanguage.NextGENGalleryFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="nextgengallery-fields-body"  data-display={this.state.display}>
                    <table className="table table-mapping">
                        <thead>
                            <tr>
                                <th>{this.context.translateLanguage.WPFIELDS}</th>
                                <th>{this.context.translateLanguage.CSVHEADER}</th>
                                <th>{this.context.translateLanguage.Action}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(this.context.nextgenGalleryFields != null) ?
                            this.context.nextgenGalleryFields.map((corefields, index) => {
                                return(
                                    <tr>
                                    <td>
                                        <label className="wpfields">{corefields.label}</label>
                                        <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                    </td> 
                                    <td>
                                    <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "nextgengalleryfields");}} name="" id="">
                                        <optgroup label="Nextgen Gallery Fields">
                                        <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "nextgengalleryfields", "selected_csv_header_type": "select"}`}>--select--</option>
                                        {this.context.csvHeaderFields.map((csvheaders) => {
                                                        return (<option selected={this.isMapped(corefields.name, csvheaders, "nextgengalleryfields")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "nextgengalleryfields", "selected_csv_header_type": "normal"}`}>
                                                                {csvheaders}
                                                                </option>);
                                        })}
                                       <option selected={this.isHeaderManipulation(corefields.name, index, "nextgengalleryfields")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.nextgengalleryManipulatedCsvHeader[index]}", "type": "nextgengalleryfields", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                        </optgroup>
                                        </select>
                                    </td>
                                    <td className="action">
                                            <a className="action-icon" data-toggle="tooltip" title="Static">
                                                <i className="csv-icon-plus-square" onClick={(event)=>{if(this.nextgengalleryChoosedHeaderManipulation[index]) { this.nextgengalleryHeaderManipulation[index]="active"; this.nextgengalleryMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.nextgengalleryHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.nextgengalleryHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea className="form-control" value={(this.nextgengalleryManipulatedCsvHeader[index] == "undefined") ? this.nextgengalleryManipulatedCsvHeader[index] = "" : this.nextgengalleryManipulatedCsvHeader[index]} onChange={(event)=>{this.nextgengalleryManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.nextgengalleryManipulatedCsvHeader[index]}", "type": "nextgengalleryfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "nextgengalleryfields");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                        <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a className="action-icon" data-toggle="tooltip" title="Formula">
                                                <i className="csv-icon-sum" onClick={(event)=>{if(this.nextgengalleryChoosedHeaderManipulation[index]) { this.nextgengalleryMathHeaderManipulation[index]="active"; this.nextgengalleryHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.nextgengalleryMathHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.nextgengalleryMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea class="form-control" value={(this.nextgengalleryManipulatedCsvHeader[index] == "undefined") ? this.nextgengalleryManipulatedCsvHeader[index] = "" : this.nextgengalleryManipulatedCsvHeader[index]} onChange={(event)=>{this.nextgengalleryManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.nextgengalleryManipulatedCsvHeader[index]}", "type": "nextgengalleryfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "nextgengalleryfields");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                        <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </td>
                                </tr>
                            )}) : '' }
                        </tbody>
                    </table>
        
                </div>
            </div> 
        </div>
        : "" }
                    
                {/* <!-- Nextgen Gallery Fields End--> */}
        <div className="clearfix"></div>

        {(this.context.showCmb2CustomFieldsState) ?
        <div id="mapping-accordion">
            <div className="card csv-importer-panel mt50">
                {/* <!-- Cmb2 Fields Starts--> */}
                <h1 className="card-header main-heading active" id="cmb2custom-fields" onClick={()=>toggle_func('cmb2custom-fields')}>{this.context.translateLanguage.CMB2CustomFields}<span className="csv-icon-angle-down float-right"></span></h1>
                <div className="card-body" id="cmb2custom-fields-body"  data-display={this.state.display}>
                    <table className="table table-mapping">
                        <thead>
                            <tr>
                                <th>{this.context.translateLanguage.WPFIELDS}</th>
                                <th>{this.context.translateLanguage.CSVHEADER}</th>
                                <th>{this.context.translateLanguage.Action}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {(this.context.cmb2CustomFields != null) ?
                            this.context.cmb2CustomFields.map((corefields, index) => {
                                return(
                                    <tr>
                                    <td>
                                        <label className="wpfields">{corefields.label}</label>
                                        <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                    </td> 
                                    <td>
                                    <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "cmb2customfields");}} name="" id="">
                                        <optgroup label="CMB2 Custom Fields">
                                        <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "cmb2customfields", "selected_csv_header_type": "select"}`}>--select--</option>
                                        {this.context.csvHeaderFields.map((csvheaders) => {
                                                        return (<option selected={this.isMapped(corefields.name, csvheaders, "cmb2customfields")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "cmb2customfields", "selected_csv_header_type": "normal"}`}>
                                                                {csvheaders}
                                                                </option>);
                                        })}
                                       <option selected={this.isHeaderManipulation(corefields.name, index, "cmb2customfields")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.cmb2ManipulatedCsvHeader[index]}", "type": "cmb2customfields", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                        </optgroup>
                                        </select>
                                    </td>
                                    <td className="action">
                                            <a className="action-icon" data-toggle="tooltip" title="Static">
                                                <i className="csv-icon-plus-square" onClick={(event)=>{if(this.cmb2ChoosedHeaderManipulation[index]) { this.cmb2HeaderManipulation[index]="active"; this.cmb2MathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.cmb2HeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.cmb2HeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea className="form-control" value={(this.cmb2ManipulatedCsvHeader[index] == "undefined") ? this.cmb2ManipulatedCsvHeader[index] = "" : this.cmb2ManipulatedCsvHeader[index]} onChange={(event)=>{this.cmb2ManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.cmb2ManipulatedCsvHeader[index]}", "type": "cmb2customfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "cmb2customfields");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                        <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a className="action-icon" data-toggle="tooltip" title="Formula">
                                                <i className="csv-icon-sum" onClick={(event)=>{if(this.cmb2ChoosedHeaderManipulation[index]) { this.cmb2MathHeaderManipulation[index]="active"; this.cmb2HeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                                <div className={`manipulation-screen ${(this.cmb2MathHeaderManipulation[index])}`}>
                                                    <span className="close" onClick={(event)=>{this.cmb2MathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                    <div className="form-group">
                                                        <textarea class="form-control" value={(this.cmb2ManipulatedCsvHeader[index] == "undefined") ? this.cmb2ManipulatedCsvHeader[index] = "" : this.cmb2ManipulatedCsvHeader[index]} onChange={(event)=>{this.cmb2ManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.cmb2ManipulatedCsvHeader[index]}", "type": "cmb2customfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "cmb2customfields");}} rows={index}></textarea>
                                                    </div>
                                                    <div className="csv-hint">
                                                        <b>{this.context.translateLanguage.HIN} :</b> {this.hintMathNoteHeaderManipulation}
                                                        <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </td>
                                </tr>
                            )}) : '' }
                        </tbody>
                    </table>
        
                </div>
            </div> 
        </div>
        : "" }
                    
                {/* <!-- Cmb2 Fields End--> */}
        <div className="clearfix"></div>




{ (this.context.showWordPressCustomFieldsState) ?
            <div className="card csv-importer-panel">
                {/* <!-- Wordpress Custom Fields Starts--> */}
                <h1 className="card-header main-heading bg-white" id="wordpress-custom-fields" onClick={()=>{toggle_func('wordpress-custom-fields')}}>
                    {this.context.translateLanguage.WordPressCustomFields} <span class="csv-icon-angle-down float-right active"></span></h1>
                <div className="card-body" id="wordpress-custom-fields-body"  data-display={this.state.display}>
                {(this.context.showWordPressCustomFieldsState) ?
                <table className="table table-mapping">
                    <thead>
                        <tr>
                            <th>{this.context.translateLanguage.WPFIELDS}</th>
                            <th>{this.context.translateLanguage.CSVHEADER}</th>
                            <th>{this.context.translateLanguage.Action}</th>
                        </tr>
                    </thead>
                    <tbody>
                        {(this.context.wordPressCustomFields != null) ?
                        this.context.wordPressCustomFields.map((corefields, index) => {
                            return(
                                
                        <tr>
                            <td>
                                <label className="wpfields">{corefields.label}</label>
                                <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                            </td> 
                            <td>
                            <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "wordpresscustomfields");}} name="" id="">
                                <optgroup label="-select-">
                                <option value={`{"wp_name":"${corefields.name}","csv_header":"","type":"wordpresscustomfields"}`}>--select--</option>
                                {this.context.csvHeaderFields.map((csvheaders) => {
                                                return (<option selected={this.isMapped(corefields.name, csvheaders, "wordpresscustomfields")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "wordpresscustomfields"}`}>
                                                        {csvheaders}
                                                        </option>);
                                        })}
                                </optgroup>
                                </select>
                            </td>
                            <td className="action">
                                        <a className="action-icon" data-toggle="tooltip" title="Static">
                                            <i className="csv-icon-plus-square" onClick={(event)=>{if(this.wordpresscustomfieldsChoosedHeaderManipulation[index]) { this.wordpresscustomfieldsHeaderManipulation[index]="active"; this.wordpresscustomfieldsMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.wordpresscustomfieldsHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.wordpresscustomfieldsHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea className="form-control" value={(this.wordpresscustomfieldsManipulatedCsvHeader[index] == "undefined") ? this.wordpresscustomfieldsManipulatedCsvHeader[index] = "" : this.wordpresscustomfieldsManipulatedCsvHeader[index]} onChange={(event)=>{this.wordpresscustomfieldsManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${this.context.wordPressCustomFields[index]}", "csv_header": "${this.wordpresscustomfieldsManipulatedCsvHeader[index]}", "type": "wordpresscustomfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "wordpresscustomfields");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                    <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                        <a className="action-icon" data-toggle="tooltip" title="Formula">
                                            <i className="csv-icon-sum" onClick={(event)=>{if(this.wordpresscustomfieldsChoosedHeaderManipulation[index]) { this.wordpresscustomfieldsMathHeaderManipulation[index]="active"; this.wordpresscustomfieldsHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.wordpresscustomfieldsMathHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.wordpresscustomfieldsMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                    <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                </td>
                        </tr>
                        )}) : '' }
                    </tbody>
                </table>
                : "" }
                
                
                
                {/* <!-- Wordpress Custom Fields Starts--> */}
                {/* <h1 class="card-header main-heading bg-white" id="wordpress-custom-fields" onClick={()=>{toggle_func('wordpress-custom-fields')}} >
                    {this.context.translateLanguage.WordPressCustomFields} <span class="csv-icon-angle-down float-right active"></span></h1>
                <div class="card-body" id="wordpress-custom-fields-body" data-display={this.state.display}>></div> */}
                <table class="table table-mapping" id="usercustfields">
                {/* <thead>
                    <tr>
                        <th>{this.context.translateLanguage.WPFIELDS}</th>
                        <th>{this.context.translateLanguage.CSVHEADER}</th>
                        <th>{this.context.translateLanguage.IsSerialized}</th>
                        <th>{this.context.translateLanguage.Action}</th>
                    </tr>
                </thead> */}
                <tbody>
                { this.context.totalCustomFields.map((customfields, index) => {
                    return (
                    <tr>
                        <td>
                            <label class="wpfields"><input type="text" value={this.context.wordPressUserCustomFieldsLabel[index]} class="form-control" onChange={(event)=>{this.onChangeWordPressUserCustomFieldsLabel(event.target.value, index)}} /></label>
                            <label class="sub-text">{`[Name: ${this.context.wordPressUserCustomFields[index]}]`} </label>

                        </td>
                        <td>
                        <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index , "wordpressusercustomfields");}} name="" id="">
                            <optgroup label="WordPress Custom Fields">
                            <option value={`{"wp_name": "${this.context.wordPressUserCustomFields[index]}", "csv_header": "", "type": "wordpressusercustomfields", "selected_csv_header_type": "select"}`}>--select--</option>
                            {this.context.csvHeaderFields.map((csvheaders) => {
                                            return (<option selected={this.isMapped(this.context.wordPressUserCustomFields[index], csvheaders, "wordpressusercustomfields")} value={`{ "wp_name": "${this.context.wordPressUserCustomFields[index]}","csv_header": "${csvheaders}", "type": "wordpressusercustomfields", "selected_csv_header_type": "normal"}`}>
                                                    {csvheaders}
                                                    </option>);
                            })}
                           <option selected={this.isHeaderManipulation(this.context.wordPressUserCustomFields[index], index, "wordpressusercustomfields")} value={`{"wp_name": "${this.context.wordPressUserCustomFields[index]}", "csv_header": "${this.wordpressusercustomfieldsManipulatedCsvHeader[index]}", "type": "wordpressusercustomfields", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                            </optgroup>
                            </select>
                        </td>
                        {/* <td>
                            <div class="form-check">
                                <label class="form-check-label">
                                    <input type="checkbox" class="form-check-input" name="" id="" value="checkedValue"
                                        checked />
                                </label>
                            </div>
                        </td> */}
                        <td className="action">
                                <a className="action-icon" data-toggle="tooltip" title="Static">
                                    <i className="csv-icon-plus-square" onClick={(event)=>{if(this.wordpressusercustomfieldsChoosedHeaderManipulation[index]) { this.wordpressusercustomfieldsHeaderManipulation[index]="active"; this.wordpressusercustomfieldsMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                    <div className={`manipulation-screen ${(this.wordpressusercustomfieldsHeaderManipulation[index])}`}>
                                        <span className="close" onClick={(event)=>{this.wordpressusercustomfieldsHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                        <div className="form-group">
                                            <textarea className="form-control" value={(this.wordpressusercustomfieldsManipulatedCsvHeader[index] == "undefined") ? this.wordpressusercustomfieldsManipulatedCsvHeader[index] = "" : this.wordpressusercustomfieldsManipulatedCsvHeader[index]} onChange={(event)=>{this.wordpressusercustomfieldsManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${this.context.wordPressUserCustomFields[index]}", "csv_header": "${this.wordpressusercustomfieldsManipulatedCsvHeader[index]}", "type": "wordpressusercustomfields", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "wordpressusercustomfields");}} rows={index}></textarea>
                                        </div>
                                        <div className="csv-hint">
                                            <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                            <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                        </div>
                                    </div>
                                </a>
                                <a className="action-icon" data-toggle="tooltip" title="Formula">
                                    <i className="csv-icon-sum" onClick={(event)=>{if(this.wordpressusercustomfieldsChoosedHeaderManipulation[index]) { this.wordpressusercustomfieldsMathHeaderManipulation[index]="active"; this.wordpressusercustomfieldsHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                    <div className={`manipulation-screen ${(this.wordpressusercustomfieldsMathHeaderManipulation[index])}`}>
                                        <span className="close" onClick={(event)=>{this.wordpressusercustomfieldsMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                        <div className="form-group">
                                        </div>
                                        <div className="csv-hint">
                                            <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                            <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                        </div>
                                    </div>
                                </a>
                                <a class="action-icon" data-toggle="tooltip" onClick={(event)=>{this.deleteUserCustomFields(index);}} title="Delete">
                                <i class="csv-icon-trash-2"></i>
                                </a>
                            </td>
                    </tr> 
                    )})}
                    <tr>
                        <td colspan="4" class="no-data text-center text-danger">{this.context.translateLanguage.NoCustomFieldsFound}</td>
                    </tr>
                </tbody>
            </table>
            
            <div class="float-right mb20"><a href="#" class="smack-btn smack-btn-primary" onClick={(event)=>{this.addCustomFields();}}>Add Custom Field</a></div>
                    {/* <div className="float-right mb20"><a href="#" className="smack-btn smack-btn-primary">Add Custom Field</a></div> */}
            </div>
            </div> 
            : "" }
            {/*<!-- WordPress Custom Fields Ends-->*/}

            {(this.context.showTermsAndTaxonomiesState) ?
            <div id="mapping-accordion">
            <div className="card csv-importer-panel">
                {/* <!-- Terms and Taxonomies Starts--> */}
                <h1 className="card-header main-heading bg-white" id="terms-taxonomies" onClick={()=>{toggle_func('terms-taxonomies')}}>{this.context.translateLanguage.TermsandTaxonomies}<span className="csv-icon-angle-down float-right active"></span></h1>
                <div className="card-body" id="terms-taxonomies-body"  data-display={this.state.display}>
                    <table className="table table-mapping">
                        <thead>
                            <tr>
                                <th>{this.context.translateLanguage.WPFIELDS}</th>
                                <th>{this.context.translateLanguage.CSVHEADER}</th>
                                <th>{this.context.translateLanguage.Action}</th>
                            </tr>
                        </thead>
                        <tbody>
                        {(this.context.termsAndTaxonomiesFields != null) ?
                        this.context.termsAndTaxonomiesFields.map((corefields, index) => {
                            return(
                                <tr>
                                <td>
                                    <label className="wpfields">{corefields.label}</label>
                                    <label className="sub-text">[{this.context.translateLanguage.Name}: {corefields.name}] </label>
                                </td> 
                                <td>
                                <select className="select" onChange={(event)=>{this.onSelectMappedFields.bind(this)(event.target.value, index, "termsandtaxonomies");}} name="" id="">
                                    <optgroup label="Terms and Taxonomies Fields">
                                    <option value={`{"wp_name": "${corefields.name}", "csv_header": "", "type": "termsandtaxonomies", "selected_csv_header_type": "select"}`}>--select--</option>
                                    {this.context.csvHeaderFields.map((csvheaders) => {
                                                    return (<option selected={this.isMapped(corefields.name, csvheaders, "termsandtaxonomies")} value={`{ "wp_name": "${corefields.name}","csv_header": "${csvheaders}", "type": "termsandtaxonomies", "selected_csv_header_type": "normal"}`}>
                                                            {csvheaders}
                                                            </option>);
                                    })}
                                   <option selected={this.isHeaderManipulation(corefields.name, index, "termsandtaxonomies")} value={`{"wp_name": "${corefields.name}", "csv_header": "${this.termsandtaxonomiesManipulatedCsvHeader[index]}", "type": "termsandtaxonomies", "selected_csv_header_type": "headermanipulation"}`}>Header Manipulation</option>
                                    </optgroup>
                                    </select>
                                </td>
                                <td className="action">
                                        <a className="action-icon" data-toggle="tooltip" title="Static">
                                            <i className="csv-icon-plus-square" onClick={(event)=>{if(this.termsandtaxonomiesChoosedHeaderManipulation[index]) { this.termsandtaxonomiesHeaderManipulation[index]="active"; this.termsandtaxonomiesMathHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.termsandtaxonomiesHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.termsandtaxonomiesHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea className="form-control" value={(this.termsandtaxonomiesManipulatedCsvHeader[index] == "undefined") ? this.termsandtaxonomiesManipulatedCsvHeader[index] = "" : this.termsandtaxonomiesManipulatedCsvHeader[index]} onChange={(event)=>{this.termsandtaxonomiesManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.termsandtaxonomiesManipulatedCsvHeader[index]}", "type": "termsandtaxonomies", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "termsandtaxonomies");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintNoteHeaderManipulation}
                                                    <div className="d-block"><b>{this.context.translateLanguage.Example} : </b> {this.exampleNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                        <a className="action-icon" data-toggle="tooltip" title="Formula">
                                            <i className="csv-icon-sum" onClick={(event)=>{if(this.termsandtaxonomiesChoosedHeaderManipulation[index]) { this.termsandtaxonomiesMathHeaderManipulation[index]="active"; this.termsandtaxonomiesHeaderManipulation[index]=""; this.forceUpdate();} else{window.alert("Choose Header Manipulation in the Dropdown");}}}></i>
                                            <div className={`manipulation-screen ${(this.termsandtaxonomiesMathHeaderManipulation[index])}`}>
                                                <span className="close" onClick={(event)=>{this.termsandtaxonomiesMathHeaderManipulation[index]=""; this.forceUpdate(); }}>&times;</span>
                                                <div className="form-group">
                                                    <textarea class="form-control" value={(this.termsandtaxonomiesManipulatedCsvHeader[index] == "undefined") ? this.termsandtaxonomiesManipulatedCsvHeader[index] = "" : this.termsandtaxonomiesManipulatedCsvHeader[index]} onChange={(event)=>{this.termsandtaxonomiesManipulatedCsvHeader[index] = event.target.value; var value= `{"wp_name": "${corefields.name}", "csv_header": "${this.termsandtaxonomiesManipulatedCsvHeader[index]}", "type": "termsandtaxonomies", "selected_csv_header_type": "headermanipulation"}`; this.forceUpdate(); this.onSelectMappedFields.bind(this)(value, index, "termsandtaxonomiescustomfields");}} rows={index}></textarea>
                                                </div>
                                                <div className="csv-hint">
                                                    <b>{this.context.translateLanguage.HINT} :</b> {this.hintMathNoteHeaderManipulation}
                                                    <div class="d-block"><b>{this.context.translateLanguage.Example} :</b> {this.exampleMathNoteHeaderManipulation} </div>
                                                </div>
                                            </div>
                                        </a>
                                    </td>
                            </tr>
                        )}) : '' }
                        </tbody>
                    </table>

                </div>
            </div> 
            </div>
            : "" }
            {/* <!-- Terms and Taxonomies End--> */}

            

            <div className="card csv-importer-panel">
                {/* <!-- Media Upload Starts--> */}
                <h1 className="card-header main-heading active" id="media-upload">{this.context.translateLanguage.MediaUploadFields}</h1>
                <div className="card-body" id="media-upload-body"  data-display='block'>
                <div className="d-flex justify-content-center mb20"><a href="#" className="smack-btn smack-btn-primary">{this.context.translateLanguage.UploadMedia}</a></div>
                    <FilePond acceptedFileTypes={['zip']} allowMultiple={false} maxFiles={1} server={{
                                process: (fieldname, file, metadata, load, error, progress, abort) => {
                                        const formData = new FormData();
                                        formData.append('zipFile', file, file.name);
                                        formData.append('action', 'zip_upload');

                                        console.log(' file name '+fieldname);


                                        const request = new XMLHttpRequest();
                                        request.open('POST', ajaxurl);
                                        console.log('sending file to '+ajaxurl);
                                        console.log(request);
                                        request.upload.onprogress = (e) => {
                                            progress(e.lengthComputable, e.loaded, e.total);
                                    };

                                    request.onload = function() {
                                        if (request.status >= 200 && request.status < 300) {
                                        // 	the load method accepts either a string (id) or an object
                                        load(JSON.parse(request.responseText));
                                        //console.log(JSON.parse(request.responseText));
                                        var response = JSON.parse(request.responseText);
                                        MappingSection.imageUploadResponse = response;
                                        console.log('response came');
                                        console.log(MappingSection.imageUploadResponse);
                                            if(MappingSection.imageUploadResponse.success) {
                                                    MappingSection.imageFileNames = MappingSection.imageUploadResponse.filename;
                                                    MappingSection.showUploadedImageList = true;
                                                    MappingSection.activateMediaHandling=true;
                                                    console.log('success');
                                                    console.log(MappingSection.showUploadedImageList);  
                                            }
                                            else {
                                                MappingSection.activateMediaHandling=false;
                                                MappingSection.showUploadedImageList = false;
                                                alert(MappingSection.imageUploadResponse.message);

                                            }
                                        }
                                        
                                        else {
                                            console.log('oh no');
                                            // 	Can call the error method if something is wrong, should exit after
                                            error('oh no');
                                        }
                                    };
                                    request.send(formData);
                                            
                                    // Should expose an abort method so the request can be cancelled
                                    return {
                                        abort: () => {
                                            // This function is entered if the user has tapped the cancel button
                                            request.abort();
                                            // Let FilePond know the request has been cancelled
                                            abort();
                                        }
                                    };
                                }
                            }
                        }
                        // onprocessfile={(file)=>{console.log('Image File Zip uploaded'); this.context.getFileName(MappingSection.ImageUploadResponse.filename); var fileName = MappingSection.imageUploadResponse.filename; var fileNameWithoutExtension = fileName.slice(0,-4); this.context.getTemplateName(fileNameWithoutExtension); this.context.saveTemplateName(this.context.templateName);  this.context.setSelectedType(UploadFromDesktop.filePondResponse.selectedtype); this.setState({postType: UploadFromDesktop.filePondResponse.posttype, taxonomy: UploadFromDesktop.filePondResponse.taxonomy}); this.setState({showImportRecord: true});}}
                        onprocessfile={(file)=>{console.log('Image File Zip uploaded'); this.setState({showUploadedFiles: MappingSection.showUploadedImageList})}}
                        onremovefile={(file)=>{MappingSection.activateMediaHandling=false; this.setState({showUploadedFiles: false})}}
                />
                </div>
                </div>
                
                
                {(this.state.showUploadedFiles) && (!this.context.fromTemplateMappingSection) ?
                <div className="card csv-importer-panel">
                <h1 className="card-header main-heading active" id="media-upload-list-files">{this.context.translateLanguage.UploadedListofFiles}</h1>
                    <div className="card-body" id="media-upload-list-files-body"  data-display='block'>
                        <div className="d-flex justify-content-center mb20"><a href="#" className="smack-btn smack-btn-primary" data-toggle="modal" data-target="#upload_media">{this.context.translateLanguage.UploadedMediaFileLists}</a></div>
                         
                     </div>
                </div>
                : ""}


            {((this.context.fromTemplateMappingSection) && (this.context.activateUseExistingMappingState)) ?
            <div>
            <div className="col-md-12 text-center mt30">
            <label>
                  {this.context.translateLanguage.SavethismappingasTemplate} 
            </label>
            <input type="text" className="form-control ml10 d-inline w-25" value={this.context.editedTemplateNameInManagerSection} onChange={(event)=>{ this.context.selectedEditedTemplateInManager(event.target.value); }} />
            </div>
            {/* <div className="col-md-12 mt30 p0"> */}
               
            <div className="float-right mb20"><a href="#" className="smack-btn smack-btn-primary" onClick={(event)=>{this.sendMappedFields.bind(this)();}}>{this.context.translateLanguage.Save}</a></div>
            </div>
            : ""}
                   
                
        { (!this.context.fromTemplateMappingSection) ?
        <div>
            <div className="col-md-12 text-center mt30">
                <input type="checkbox" className="mr10" value="" id="saveMappingCheck" checked={this.state.display1} onClick={(event)=>{ if(event.target.checked) { this.setState({display1: true}); } else { this.setState({display1: false }); }}} />
                <label>
                    {(this.context.activateUseExistingMappingState) ? `${this.context.translateLanguage.Doyouneedtoupdatethecurrentmapping}` : `${this.context.translateLanguage.Savethecurrentmappingasnewtemplate}` }
                </label>
                <input type="text" className="form-control ml10 d-inline w-25" disabled={!this.state.display1} value={this.state.templateName} onChange={(event)=>{ this.setState({ templateName: event.target.value})}}/>
                </div>
                <div className="col-md-12 mt30 p0">
                    <div className="float-left">
                        <a href="#" className="smack-btn btn-default" onClick={(event)=>{this.context.changeActivateMappingSectionState(false); this.context.setActivateDashboard(true);}}>{this.context.translateLanguage.Back}</a>
                    </div>
                <div className="float-right mb20"><a href="#" className="smack-btn smack-btn-primary" onClick={(event)=>{this.sendMappedFields.bind(this)();}}>{this.context.translateLanguage.Continue}</a></div>
                </div>
        </div> : "" }
         
    
        {/* <!-- Container End-->  */}
        <div className="clearfix"></div>
    

         {/* <!-- upload media model start --> */}
 <div id="upload_media" className="modal fade payment_modal" role="dialog">
            <div className="modal-dialog modal-lg modal-dialog-centered">
          
              {/* <!-- Modal content--> */}
              <div className="modal-content">
                <div className="modal-header">
                  <button type="button" className="close" data-dismiss="modal">&times;</button>
                </div>
                <div className="modal-body my-2">
                  <h1 className="main-heading text-center">Media gallery.zip</h1>
                  <div className="importing-details">
                      <div className="import-progress">
                          <div className="progress-loading">70% to Complete</div>
                      </div>
                  </div>
          
                  <div className="progress mt10 mb40">
                      <div className="progress-bar" role="progressbar" style={{width: ""+"100%"}} aria-valuenow="10" aria-valuemin="0"
                       aria-valuemax="100"></div>
                  </div>
                 <table className="table table-striped"> 
                 {/* <!-- Save Template Table start--> */}
                  <thead>
                      <tr>
                          <th>{this.context.translateLanguage.Name}</th>
                          <th>{this.context.translateLanguage.Size}</th>
                          <th class="text-center">{this.context.translateLanguage.Action}</th>
                      </tr>
                  </thead>
                  <tbody>
                {MappingSection.imageFileNames.map((filename,index) => {
                    return(
                      <tr>
                          <td>{filename}</td>
                          <td>2MB</td>
                          <td><a className="action-icon" onClick={(event)=>{this.deleteImage(filename, index);}} data-toggle="tooltip" title="Delete">
                             <i className="csv-icon-trash-2"></i>
                            </a></td>
                      </tr>
                    )})}
                       
                  </tbody>
              </table>
                </div>
              </div>
          
            </div>
          </div>
            {/* <!-- upload media model closed --> */}                                                                                       
        </div>
                                                                                                                 
        )
    }
}


export default MappingSection;
