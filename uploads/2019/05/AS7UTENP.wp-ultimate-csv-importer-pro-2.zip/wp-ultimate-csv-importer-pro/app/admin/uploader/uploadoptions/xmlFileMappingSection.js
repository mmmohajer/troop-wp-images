import React, { Component } from 'react';
import {AppContext} from '../../../context.js'
import { Draggable, Droppable } from 'react-drag-and-drop'
import axios from 'axios';

class XmlFileMappingSection extends Component {
    static contextType = AppContext;
    constructor(props) {
        super(props);
		this.state = {
            loading: false,
            check: '',
            mappedWordPressCoreFields: [],
            mappedAcfFreeFields: [],
            mappedAcfProFields: [],
            mappedAcfGroupFields: [],
            mappedAcfRepeaterFields: [],
            mappedTypesFields: [],
            mappedPodsFields: [],
            mappedCustomFieldSuiteFields: [],
            mappedAllInOneSeoFields: [],
            mappedYoastSeoFields: [],
            mappedBillingAndShippingFields: [],
            mappedWpMemberFields: [],
            mappedMemberFields: [],
            mappedProductMetaFields: [],
            mappedWpEcomFields: [],
            mappedEventsManagerFields: [],
            mappedNextgenGalleryFields: [],
            mappedCmb2Fields: [],
            mappedTermsAndTaxonomiesFields: [],
            indexed: '',
            advancedMode: "",
            dragAndDrop: "active",
            initialRowSize: 1,
            acfFree: '',
            acfPro: '',
            acfGroup: '',
            acfRepeater: '', 
            types: '', 
            pods: '', 
            cfs: '', 
            allInOneSeo: '', 
            yoastSeo: '', 
            billingAndShipping: '', 
            wpMember: '', 
            member: '', 
            productMeta: '', 
            wpEcom: '', 
            eventsManager: '', 
            nextGenGallery: '', 
            cmb2: '',
            termsAndTaxonomies: '',
            displayBlock: "block",
            displayNone: "none",
            display1: true,
            templateName: '',
            
        }
        this.mappedFields = [];
        this.csvHeaders = [];
        this.csvHeadersValue = [];
        this.csvInformation = [];
        this.core = {};
        this.acffree = {};
        this.acfpro = {};
        this.acfgroup = {};
        this.acfrepeater = {};
        this.types = {};
        this.pods = {};
        this.customfieldsuite = {};
        this.allinoneseo = {};
        this.yoastseo = {};
        this.billingandshipping = {};
        this.wpmember = {};
        this.member = {};
        this.productmeta = {};
        this.mappedElements = {};
        this.wpecom = {};
        this.eventsmanager = {};
        this.nextgengallery = {};
        this.cmb2 = {};
        this.termsandtaxonomies = {};
        this.onDropState = false;
        this.unmount = false;
        this.handleScroll = this.handleScroll.bind(this);
    }

    componentDidMount() {
        this.context.setSelectedTabCookies("import-update");
        window.addEventListener('scroll', this.handleScroll);
        this.context.fromDragAndDropMappingSection(true);
        this.setState({ templateName: this.context.saveTemplateNames })
        this.getCsvFields(this.state.initialRowSize);
        (this.context.showAcfFreeFieldsState) ? this.setState({acfFree: 'active'}) : (this.context.showAcfProFieldsState) ? this.setState({acfPro: 'active'}) : (this.context.showAcfGroupFieldsState) ? this.setState({acfGroup: 'active'}) : (this.context.showAcfRepeaterFieldsState) ? this.setState({acfRepeater: 'active'}) : (this.context.showTypesFieldsState) ? this.setState({types: 'active'}) : (this.context.showPodsFieldsState) ? this.setState({pods: 'active'}) : (this.context.showCustomFieldSuiteState) ? this.setState({cfs: 'active'}) : (this.context.showAllInOneSeoFieldsState) ? this.setState({allInOneSeo: 'active'}) : (this.context.showYoastSeoFieldsState) ? this.setState({yoastSeo: 'active'}) : (this.context.showBillingAndShippingInformationState) ? this.setState({billingAndShipping: 'active'}) : (this.context.showCustomFieldsWpMembersState) ? this.setState({wpMember: 'active'}) : (this.context.showCustomFieldsMembersState) ? this.setState({member: 'active'}) : (this.context.showProductMetaFieldsState) ?  this.setState({productMeta: 'active'}) : (this.context.showWpEcomCustomFieldsState) ? this.setState({wpEcom: 'active'}) : (this.context.showEventsManagerFieldsState) ?  this.setState({eventsManager: 'active'}) : (this.context.showNextgenGalleryFieldsState) ? this.setState({nextGenGallery: 'active'}) : (this.context.showCmb2CustomFieldsState) ?  this.setState({cmb2: 'active'}) : "" 
    }

    componentWillUnmount() {
        window.removeEventListener('scroll', this.handleScroll);
    };

    handleScroll(event) {
        var sidebar = document.getElementById('mapping-sidebar');
        var mapping_section_height = document.getElementById('mapping-accordion').offsetHeight;
        var limit_height = mapping_section_height - 300;

        if(event.pageY > 200){
            sidebar.classList.add("mapping-sidebar-fixed");

            if(event.pageY > limit_height){
                sidebar.classList.add("fixed-bottom-position");
            } else{
                sidebar.classList.remove("fixed-bottom-position");
            }
        } else{
            sidebar.classList.remove("mapping-sidebar-fixed");
        }
    };

    async getCsvFields(rownumber) {
        var formData = new FormData();
        formData.set('action','get_parse_xml');
        formData.set('Row', rownumber);
        if(!this.context.fromTemplateMappingSection) {
            formData.set('HashKey',this.context.hashKey);
            //formData.set('filename', this.context.fileName);           
        }
        if((this.context.fromTemplateMappingSection) && (this.context.activateUseExistingMappingState)) {
            formData.set('templatename', this.context.selectedTemplateNameInManagerSection);
            console.log("Selected Template Name", this.context.selectedTemplateNameInManagerSection);
        }
        

        this.setState({
            loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);
        if (response.status == 200)	{
            if(response.data.success) {
                console.log('csv  fields received successfully');
                this.csvHeaders = [];
                this.csvHeadersValue = [];
                this.csvInformation = [];

                for(var i=0; i<response.data.Headers.length; i++) {
                    this.csvHeaders.push(response.data.Headers[i]);
                    this.csvHeadersValue.push(response.data.Values[i]);
                    this.setState({totalCsvRows: response.data.total_rows})
                }               
                for(var i=0; i<response.data.Headers.length; i++) {
                   this.csvInformation.push({csvHeaders : response.data.Headers[i], csvValues: response.data.Values[i]});
                }
                console.log(this.csvHeaders);
                console.log(this.csvHeadersValue);
                console.log(this.csvInformation);
                this.forceUpdate();
            }
            
        }
    }

    setAlreadyMappedFields(fields, type, index, csvheader) {
        if(type === "core") {
            this.state.mappedWordPressCoreFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedWordPressCoreFields[index], type, index);
            return this.state.mappedWordPressCoreFields[index];
        }
        if(type === "acffree") {
            this.state.mappedAcfFreeFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedAcfFreeFields[index], type, index);
            return this.state.mappedAcfFreeFields[index];
        }
        if(type === "acfpro") {
            this.state.mappedAcfProFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedAcfProFields[index], type, index);
            return this.state.mappedAcfProFields[index];
        }
        if(type === "acfgroup") {
            this.state.mappedAcfGroupFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedAcfGroupFields[index], type, index);
            return this.state.mappedAcfGroupFields[index];
        }
        if(type === "acfrepeater") {
            this.state.mappedAcfRepeaterFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedAcfRepeaterFields[index], type, index);
            return this.state.mappedAcfRepeaterFields[index];
        }
        if(type === "types") {
            this.state.mappedTypesFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedTypesFields[index], type, index);
            return this.state.mappedTypesFields[index];
        }
        if(type === "pods") {
            this.state.mappedPodsFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedPodsFields[index], type, index);
            return this.state.mappedPodsFields[index];
        }
        if(type === "customfieldsuite") {
            this.state.mappedCustomFieldSuiteFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedCustomFieldSuiteFields[index], type, index);
            return this.state.mappedCustomFieldSuiteFields[index];
        }
        if(type === "allinoneseo") {
            this.state.mappedAllInOneSeoFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedAllInOneSeoFields[index], type, index);
            return this.state.mappedAllInOneSeoFields[index];
        }
        if(type === "yoastseo") {
            this.state.mappedYoastSeoFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedYoastSeoFields[index], type, index);
            return this.state.mappedYoastSeoFields[index];
        }
        if(type === "billingandshipping") {
            this.state.mappedBillingAndShippingFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedBillingAndShippingFields[index], type, index);
            return this.state.mappedBillingAndShippingFields[index];
        }
        if(type === "wpmember") {
            this.state.mappedWpMemberFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedWpMemberFields[index], type, index);
            return this.state.mappedWpMemberFields[index];
        }
        if(type === "member") {
            this.state.mappedMemberFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedMemberFields[index], type, index);
            return this.state.mappedMemberFields[index];
        }
        if(type === "productmeta") {
            this.state.mappedProductMetaFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedProductMetaFields[index], type, index);
            return this.state.mappedProductMetaFields[index];
        }
        if(type === "wpecom") {
            this.state.mappedWpEcomFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedWpEcomFields[index], type, index);
            return this.state.mappedWpEcomFields[index];
        }
        if(type === "eventsmanager") {
            this.state.mappedEventsManagerFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedEventsManagerFields[index], type, index);
            return this.state.mappedEventsManagerFields[index];
        }
        if(type === "nextgengallery") {
            this.state.mappedNextgenGalleryFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedNextgenGalleryFields[index], type, index);
            return this.state.mappedNextgenGalleryFields[index];
        }
        if(type === "cmb2") {
            this.state.mappedCmb2Fields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedCmb2Fields[index], type, index);
            return this.state.mappedCmb2Fields[index];
        }
        
        if(type === "termsandtaxonomies") {
            this.state.mappedTermsAndTaxonomiesFields[index] = csvheader;
            this.setMappedFields(fields, this.state.mappedTermsAndTaxonomiesFields[index], type, index);
            return this.state.mappedTermsAndTaxonomiesFields[index];
        }
    }

    async sendMappedFields() {
        var mappedMethod = "advanced";
        var formData = new FormData();
        formData.set('action','saveMappedFields');
        formData.set('HashKey',this.context.hashKey);
        formData.set('Types', this.context.selectedType);
        formData.set('TemplateName', (this.context.activateUseExistingMappingState) ? this.context.saveTemplateNames : (this.state.display1) ? this.state.templateName : "");
        formData.set('UseTemplateState', JSON.stringify(this.context.activateUseExistingMappingState));
        formData.set('NewTemplate', (!this.context.activateXmlFileMappingSection) ? "" : (this.state.display1) ? this.state.templateName  : "");
        formData.set('MappedFields', JSON.stringify(this.mappedElements));
        formData.set('MappingType', mappedMethod);
        //console.log(JSON.stringify(this.mappedElements));
        

        this.setState({ loading : true, });
        
        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);
        
        if (response.status == 200)	{
            if(response.data.success) {
                // this.context.saveMappedFields(this.mappedFields);
                // this.mappedFields = [];
                this.context.changeActivateXmlFileMappingSectionState(false);
                this.context.setActivateDashboard(false);
                (this.context.fromTemplateMappingSection) ?  this.context.changeActivateTemplateSectionState(true) : this.context.changeActivateMediaHandlingSection(true)
            }
            else {
                alert(response.data.message);
            } 
        }

    
    }

    setMappedFields(fieldname, csvheader, type, index) {
        
        if(type === "core") {
            this.core[fieldname] = csvheader;
            this.mappedElements['CORE'] = this.core; 
                   
        }
        if(type === "acffree") {
            this.acffree[fieldname] = csvheader;
            this.mappedElements['ACF'] = this.acffree;
        }
        if(type === "acfpro") {
            this.acfpro[fieldname] = csvheader;
            this.mappedElements['ACF'] = this.acfpro;
        }
        if(type === "acfgroup") {
            this.acfgroup[fieldname] = csvheader;
            this.mappedElements['GF'] = this.acfgroup;
        }
        if(type === "acfrepeater") {
            this.acfrepeater[fieldname] = csvheader;
            this.mappedElements['RF'] = this.acfrepeater;
        }
        if(type === "types") {
            this.types[fieldname] = csvheader;
            this.mappedElements['TYPES'] = this.types;
        }
        if(type === "pods") {
            this.pods[fieldname] = csvheader;
            this.mappedElements['PODS'] = this.pods;
        }
        if(type === "customfieldsuite") {
            this.customfieldsuite[fieldname] = csvheader;
            this.mappedElements['CFS'] = this.customfieldsuite;
        }
        if(type === "allinoneseo") {
            this.allinoneseo[fieldname] = csvheader;
            this.mappedElements['AIOSEO'] = this.allinoneseo;
        }
        if(type === "yoastseo") {
            this.yoastseo[fieldname] = csvheader;
            this.mappedElements['YOASTSEO'] = this.yoastseo;
        }
        if(type === "billingandshipping") {
            this.billingandshipping = csvheader;
            this.mappedElements['BSI'] = this.billingandshipping;
        }
        if(type === "wpmember") {
            this.wpmember = csvheader;
            this.mappedElements['WPMEMBERS'] = this.wpmember;
        }
        if(type === "member") {
            this.member = csvheader;
            this.mappedElements['MULTIROLE'] = this.member;
        }
        if(type === "productmeta") {
            this.productmeta = csvheader;
            this.mappedElements['ECOMMETA'] = this.productmeta;
        }
        if(type === "wpecom") {
            this.wpecom = csvheader;
            this.mappedElements['WPECOMMETA'] = this.wpecom;
        }
        if(type === "eventsmanager") {
            this.eventsmanager = csvheader;
            this.mappedElements['EVENTS'] = this.eventsmanager;
        }
        if(type === "nextgengallery") {
            this.nextgengallery = csvheader;
            this.mappedElements['NEXTGEN'] = this.nextgengallery;
        }
        if(type === "cmb2") {
            this.cmb2 = csvheader;
            this.mappedElements['CMB2'] = this.cmb2;
        }
        if(type === "termsandtaxonomies") {
            this.termsandtaxonomies = csvheader;
            this.mappedElements['TERMS'] = this.cmb2;
        }
    }

    onWordPressCoreDrop(data, fields, index) {
        var type = "core";
        
        if(this.state.mappedWordPressCoreFields[index] !== undefined){
            this.state.mappedWordPressCoreFields[index]=`${(this.state.mappedWordPressCoreFields[index])}{${(data.csvheader)}}`
            this.setState({mappedWordPressCoreFields: this.state.mappedWordPressCoreFields});
            this.setMappedFields(fields, this.state.mappedWordPressCoreFields[index], type, index);
        }
        if(this.state.mappedWordPressCoreFields[index] === undefined) {
            this.state.mappedWordPressCoreFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedWordPressCoreFields: this.state.mappedWordPressCoreFields});
            this.setMappedFields(fields, this.state.mappedWordPressCoreFields[index], type, index);
        }
    }

    onAcfFreeDrop(data, fields, index) {
        var type = "acffree"
        if(this.state.mappedAcfFreeFields[index] !== undefined){
            this.state.mappedAcfFreeFields[index]=`${(this.state.mappedAcfFreeFields[index])}{${(data.csvheader)}}`
            this.setState({mappedAcfFreeFields: this.state.mappedAcfFreeFields});
            this.setMappedFields(fields, this.state.mappedAcfFreeFields[index], type, index);
        }
        if(this.state.mappedAcfFreeFields[index] === undefined) {
            this.state.mappedAcfFreeFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedAcFreeFields: this.state.mappedAcfFreeFields});
            this.setMappedFields(fields, this.state.mappedAcfFreeFields[index], type, index);
        }
    }

    onAcfProDrop(data, fields, index) {
        var type = "acfpro";
        if(this.state.mappedAcfProFields[index] !== undefined){
            this.state.mappedAcfProFields[index]=`${(this.state.mappedAcfProFields[index])}{${(data.csvheader)}}`
            this.setState({mappedAcfProFields: this.state.mappedAcfProFields});
            this.setMappedFields(fields, this.state.mappedAcfProFields[index], type, index);
        }
        if(this.state.mappedAcfProFields[index] === undefined) {
            this.state.mappedAcfProFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedAcfProFields: this.state.mappedAcfProFields});
            this.setMappedFields(fields, this.state.mappedAcfProFields[index], type, index);
        }
    }

    onAcfGroupDrop(data, fields, index) {
        var type = "acfgroup";
        if(this.state.mappedAcfGroupFields[index] !== undefined){
            this.state.mappedAcfGroupFields[index]=`${(this.state.mappedAcfGroupFields[index])}{${(data.csvheader)}}`
            this.setState({mappedAcfGroupFields: this.state.mappedAcfProFields});
            this.setMappedFields(fields, this.state.mappedAcfGroupFields[index], type, index);
        }
        if(this.state.mappedAcfGroupFields[index] === undefined) {
            this.state.mappedAcfGroupFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedAcfGroupFields: this.state.mappedAcfGroupFields});
            this.setMappedFields(fields, this.state.mappedAcfGroupFields[index], type, index);
        }
    }

    onAcfRepeaterDrop(data, fields, index) {
        var type = "acfrepeater";
        if(this.state.mappedAcfRepeaterFields[index] !== undefined){
            this.state.mappedAcfRepeaterFields[index] =`${(this.state.mappedAcfRepeaterFields[index])}{${(data.csvheader)}}`
            this.setState({mappedAcfRepeaterFields: this.state.mappedAcfRepeaterFields});
            this.setMappedFields(fields, this.state.mappedAcfRepeaterFields[index], type, index);
        }
        if(this.state.mappedAcfRepeaterFields[index] === undefined) {
            this.state.mappedAcfRepeaterFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedAcfRepeaterFields: this.state.mappedAcfRepeaterFields});
            this.setMappedFields(fields, this.state.mappedAcfRepeaterFields[index], type, index);
        }
    }

    onTypesDrop(data, fields, index) {
        var type = "types";
        if(this.state.mappedTypesFields[index] !== undefined){
            this.state.mappedTypesFields[index]=`${(this.state.mappedTypesFields[index])}{${(data.csvheader)}}`
            this.setState({mappedTypesFields: this.state.mappedTypesFields});
            this.setMappedFields(fields, this.state.mappedTypesFields[index], type, index);
        }
        if(this.state.mappedTypesFields[index] === undefined) {
            this.state.mappedTypesFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedTypesFields: this.state.mappedTypesFields});
            this.setMappedFields(fields, this.state.mappedTypesFields[index], type, index);
        }
    }

    onPodsDrop(data, fields, index) {
        var type = "pods";
        if(this.state.mappedPodsFields[index] !== undefined){
            this.state.mappedPodsFields[index]=`${(this.state.mappedPodsFields[index])}{${(data.csvheader)}}`
            this.setState({mappedPodsFields: this.state.mappedPodsFields});
            this.setMappedFields(fields, this.state.mappedPodsFields[index], type, index);
        }
        if(this.state.mappedPodsFields[index] === undefined) {
            this.state.mappedPodsFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedPodsFields: this.state.mappedPodsFields});
            this.setMappedFields(fields, this.state.mappedPodsFields[index], type, index);
        }
    }

    onCustomFieldSuiteDrop(data, fields, index) {
        var type = "customfieldsuite";
        if(this.state.mappedCustomFieldSuiteFields[index] !== undefined){
            this.state.mappedCustomFieldSuiteFields[index]=`${(this.state.mappedCustomFieldSuiteFields[index])}{${(data.csvheader)}}`
            this.setState({mappedCustomFieldSuiteFields: this.state.mappedCustomFieldSuiteFields});
            this.setMappedFields(fields, this.state.mappedCustomFieldSuiteFields[index], type, index);
        }
        if(this.state.mappedCustomFieldSuiteFields[index] === undefined) {
            this.state.mappedCustomFieldSuiteFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedCustomFieldSuiteFields: this.state.mappedCustomFieldSuiteFields});
            this.setMappedFields(fields, this.state.mappedCustomFieldSuiteFields[index], type, index);
        }
    }

    onAllInOneSeoDrop(data, fields, index) {
        var type = "allinoneseo";
        if(this.state.mappedAllInOneSeoFields[index] !== undefined){
            this.state.mappedAllInOneSeoFields[index]=`${(this.state.mappedAllInOneSeoFields[index])}{${(data.csvheader)}}`
            this.setState({mappedAllInOneSeoFields: this.state.mappedAllInOneSeoFields});
            this.setMappedFields(fields, this.state.mappedAllInOneSeoFields[index], type, index);
        }
        if(this.state.mappedAllInOneSeoFields[index] === undefined) {
            this.state.mappedAllInOneSeoFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedAllInOneSeoFields: this.state.mappedAllInOneSeoFields});
            this.setMappedFields(fields, this.state.mappedAllInOneSeoFields[index], type, index);
        }
    }

    onYoastSeoDrop(data, fields, index) {
        var type = "yoastseo";
        if(this.state.mappedYoastSeoFields[index] !== undefined){
            this.state.mappedYoastSeoFields[index]=`${(this.state.mappedYoastSeoFields[index])}{${(data.csvheader)}}`
            this.setState({mappedYoastSeoFields: this.state.mappedYoastSeoFields});
            this.setMappedFields(fields, this.state.mappedYoastSeoFields[index], type, index);
        }
        if(this.state.mappedYoastSeoFields[index] === undefined) {
            this.state.mappedYoastSeoFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedYoastSeoFields: this.state.mappedYoastSeoFields});
            this.setMappedFields(fields, this.state.mappedYoastSeoFields[index], type, index);
        }
    }

    onBillingAndShippingDrop(data, fields, index) {
        var type = "billingandshipping";
        if(this.state.mappedBillingAndShippingFields[index] !== undefined){
            this.state.mappedBillingAndShippingFields[index]=`${(this.state.mappedBillingAndShippingFields[index])}{${(data.csvheader)}}`
            this.setState({mappedBillingAndShippingFields: this.state.mappedBillingAndShippingFields});
            this.setMappedFields(fields, this.state.mappedBillingAndShippingFields[index], type, index);
        }
        if(this.state.mappedBillingAndShippingFields[index] === undefined) {
            this.state.mappedBillingAndShippingFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedBillingAndShippingFields: this.state.mappedBillingAndShippingFields});
            this.setMappedFields(fields, this.state.mappedBillingAndShippingFields[index], type, index);
        }
    }

    onWpMemberDrop(data, fields, index) {
        var type = "wpmember";
        if(this.state.mappedWpMemberFields[index] !== undefined){
            this.state.mappedWpMemberFields[index]=`${(this.state.mappedWpMemberFields[index])}{${(data.csvheader)}}`
            this.setState({mappedWpMemberFields: this.state.mappedWpMemberFields});
            this.setMappedFields(fields, this.state.mappedWpMemberFields[index], type, index);
        }
        if(this.state.mappedWpMemberFields[index] === undefined) {
            this.state.mappedWpMemberFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedWpMemberFields: this.state.mappedWpMemberFields});
            this.setMappedFields(fields, this.state.mappedWpMemberFields[index], type, index);
        }
    }

    onMemberDrop(data, fields, index) {
        var type = "member";
        if(this.state.mappedMemberFields[index] !== undefined){
            this.state.mappedMemberFields[index]=`${(this.state.mappedMemberFields[index])}{${(data.csvheader)}}`
            this.setState({mappedMemberFields: this.state.mappedMemberFields});
            this.setMappedFields(fields, this.state.mappedMemberFields[index], type, index);
        }
        if(this.state.mappedMemberFields[index] === undefined) {
            this.state.mappedMemberFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedMemberFields: this.state.mappedMemberFields});
            this.setMappedFields(fields, this.state.mappedMemberFields[index], type, index);
        }
    }

    onProductMetaDrop(data, fields, index) {
        var type = "productmeta";
        if(this.state.mappedProductMetaFields[index] !== undefined){
            this.state.mappedProductMetaFields[index]=`${(this.state.mappedProductMetaFields[index])}{${(data.csvheader)}}`
            this.setState({mappedProductMetaFields: this.state.mappedProductMetaFields});
            this.setMappedFields(fields, this.state.mappedProductMetaFields[index], type, index);
        }
        if(this.state.mappedProductMetaFields[index] === undefined) {
            this.state.mappedProductMetaFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedProductMetaFields: this.state.mappedProductMetaFields});
            this.setMappedFields(fields, this.state.mappedProductMetaFields[index], type, index);
        }
    }

    onWpEcomDrop(data, fields, index) {
        var type = "wpecom"
        if(this.state.mappedWpEcomFields[index] !== undefined){
            this.state.mappedWpEcomFields[index]=`${(this.state.mappedWpEcomFields[index])}{${(data.csvheader)}}`
            this.setState({mappedWpEcomFields: this.state.mappedWpEcomFields});
            this.setMappedFields(fields, this.state.mappedWpEcomFields[index], type, index);
        }
        if(this.state.mappedWpEcomFields[index] === undefined) {
            this.state.mappedWpEcomFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedWpEcomFields: this.state.mappedWpEcomFields});
            this.setMappedFields(fields, this.state.mappedWpEcomFields[index], type, index);
        }
    }

    onEventsManagerDrop(data, fields, index) {
        var type = "eventsmanager";
        if(this.state.mappedEventsManagerFields[index] !== undefined){
            this.state.mappedEventsManagerFields[index]=`${(this.state.mappedEventsManagerFields[index])}{${(data.csvheader)}}`
            this.setState({mappedEventsManagerFields: this.state.mappedEventsManagerFields});
            this.setMappedFields(fields, this.state.mappedEventsManagerFields[index], type, index);
        }
        if(this.state.mappedEventsManagerFields[index] === undefined) {
            this.state.mappedEventsManagerFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedEventsManagerFields: this.state.mappedEventsManagerFields});
            this.setMappedFields(fields, this.state.mappedEventsManagerFields[index], type, index);
        }
    }

    onNextgenGalleryDrop(data, fields, index) {
        var type = "nextgengallery";
        if(this.state.mappedNextgenGalleryFields[index] !== undefined){
            this.state.mappedNextgenGalleryFields[index]=`${(this.state.mappedNextgenGalleryFields[index])}{${(data.csvheader)}}`
            this.setState({mappedNextgenGalleryFields: this.state.mappedNextgenGalleryFields});
            this.setMappedFields(fields, this.state.mappedNextgenGalleryFields[index], type, index);
        }
        if(this.state.mappedNextgenGalleryFields[index] === undefined) {
            this.state.mappedNextgenGalleryFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedNextgenGalleryFields: this.state.mappedNextgenGalleryFields});
            this.setMappedFields(fields, this.state.mappedNextgenGalleryFields[index], type, index);
        }
    }

    onCmb2Drop(data, fields, index) {
        var type = "cmb2";
        if(this.state.mappedCmb2Fields[index] !== undefined){
            this.state.mappedCmb2Fields[index]=`${(this.state.mappedCmb2Fields[index])}{${(data.csvheader)}}`
            this.setState({mappedCmb2Fields: this.state.mappedCmb2Fields});
            this.setMappedFields(fields, this.state.mappedCmb2Fields[index], type, index);
        }
        if(this.state.mappedCmb2Fields[index] === undefined) {
            this.state.mappedCmb2Fields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedCmb2Fields: this.state.mappedCmb2Fields});
            this.setMappedFields(fields, this.state.mappedCmb2Fields[index], type, index);
        }
    }

    onTermsAndTaxonomiesDrop(data, fields, index) {
        var type = "cmb2";
        if(this.state.mappedTermsAndTaxonomiesFields[index] !== undefined){
            this.state.mappedTermsAndTaxonomiesFields[index]=`${(this.state.mappedTermsAndTaxonomiesFields[index])}{${(data.csvheader)}}`
            this.setState({mappedTermsAndTaxonomiesFields: this.state.mappedCmb2Fields});
            this.setMappedFields(fields, this.state.mappedTermsAndTaxonomiesFields[index], type, index);
        }
        if(this.state.mappedTermsAndTaxonomiesFields[index] === undefined) {
            this.state.mappedTermsAndTaxonomiesFields[index] = `{${(data.csvheader)}}`;
            this.setState({mappedTermsAndTaxonomiesFields: this.state.mappedCmb2Fields});
            this.setMappedFields(fields, this.state.mappedTermsAndTaxonomiesFields[index], type, index);
        }
    }



    render() {
        return(
        <div className="wp-ultimate-csv-importer">
        {/* <div className="col-md-6 offset-md-3">
                <!-- mapping tab menu start-->
                <ul className="mapping-switcher">
                    <li className={`map ${this.state.advancedMode}`} onClick={(event)=>{this.setState({advancedMode: "active", dragAndDrop: ""}); this.context.changeActivateMappingSectionState(true); this.context.changeActivateDragAndDropSectionState(false)}} data-form="create">Advanced Mode</li>
                    <li className={`map ${this.state.dragAndDrop}`} onClick={(event)=>{this.setState({advancedMode: "", dragAndDrop: "active"}); this.context.changeActivateDragAndDropSectionState(true); this.context.changeActivateMappingSectionState(false);}} data-form="existing">Drag & Drop Mode</li>
                </ul>


            </div> 
             <!-- mapping tab menu End--> 
            <div className="clearfix"></div> */}
    
       


        <div className="row container-fluid ">
            <div id="mapping-accordion" className="col-md-8">
                <div className="card csv-importer-panel mt50">
                    {/* <!-- Wordpress Fields Starts--> */}
                    <h1 className="card-header main-heading active" id="wordpress-fields" onclick="toggle_func('wordpress-fields');" >{this.context.translateLanguage.WordPressCoreFields} <span className="csv-icon-angle-down float-right"></span></h1>
                    <div className="card-body" id="wordpress-fields-body">
                        {this.context.wordPressCoreFields.map((corefields,index) => {
                        return(
                        <div className="form-group">
                        <label>{corefields.label}</label>
                        <Droppable
                            types={[`csvheader`]}
                            onDrop={(data) => {this.onDropState =true; this.onWordPressCoreDrop.bind(this)(data, corefields.name, index);}}>
                            <input type="text" name="" id={index} className="form-control" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "core", index, corefields.csvheader) : this.state.mappedWordPressCoreFields[index]} onChange={(event)=>{ this.onDropState =true; var type = "core"; this.state.mappedWordPressCoreFields[index]=event.target.value; this.setState({mappedWordPressCoreFields: this.state.mappedWordPressCoreFields}); this.setMappedFields(corefields.name, this.state.mappedWordPressCoreFields[index], type, index);}} />                         
                        
                        </Droppable>
                        {/* // {((corefields.csvheader !== undefined) ||  (corefields.csvheader !== null) || (corefields.csvheader !=="")) ? <input type="text" name="" id={index} className="form-control" placeholder={corefields.name} aria-describedby="helpId" rows={index} value={(this.context.activateUseExistingMappingState) ? this.context.wordPressCoreFields[index].csvheader : this.state.mappedWordPressCoreFields[index]} onChange={(event)=>{ var type = "core"; this.state.mappedWordPressCoreFields[index]=event.target.value; this.setState({mappedWordPressCoreFields: this.state.mappedWordPressCoreFields}); this.setMappedFields(corefields.name, this.state.mappedWordPressCoreFields[index], type, index);}}} */}

                        </div> 
                                        
                        )})} 
                        
                        <button type="submit" className="smack-btn smack-btn-primary float-right">Preview</button>

                    </div>
                </div> 
                {/* <!-- Wordpress Fields End--> */}

            {(this.context.showAcfFreeFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- ACF Free Fields Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="acffree-fields" onClick={(event)=>{toggle_func('acffree-fields');}} >
                         {this.context.translateLanguage.ACFFreeFields}<span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="acffree-fields-body" data-display='block'>    
                   
                    <div className={`custom-fields-tabpane custom-fields-tab1 ${(this.state.acfFree)}`}>
                            {(this.context.acfFreeFields != null) ? 
                                this.context.acfFreeFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                            <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                                types={[`csvheader`]}
                                                onDrop={(data) => {this.onDropState =true; this.onAcfFreeDrop.bind(this)(data, corefields.name, index)}}>
                                                <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "acffree", index, corefields.csvheader) : this.state.mappedAcfFreeFields[index]} onChange={(event)=>{this.onDropState =true; var type = "acffree"; this.state.mappedAcfFreeFields[index]=event.target.value; this.setState({mappedAcfFreeFields: this.state.mappedAcfFreeFields}); this.setMappedFields(corefields.name, this.state.mappedAcfFreeFields[index], type, index);}} />
                                                <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                            </Droppable>
                                        </div>
                                                       {/* <input type="text" className="form-control col-md-9" name="" id={index} value={corefields.name} /> */}
                                                            
                                         </div>
                                    
                                    )})
                                    
                                    : "" }
                       </div>
                    </div>
                </div>
            : "" }
            {/* <!-- ACF Free Fields Ends--> */}


            {(this.context.showAcfProFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- ACF Pro Fields Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="acfpro-fields" onClick={(event)=>{toggle_func('acfpro-fields');}} >
                         {this.context.translateLanguage.ACFProFields}<span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="acfpro-fields-body" data-display='block'>    
                    
                    <div className={`acfpro-fields-tabpane acfpro-fields-tab2 ${(this.state.acfPro)}`}>
                             {(this.context.acfProFields != null) ?
                                this.context.acfProFields.map((corefields, index) => {
                                    return(
                                        // <div className="form-group col-md-10 mt-5 mb-3 d-flex">
                                        <div className="form-group">
                                            <label>{corefields.label}</label>
                                            <Droppable
                                            className="d-flex justify-content-center"
                                                types={[`csvheader`]}
                                                onDrop={(data) => {this.onDropState = true; this.onAcfProDrop.bind(this)(data, corefields.name, index)}}>
                                                <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "acfpro", index, corefields.csvheader) :  this.state.mappedAcfProFields[index]} onChange={(event)=>{this.onDropState = true; var type = "acfpro"; this.state.mappedAcfProFields[index]=event.target.value; this.setState({mappedAcfProFields: this.state.mappedAcfProFields}); this.setMappedFields(corefields.name, this.state.mappedAcfProFields[index], type, index);}} />
                                                <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                            </Droppable>
                                        </div>
                                        // </div>
                                     )})
                                     : "" }
                        </div>
                    </div>
                </div>
            : "" }
            {/* <!-- ACF Pro Fields Ends--> */}


            {(this.context.showAcfGroupFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- ACF Group Fields Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="acfgroup-fields" onClick={(event)=>{toggle_func('acfgroup-fields');}} >
                         {this.context.translateLanguage.ACFGroupFields}<span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="acfgroup-fields-body" data-display='block'>    
                    <ul className="acfgroup-fields-tabs row justify-content-center">
                    <li className={`acfgroup-fields-tab-list col-xs-6 col-sm-4 col-md-2 ${(this.context.showAcfGroupFieldsState) ? this.state.acfGroup : 'disable'}`} onClick={(event)=>{if(this.context.showAcfGroupFieldsState) { this.setState({acfGroup: 'active'})}}} style={{display: (this.context.showAcfGroupFieldsState) ? this.state.displayBlock : this.state.displayNone}} data-tab="acfgroup-fields-tab1">ACF Group</li>
                    </ul>

                    <div className={`acfgroup-fields-tabpane acfgroup-fields-tab1 ${(this.state.acfGroup)}`}>
                             {(this.context.acfGroupFields != null) ? 
                                this.context.acfGroupFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group col-md-10 mt-5 mb-3 d-flex">
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                                types={[`csvheader`]}
                                                onDrop={(data) => {this.onDropState=true; this.onAcfGroupDrop.bind(this)(data, corefields.name, index)}}>
                                                <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "acfgroup", index, corefields.csvheader) : this.state.mappedAcfGroupFields[index]} onChange={(event)=>{this.onDropState=true; var type= "acfgroup"; this.state.mappedAcfGroupFields[index]=event.target.value; this.setState({mappedAcfGroupFields: this.state.mappedAcfGroupFields}); this.setMappedFields(corefields.name, this.state.mappedAcfGroupFields[index], type, index);}} />
                                                <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                            </Droppable>
                                        </div>
                                        </div>
                                    )})
                                    : "" }
                        </div>
                    </div>
                </div>
            : "" }
            {/* <!-- ACF Group Fields Ends--> */}


            {(this.context.showAcfRepeaterFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- ACF Repeater Fields Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="acfrepeater-fields" onClick={(event)=>{toggle_func('acfrepeater-fields');}} >
                         {this.context.translateLanguage.ACFRepeaterFields}<span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="acfrepeater-fields-body" data-display='block'>    
                    
                    <div className={`acfrepeater-fields-tabpane acfrepeater-fields-tab1 ${(this.state.acfRepeater)}`}>
                            {(this.context.acfRepeaterFields != null) ?
                                this.context.acfRepeaterFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                                types={[`csvheader`]}
                                                onDrop={(data) => {this.onDropState=true; this.onAcfRepeaterDrop.bind(this)(data, corefields.name, index)}}>
                                                <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "acfrepeater", index, corefields.csvheader) : this.state.mappedAcfRepeaterFields[index]} onChange={(event)=>{this.onDropState=true; var type = "acfrepeater"; this.state.mappedAcfRepeaterFields[index]=event.target.value; this.setState({mappedAcfRepeaterFields: this.state.mappedAcfRepeaterFields}); this.setMappedFields(corefields.name, this.state.mappedAcfRepeaterFields[index], type, index);}} />
                                                <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div> 
                                    )})
                                    : "" }
                        </div>
                    </div>
                </div>
             : "" }
             {/* <!-- ACF Repeater Fields Ends--> */}
                                
            {(this.context.showTypesFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- Types Fields Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="types-fields" onClick={(event)=>{toggle_func('types-fields');}} >
                        {this.context.translateLanguage.TypesCustomFields}<span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="types-fields-body" data-display='block'>    
                  
                    <div className={`types-fields-tabpane types-fields-tab1 ${(this.state.types)}`}>
                            {(this.context.typesFields != null) ?
                                this.context.typesFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                                types={[`csvheader`]}
                                                onDrop={(data) => {this.onDropState=true; this.onTypesDrop.bind(this)(data, corefields.name, index)}}>
                                                <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "types", index, corefields.csvheader) : this.state.mappedTypesFields[index]} onChange={(event)=>{this.onDropState=true; var type = "types"; this.state.mappedTypesFields[index]=event.target.value; this.setState({mappedTypesFields: this.state.mappedTypesFields}); this.setMappedFields(corefields.name, this.state.mappedTypesFields[index], type, index);}} />
                                                <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                                    : "" }
                        </div>
                    </div>
                </div>
            : "" }
            {/* <!-- Types Fields Ends--> */}

            {(this.context.showPodsFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- Pods Fields Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="pods-fields" onClick={(event)=>{toggle_func('pods-fields');}} >
                         {this.context.translateLanguage.PodsFields}<span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="pods-fields-body" data-display='block'>    
                    
                    <div className={`pods-fields-tabpane pods-fields-tab1 ${(this.state.pods)}`}>
                            {(this.context.podsFields != null) ?
                                this.context.podsFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                                types={[`csvheader`]}
                                                onDrop={(data) => {this.onDropState=true; this.onPodsDrop.bind(this)(data, corefields.name, index)}}>
                                                <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "pods", index, corefields.csvheader) : this.state.mappedPodsFields[index]} onChange={(event)=>{this.onDropState=true; var type = "pods"; this.state.mappedPodsFields[index]=event.target.value; this.setState({mappedPodsFields: this.state.mappedPodsFields}); this.setMappedFields(corefields.name, this.state.mappedPodsFields[index], type, index);}} />
                                                <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                                    : "" }
                        </div>
                    </div>
                </div>
            : "" }
            {/* <!-- Pods Fields Ends--> */}

            {(this.context.showCustomFieldSuiteState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- Custom Field Suite Fields Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="customfieldsuite-fields" onClick={(event)=>{toggle_func('customfieldsuite-fields');}} >
                         {this.context.translateLanguage.CustomFieldSuite}<span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="customfieldsuite-fields-body" data-display='block'>    
                
                    <div className={`customfieldssuite-fields-tabpane customfieldssuite-fields-tab1 ${(this.state.cfs)}`}>
                            {(this.context.customFieldSuiteFields != null) ?
                            this.context.customFieldSuiteFields.map((corefields, index) => {
                                return(
                                    <div className="form-group">
                                    <label>{corefields.label}</label>
                                    <Droppable
                                            className="d-flex justify-content-center"
                                        types={[`csvheader`]}
                                        onDrop={(data) => {this.onDropState=true; this.onCustomFieldSuiteDrop.bind(this)(data, corefields.name, index)}}>
                                        <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "customfieldsuite", index, corefields.csvheader) : this.state.mappedCustomFieldSuiteFields[index]} onChange={(event)=>{this.onDropState=true; var type = "customfieldsuite"; this.state.mappedCustomFieldSuiteFields[index]=event.target.value; this.setState({mappedCustomFieldSuiteFields: this.state.mappedCustomFieldSuiteFields}); this.setMappedFields(corefields.name, this.state.mappedCustomFieldSuiteFields[index], type, index);}} />
                                        <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                    </Droppable>
                                    </div>
                                    )})
                                    : "" }
                        </div>
                    </div>
                </div>
            : "" }
            {/* <!-- Custom Field Suite Fields Ends--> */}            
                
            {(this.context.showCmb2CustomFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- CMB2 Custom Fields Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="cmb2custom-fields" onClick={(event)=>{toggle_func('cmb2custom-fields');}} >
                        {this.context.translateLanguage.CMB2CustomFields} <span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="cmb2custom-fields-body" data-display='block'>    
                   
                    <div className={`cmb2custom-fields-tabpane cmb2custom-fields-tab1 ${(this.state.cmb2)}`}>
                            {(this.context.cmb2CustomFields != null) ?
                                this.context.cmb2CustomFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                            types={[`csvheader`]}
                                            onDrop={(data) => {this.onDropState=true; this.onCmb2Drop.bind(this)(data, corefields.name, index)}}>
                                            <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "cmb2", index, corefields.csvheader) : this.state.mappedCmb2Fields[index]} onChange={(event)=>{this.onDropState=true; var type="cmb2"; this.state.mappedCmb2Fields[index]=event.target.value; this.setState({mappedCmb2Fields: this.state.mappedCmb2Fields}); this.setMappedFields(corefields.name, this.state.mappedCmb2Fields[index], type, index);}} />
                                            <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                                    : "" }
                        </div>
                    </div>
                </div>
            : "" }
                {/* <!-- CMB2 Custom Fields Ends--> */}
            

                
            {(this.context.showAllInOneSeoFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- All in One Seo Fields Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="allinoneseo-fields" onClick={(event)=>{toggle_func('allinoneseo-fields');}} >
                        {this.context.translateLanguage.AllInOneSeoFields} <span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="allinoneseo-fields-body" data-display='block'>    
                    
                        <div className={`allinoneseo-fields-tabpane allinoneseo-fields-tab1 ${(this.state.allInOneSeo)}`}>
                            {(this.context.allInOneSeoFields != null) ?
                                this.context.allInOneSeoFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                            types={[`csvheader`]}
                                            onDrop={(data) => {this.onDropState=true; this.onAllInOneSeoDrop.bind(this)(data, corefields.name, index)}}>
                                            <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "allinoneseo", index, corefields.csvheader) : this.state.mappedAllInOneSeoFields[index]} onChange={(event)=>{this.onDropState=true; var type = "allinoneseo"; this.state.mappedAllInOneSeoFields[index]=event.target.value; this.setState({mappedAllInOneSeoFields: this.state.mappedAllInOneSeoFields}); this.setMappedFields(corefields.name, this.state.mappedAllInOneSeoFields[index], type, index);}} />
                                            <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                                : "" }
                        </div>
                    
                   </div>
                </div>
            : "" }
                {/* <!-- All in One Seo field ends --> */}

                {(this.context.showYoastSeoFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- Yoast Seo Fields Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="yoastseo-fields" onClick={(event)=>{toggle_func('yoastseo-fields');}} >
                        {this.context.translateLanguage.YoastSeoFields} <span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="yoastseo-fields-body" data-display='block'>    
                    
                    <div className={`yoastseo-fields-tabpane yoastseo-fields-tab1 ${(this.state.yoastSeo)}`}>
                            {(this.context.yoastSeoFields != null) ?
                                this.context.yoastSeoFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                            types={[`csvheader`]}
                                            onDrop={(data) => {this.onDropState=true; this.onYoastSeoDrop.bind(this)(data, corefields.name, index)}}>
                                            <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "yoastseo", index, corefields.csvheader) : this.state.mappedYoastSeoFields[index]} onChange={(event)=>{this.onDropState=true; var type = "yoastseo"; this.state.mappedYoastSeoFields[index]=event.target.value; this.setState({mappedYoastSeoFields: this.state.mappedYoastSeoFields}); this.setMappedFields(corefields.name, this.state.mappedYoastSeoFields[index], type, index);}} />
                                            <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                                    : "" }
                        </div>
                       
                </div>
                </div>
            : "" }
             {/* <!-- Yoast Seo Fields Ends--> */}

            {(this.context.showBillingAndShippingInformationState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- Billing And Shipping Information Fields Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="billingandshipping-fields" onClick={(event)=>{toggle_func('billingandshipping-fields');}} >
                        {this.onDropState.context.translateLanguage.BillingAndShippingInformation} <span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="billingandshipping-fields-body" data-display='block'>    
                    
                        <div className={`billingandshipping-fields-tabpane billingandshipping-fields-tab1 ${(this.state.billingAndShipping)}`}>
                            {(this.context.billingAndShippingInformation != null) ?
                                this.context.billingAndShippingInformation.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                            types={[`csvheader`]}
                                            onDrop={(data) => {this.onDropState=true; this.onBillingAndShippingDrop.bind(this)(data, corefields.name, index)}}>
                                            <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "billingandshipping", index, corefields.csvheader) : this.state.mappedBillingAndShippingFields[index]} onChange={(event)=>{this.onDropState=true; var type = "billingandshipping"; this.state.mappedBillingAndShippingFields[index]=event.target.value; this.setState({mappedBillingAndShippingFields: this.state.mappedBillingAndShippingFields}); this.setMappedFields(corefields.name, this.state.mappedBillingAndShippingFields[index], type, index);}} />
                                            <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                                    : "" }
                        </div>
                        
                    </div>
                </div>
            : "" }

                {/* <!-- Billing And Shipping Information Fields Ends--> */}

            {(this.context.showCustomFieldsWpMembersState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- Custom Fields WP Member Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="customfieldswpmember-fields" onClick={(event)=>{toggle_func('customfieldswpmember-fields');}} >
                        {this.context.translateLanguage.CustomFieldsWPMemberFields} <span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="customfieldswpmember-fields-body" data-display='block'>    
                    
                        <div className={`customfieldswpmember-fields-tabpane customfieldswpmember-fields-tab1 ${(this.state.wpMember)}`}>
                            {(this.context.customFieldsWpMembersFields != null) ?
                                this.context.customFieldsWpMembersFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                            types={[`csvheader`]}
                                            onDrop={(data) => {this.onDropState=true; this.onWpMemberDrop.bind(this)(data, corefields.name, index)}}>
                                            <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "wpmember", index, corefields.csvheader) : this.state.mappedWpMemberFields[index]} onChange={(event)=>{this.onDropState=true; var type = "wpmember"; this.state.mappedWpMemberFields[index]=event.target.value; this.setState({mappedWpMemberFields: this.state.mappedWpMemberFields}); this.setMappedFields(corefields.name, this.state.mappedWpMemberFields[index], type, index);}} />
                                            <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                                    : "" }
                        </div>
                        
                    </div>
                </div>
            : "" }
                 {/* <!-- Custom Fields WP Member Ends--> */}

            {(this.context.showCustomFieldsMembersState) ?
                 <div className="card csv-importer-panel">
                    {/* <!-- Custom Fields Member Starts--> */}
                    <h1 className="card-header main-heading bg-white" id="customfieldsmember-fields" onClick={(event)=>{toggle_func('customfieldsmember-fields');}} >
                        {this.context.translateLanguage.CustomFieldsMemberFields} <span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="customfieldsmember-fields-body" data-display='block'>    
                    
                        <div className={`customfieldsmember-fields-tabpane customfieldsmember-fields-tab1 ${(this.state.member)}`}>
                            {(this.context.customFieldsMembersFields != null) ?
                                this.context.customFieldsMembersFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                            types={[`csvheader`]}
                                            onDrop={(data) => {this.onDropState=true; this.onMemberDrop.bind(this)(data, corefields.name, index)}}>
                                            <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "member", index, corefields.csvheader) : this.state.mappedMemberFields[index]} onChange={(event)=>{this.onDropState=true; var type= "member"; this.state.mappedMemberFields[index]=event.target.value; this.setState({mappedMemberFields: this.state.mappedMemberFields}); this.setMappedFields(corefields.name, this.state.mappedMemberFields[index], type, index);}} />
                                            <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                                    : "" }
                        </div>
                       
                    </div>
                </div>
            : "" }
                {/* <!-- Custom Fields Member Ends--> */}

            {(this.context.showProductMetaFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- Product Meta Fields Starts-->*/}
                    <h1 className="card-header main-heading bg-white" id="productmeta-fields" onClick={(event)=>{toggle_func('productmeta-fields');}} >
                        {this.context.translateLanguage.ProductMetaFields}<span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="productmeta-fields-body" data-display='block'>    
                    
                        <div className={`productmeta-fields-tabpane productmeta-fields-tab1 ${(this.state.productMeta)}`}>
                            {(this.context.productMetaFields != null) ?
                                this.context.productMetaFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                            types={[`csvheader`]}
                                            onDrop={(data) => {this.onDropState=true; this.onProductMetaDrop.bind(this)(data, corefields.name, index)}}>
                                            <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "productmeta", index, corefields.csvheader) : this.state.mappedProductMetaFields[index]} onChange={(event)=>{this.onDropState=true; var type= "productmeta"; this.state.mappedProductMetaFields[index]=event.target.value; this.setState({mappedProductMetaFields: this.state.mappedProductMetaFields}); this.setMappedFields(corefields.name, this.state.mappedProductMetaFields[index], type, index);}} />
                                            <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                                    : "" }
                        </div>
                        
                    </div>
                </div>
            : "" }
                {/* <!-- Product Meta Fields Ends-->*/}

            {(this.context.showWpEcomCustomFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- WP ECOMMERCE Fields Starts-->*/}
                    <h1 className="card-header main-heading bg-white" id="wpecomcustom-fields" onClick={(event)=>{toggle_func('wpecomcustom-fields');}} >
                        {this.context.translateLanguage.WPECommerceCustomFields}<span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="wpecomcustom-fields-body" data-display='block'>    
                   
                        <div className={`wpecomcustom-fields-tabpane wpecomcustom-fields-tab1 ${(this.state.wpEcom)}`}>
                            {(this.context.wpEcomCustomFields != null) ?
                                this.context.wpEcomCustomFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                            types={[`csvheader`]}
                                            onDrop={(data) => {this.onDropState=true; this.onWpEcomDrop.bind(this)(data, corefields.name, index)}}>
                                            <input type="text" name="" id={index} className="form-control col-md-9" placeholder={corefields.name} aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "wpecom", index, corefields.csvheader) : this.state.mappedWpEcomFields[index]} onChange={(event)=>{this.onDropState=true; var type = "wpecom"; this.state.mappedWpEcomFields[index]=event.target.value; this.setState({mappedWpEcomFields: this.state.mappedWpEcomFields}); this.setMappedFields(corefields.name, this.state.mappedWpEcomFields[index], type, index);}} />
                                            <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                                    : "" }
                        </div>
                        
                    </div>
                </div>
            : "" }
                {/* <!-- WP ECOMMERCE Fields Ends-->*/}

            {(this.context.showEventsManagerFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- Events Manager Fields Starts-->*/}
                    <h1 className="card-header main-heading bg-white" id="eventsmanager-fields" onClick={(event)=>{toggle_func('eventsmanager-fields');}} >
                        {this.context.translateLanguage.EventsManagerFields}<span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="eventsmanager-fields-body" data-display='block'>    
                    
                        <div className={`eventsmanager-fields-tabpane eventsmanager-fields-tab1 ${(this.state.eventsManager)}`}>
                            {(this.context.eventsManagerFields != null) ?
                                this.context.eventsManagerFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                            types={[`csvheader`]}
                                            onDrop={(data) => {this.onDropState=true; this.onEventsManagerDrop.bind(this)(data, corefields.name, index)}}>
                                            <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "eventsmanager", index, corefields.csvheader) : this.state.mappedEventsManagerFields[index]} onChange={(event)=>{this.onDropState=true; var type = "eventsmanager"; this.state.mappedEventsManagerFields[index]=event.target.value; this.setState({mappedEventsManagerFields: this.state.mappedEventsManagerFields}); this.setMappedFields(corefields.name, this.state.mappedEventsManagerFields[index], type, index);}} />
                                            <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                                    : "" }
                        </div>
                        
                    </div>
                </div>
            : "" }
                {/* <!-- Events Manager Fields Ends-->*/}

            {(this.context.showNextgenGalleryFieldsState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- Nextgen Gallery Fields Starts-->*/}
                    <h1 className="card-header main-heading bg-white" id="nextgengallery-fields" onClick={(event)=>{toggle_func('nextgengallery-fields');}} >
                        {this.context.translateLanguage.NextGENGalleryFields}<span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="nextgengallery-fields-body" data-display='block'>    

                        <div className={`nextgengallery-fields-tabpane nextgengallery-fields-tab1 ${(this.state.nextGenGallery)}`}>
                            {(this.context.nextgenGalleryFields != null) ?
                                this.context.nextgenGalleryFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                            types={[`csvheader`]}
                                            onDrop={(data) => {this.onDropState=true; this.onNextgenGalleryDrop.bind(this)(data, corefields.name, index)}}>
                                            <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "nextgengallery", index, corefields.csvheader) : this.state.mappedNextgenGalleryFields[index]} onChange={(event)=>{this.onDropState=true; var type = "nextgengallery"; this.state.mappedNextgenGalleryFields[index]=event.target.value; this.setState({mappedNextgenGalleryFields: this.state.mappedNextgenGalleryFields}); this.setMappedFields(corefields.name, this.state.mappedNextgenGalleryFields[index], type, index);}} />
                                            <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                            : "" }
                        </div>                
                    </div>
                </div>
            : "" }
                {/* <!-- Nextgen Gallery Fields Ends-->*/}

                
            {(this.context.showTermsAndTaxonomiesState) ?
                <div className="card csv-importer-panel">
                    {/* <!-- Terms and Taxonomies Fields Starts-->*/}
                    <h1 className="card-header main-heading bg-white" id="termsandtaxonomies-fields" onClick={(event)=>{toggle_func('termsandtaxonomies-fields');}} >
                        {this.context.translateLanguage.TermsandTaxonomies}<span className="csv-icon-angle-down float-right active"></span></h1>
                    <div className="card-body" id="termsandtaxonomies-fields-body" data-display='block'>    
                  
                    <div className={`termsandtaxonomies-fields-tabpane termsandtaxonomies-fields-tab1 ${(this.state.termsAndTaxonomies)}`}>
                            {(this.context.termsAndTaxonomiesFields != null) ?
                                this.context.termsAndTaxonomiesFields.map((corefields, index) => {
                                    return(
                                        <div className="form-group">
                                        <label>{corefields.label}</label>
                                        <Droppable
                                            className="d-flex justify-content-center"
                                            types={[`csvheader`]}
                                            onDrop={(data) => {this.onDropState=true; this.onTermsAndTaxonomiesDrop.bind(this)(data, corefields.name, index)}}>
                                            <input type="text" name="" id={index} className="form-control col-md-9" aria-describedby="helpId" rows={index} value={((this.context.activateUseExistingMappingState) && (!this.onDropState)) ? this.setAlreadyMappedFields(corefields.name, "termsandtaxonomies", index, corefields.csvheader) : this.state.mappedTermsAndTaxonomiesFields[index]} onChange={(event)=>{this.onDropState=true; var type = "termsandtaxonomies"; this.state.mappedTermsAndTaxonomiesFields[index]=event.target.value; this.setState({mappedTermsAndTaxonomiesFields: this.state.mappedTermsAndTaxonomiesFields}); this.setMappedFields(corefields.name, this.state.mappedTermsAndTaxonomiesFields[index], type, index);}} />
                                            <a className="delete-textbox" data-toggle="tooltip" title="Delete" style={{display: "none"}}><i className="csv-icon-trash-2"></i></a>
                                        </Droppable>
                                        </div>
                                    )})
                            : "" }
                        </div>
                    </div>
                </div>
            : "" }

            {((this.context.fromTemplateMappingSection) && (this.context.activateUseExistingMappingState)) ?
                <div>
                <div className="col-md-12 text-center mt30">
                <label>
                      {this.context.translateLanguage.SavethismappingasTemplate} 
                </label>
                <input type="text" className="form-control ml10 d-inline w-25" value={this.context.editedTemplateNameInManagerSection} onChange={(event)=>{ this.context.selectedEditedTemplateInManager(event.target.value); }} />
                </div>
                {/* <div className="col-md-12 mt30 p0"> */}
                   
                <div className="float-right mb20"><a href="#" className="smack-btn smack-btn-primary" onClick={(event)=>{this.sendMappedFields.bind(this)();}}>{this.context.translateLanguage.Save}</a></div>
                </div>
                : ""}

           { (!this.context.fromTemplateMappingSection) ?
           <div>
           <div className="col-md-12 text-center mt30">
                     <input type="checkbox" className="mr10" value="" id="saveMappingCheck" checked={this.state.display1} onClick={(event)=>{ if(event.target.checked) { this.setState({display1: true}); } else { this.setState({display1: false }); }}}/>
                <label>
                    {(this.context.activateDragAndDropSection) ? `${this.context.translateLanguage.Doyouneedtoupdatethecurrentmapping}` : `${this.context.translateLanguage.Savethecurrentmappingasnewtemplate}` }
                </label>
                   <input type="text" className="form-control ml10 d-inline w-25" disabled={!this.state.display1} value={this.state.templateName} onChange={(event)=>{ this.setState({ templateName: event.target.value})}}/>
            </div>
                <div className="col-md-12 mt30 p0">
                    <div className="float-left">
                        <a href="#" className="smack-btn btn-default" onClick={(event)=>{this.context.changeActivateXmlFileMappingSectionState(false); this.context.setActivateDashboard(true);}}>{this.context.translateLanguage.Back}</a>
                    </div>
                <div className="float-right mb20"><a href="#" className="smack-btn smack-btn-primary" onClick={(event)=>{this.sendMappedFields();}}>{this.context.translateLanguage.Continue}</a></div>
                </div>
            </div>
            : "" }
            </div>

            <div className="col-md-4">
                <div className="mapping-sidebar" id="mapping-sidebar">
               <table className="mapping-sidebar-title">
                    <tbody>
                        <tr>
                            <td className="mapping-sidebar-arrow"><span className="csv-icon-chevron-with-circle-left" onClick={(event)=>{this.state.initialRowSize--; if(this.state.initialRowSize >= 1){this.getCsvFields(this.state.initialRowSize);} else{this.state.initialRowSize++}}}></span>
                            </td>
                            <td className="mapping-sidebar-textbox-section"><strong><input id="current_row" onChange={(event)=>{ this.setState({initialRowSize : event.target.value}); this.getCsvFields(this.state.initialRowSize)} } value={this.state.initialRowSize} type="text"
                                        /></strong> <span className="mapping-textbox-out-of">
                                    of <strong>
                                    {this.state.totalCsvRows} </strong></span>
                            </td>
                            <td className="mapping-sidebar-arrow"><span className="csv-icon-chevron-with-circle-right" onClick={(event)=>{this.state.initialRowSize++; if(this.state.initialRowSize <= this.state.totalCsvRows){this.getCsvFields(this.state.initialRowSize)} else{this.state.initialRowSize--}}}></span></td>
                        </tr>
                    </tbody>
                </table>
                
                <div className="uci_mapping">
                <table className="table table-bordered" cellspacing="10">
                    {this.csvInformation.map((csvdetails) => {
                    return(
                      <tr>
                        
                        <td className="text-primary font-weight-bold">
                            <Draggable type="csvheader" data={csvdetails.csvHeaders}>
                                {csvdetails.csvHeaders}
                            </Draggable>
                        </td>
                        
                                                   
                        <td>
                            {csvdetails.csvValues}
                        </td>
                        
                    </tr>
                    )})}
                </table>
                </div>
            </div>
            </div>
        
    </div>
    </div>
    )
    }
}

export default XmlFileMappingSection;