import React, { Component } from 'react';
import UploadFromDesktop from './uploadFromDesktop.js'
import UploadFromFtpSftp from './uploadFromFtpSftp.js'
import UploadFromUrl from './uploadFromUrl.js'
import UploadFromServer from './uploadFromServer.js'
import SaveMappingTemplate from './saveMappingTemplate.js'
import MappingSection from './mappingSection.js'
import DragAndDropSection from './dragAndDropSection.js'
import XmlFileMappingSection from './xmlFileMappingSection.js'
import MediaHandling from './mediaHandling.js'
import ImportConfiguration from './importConfiguration.js'
import ProgressDisplay from './progressDisplay.js'
import Templates from '../../manager/manageroptions/templates.js'
import {AppContext} from '../../../context.js'

class UploadOptions extends Component {

	static contextType = AppContext;

    constructor(props) {
		super(props);
		this.state = {
			selectedId: 'v-pills-home-tab',
			wordPressDefaultFields: []
		}
	}

	componentDidMount() {
			this.context.setSelectedTabCookies("import-update");
	}
		
	showUploadOptions (){
		return(
		
					<div className="col-md-3 pl0">
						<div className="nav flex-column nav-pills file-choosen-tab" id="v-pills-tab" role="tablist" aria-orientation="vertical">
							<a className="nav-link active" id="v-pills-home-tab" onClick={(event)=>{ this.setState({selectedId: event.target.id}); console.log(event.target.id); }} data-toggle="pill" href="#v-pills-home" role="tab" aria-controls="v-pills-home" aria-selected="false">
								<i className="csv-icon-upload-cloud"></i>{this.context.translateLanguage.UploadfromDesktop}
							</a>
							<a className="nav-link" id="v-pills-profile-tab" onClick={(event)=>{this.setState({selectedId: event.target.id}); console.log(event.target.id); }} data-toggle="pill" href="#v-pills-profile" role="tab" aria-controls="v-pills-profile" aria-selected="true">
								<i className="csv-icon-upload3"></i>{this.context.translateLanguage.UploadfromFTPSFTP}
							</a>
							<a className="nav-link" id="v-pills-messages-tab" onClick={(event)=>{this.setState({selectedId: event.target.id}); }} data-toggle="pill" href="#v-pills-messages" role="tab" aria-controls="v-pills-messages" aria-selected="false">
								<i className="csv-icon-link"></i>{this.context.translateLanguage.UploadfromURL}
							</a>
							<a className="nav-link" id="v-pills-settings-tab" onClick={(event)=>{this.setState({selectedId: event.target.id}); }} data-toggle="pill" href="#v-pills-settings" role="tab" aria-controls="v-pills-settings" aria-selected="false">
								<i className="csv-icon-server"></i>{this.context.translateLanguage.ChoosFileintheServer}
							</a>
						</div>
					</div>
				
		)
	}

	render() {
		return(
			(this.context.activateSaveMappingTemplateSection) ? <SaveMappingTemplate /> :
			(this.context.activateMappingSection) ? <MappingSection /> :
			(this.context.activateDragAndDropSection) ? <DragAndDropSection /> :
			(this.context.activateXmlFileMappingSection) ? <XmlFileMappingSection /> :
			(this.context.activateMediaHandlingSection) ? <MediaHandling /> :
			(this.context.activateImportConfigurationSection) ? <ImportConfiguration /> :
			(this.context.activateProgressDisplaySection) ? <ProgressDisplay /> :
			((!this.context.activateMappingSection) && (this.context.fromTemplateMappingSection)) ? <Templates /> :
			

			<div className=" container">
				<div className="csv-importer-panel row mt20">
					{ (this.context.activateDashboard) ? this.showUploadOptions() : '' }
					{ ((this.state.selectedId == "v-pills-home-tab") && (!this.context.activateMappingSection)) ? <UploadFromDesktop uploadoptions={this} /> : 
					 (this.state.selectedId == "v-pills-profile-tab") ? <UploadFromFtpSftp /> :
					 (this.state.selectedId == "v-pills-messages-tab") ? <UploadFromUrl /> : 
					 (this.state.selectedId == "v-pills-settings-tab") ? <UploadFromServer /> : <div></div> }
					 {/* ((this.state.selectedId == "v-pills-home-tab") && (this.state.activateMappingSection)) ? <MappingSection uploadoptions={this} /> : <div> not displayed </div> } */}
				 	{/* (this.state.selectedId === "v-pills-home-tab") ? 
					this.renderUploadFromDesktop() : (this.state.selectedId === "v-pills-profile-tab") ?
					this.renderUploadFromFtpSftp() : (this.state.selectedId === "v-pills-messages-tab") ?
					this.renderUploadFromUrl() : (this.state.selectedId === "v-pills-settings-tab") ?
					this.renderUploadFromServer() : ''  */}
				</div>
			</div>
		);
	}

}

export default UploadOptions;

