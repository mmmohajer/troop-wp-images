import React, { Component } from 'react';
import {AppContext} from '../../../context.js'

import axios from 'axios';

class MediaHandling extends Component {
    static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
            loading: false,
            activate: "",
            displayCustom: "none",
            customSlug: '',
            customWidth: '',
            customHeight: '',
        }
    }

    componentDidMount() {
        this.context.setSelectedTabCookies("import-update");
    }

    async sendMediaHandlingConfiguration() {
        var formData = new FormData();
        formData.set('action','image_options');
        formData.set(' use_ExistingImage',this.context.activateUseAlreadyMediaImageState);
        formData.set('overwriteImage', this.context.activateOverwriteExistingImageState);
        formData.set('file_name',this.context.mediaImageFileName);
        formData.set('caption',this.context.mediaImageCaption);
        formData.set('alttext', this.context.mediaImageAltText);
        formData.set('description',this.context.mediaImageDescription);
        formData.set('thumbnail',this.context.activateThumbnailState);
        formData.set('medium',this.context.activateMediumState);
        formData.set('medium_large',this.context.activateMediumLargeState);
        formData.set('large', this.context.activateLargeState);
        formData.set('custom',this.context.activateCustomState);
        formData.set('custom_slug',this.state.customSlug);
        formData.set('custom_width',this.state.customWidth);
        formData.set('custom_height',this.state.customHeight);

        this.setState({
            loading : true, });
       
        const response = await axios({
                method: 'post',
                url: ajaxurl,
                data: formData,
                config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        if (response.status == 200)	{
            console.log(response);
            if(response.data.success)
            {
                this.setState({
                    loading : false, });
                console.log('Response of Media Handling Received Successfully');
                this.context.changeActivateImportConfiguration(true); 
                this.context.changeActivateMappingSectionState(false); 
                this.context.changeActivateMediaHandlingSection(false); 
                this.context.setActivateDashboard(false);
            }        
        }
    }

render() {
    return(
        <div id="mapping-accordion">
        <div className="card csv-importer-panel mt20">
            <div className="card-body">

                <h5>{this.context.translateLanguage.MediaHandling}</h5>

                <div className="col-md-12 row mt30 justify-content-center">
                    <label className="align-self-center">{this.context.translateLanguage.Downloadexternalimagestoyourmedia}</label>
                    <div className="form-group fieldset ml30">
                        <input type="checkbox" className="ios-switch" id="media-handle" onClick={(event)=>{var checkBox = document.getElementById("media-handle"); if(checkBox.checked){this.setState({activate: "active"});} else{this.setState({activate: ""})}}} />
                        <label className="switch-ios" for="media-handle"><i></i></label>
                    </div>
                </div>

                <div className={`media-fields ${this.state.activate}`}>
                    <div className="col-md-12 mt20">
                        <div className="border-container">

                            <h5 className="border-container-header">{this.context.translateLanguage.ImageHandling}</h5>

                            <div className="form-group">
                                <input type="radio" name="media-image" className="" id="media-image-existing" onClick={(event)=>{var radiobutton = document.getElementById("media-image-existing"); this.context.activateUseAlreadyMediaImage(radiobutton.checked); }}/>
                                <label for="media-image-existing">{this.context.translateLanguage.Usemediaimagesifalreadyavailable}</label>
                            </div>

                            <div className="form-group">
                                <input type="radio" name="media-image" className="" id="media-image-overwrite" onClick={(event)=>{var radiobutton = document.getElementById("media-image-overwrite"); this.context.activateOverwriteExistingImage(radiobutton.checked);}}/> 
                                <label for="media-image-overwrite">{this.context.translateLanguage.Doyouwanttooverwritetheexistingimages}</label>
                            </div>

                        </div>
                    </div>

                    <div className="col-md-12 mt50">
                        <div className="border-container">

                            <h5 className="border-container-header">{this.context.translateLanguage.ImageSizes}</h5>

                            <div className="row justify-content-center">

                                <div className="col-md-2">
                                    <div className="form-group">
                                        <label>
                                            <input type="checkbox" id="thumbnail" name="" onClick={(event)=>{var checkBox = document.getElementById("thumbnail"); this.context.activateThumbnail(checkBox.checked); }}/>
                                            {this.context.translateLanguage.Thumbnail}
                                        </label>
                                    </div>
                                </div>

                                <div className="col-md-2">
                                    <div className="form-group">
                                        <label>
                                            <input type="checkbox" id="medium" name="" onClick={(event)=>{var checkBox = document.getElementById("medium"); this.context.activateMedium(checkBox.checked); }}/>
                                            {this.context.translateLanguage.Medium}
                                        </label>
                                    </div>
                                </div>

                                <div className="col-md-2">
                                    <div class="form-group">
                                        <label>
                                            <input type="checkbox" id="mediumlarge" name="" onClick={(event)=>{var checkBox = document.getElementById("mediumlarge"); this.context.activateMediumLarge(checkBox.checked); }}/>
                                            {this.context.translateLanguage.MediumLarge}
                                        </label>
                                    </div>
                                </div>

                                <div className="col-md-2">
                                    <div class="form-group">
                                        <label>
                                            <input type="checkbox" id="large" name="" onClick={(event)=>{var checkBox = document.getElementById("large"); this.context.activateLarge(checkBox.checked); }}/>
                                            {this.context.translateLanguage.Large}
                                        </label>
                                    </div>
                                </div>

                                <div className="col-md-2">
                                    <div className="form-group custom-size">
                                        <label>
                                            <input type="checkbox" id="custom" name="" onClick={(event)=>{var checkBox = document.getElementById("custom"); this.context.activateCustom(checkBox.checked); if(checkBox.checked){this.setState({displayCustom: "block"})} else {this.setState({displayCustom: "none"});}}}/>
                                            {this.context.translateLanguage.Custom}
                                        </label>
                                    </div>
                                </div>

                                <div className="col-md-10 custom-image-sizes" style={{display: "" + this.state.displayCustom}}>

                                    <div className="table-responsive">
                                        <table className="media-handle-image-size table mt20">
                                            <thead>
                                                <tr>
                                                    <th>{this.context.translateLanguage.Slug}</th>
                                                    <th>{this.context.translateLanguage.Width}</th>
                                                    <th>{this.context.translateLanguage.Height}</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr id="original-row">
                                                    <td><input type="text" className="form-control" name="" onChange={(event)=>{this.setState({customSlug: event.target.value})}} /></td>
                                                    <td><input type="text" className="form-control" name="" onChange={(event)=>{this.setState({customWidth: event.target.value})}} /></td>
                                                    <td><input type="text" className="form-control" name="" onChange={(event)=>{this.setState({customHeight: event.target.value})}}/></td>
                                                    <td className="delete"><i data-toggle="tooltip" title="Delete" className="csv-icon-trash-o"></i></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <button className="btn-add-size float-right"><i className="csv-icon-plus"></i> {this.context.translateLanguage.Addcustomsizes}</button>

                                </div>

                            </div>

                        </div>
                    </div>

                    <div className="col-md-12 mt50">
                        <div className="border-container">
                            <h5 className="border-container-header">{this.context.translateLanguage.MediaSEOAdvancedOptions}</h5>

                            <div className="row">
                                <div className="form-group col-md-4">
                                    <label className="d-block" >{this.context.translateLanguage.SetimageTitle} : </label>
                                    <select className="form-control" onChange={(event)=>{this.context.setImageTitle(event.target.value)}}>
                                    <option value="">--select--</option>
                                    {this.context.csvHeaderFields.map((csvheaders, index) => {
                                        return <option value={csvheaders}>{csvheaders}</option>
                                    })}
                                    </select>
                                </div>

                                <div className="form-group col-md-4">
                                    <label className="d-block">{this.context.translateLanguage.SetimageCaption} : </label>
                                    <select className="form-control" onChange={(event)=>{this.context.setImageCaption(event.target.value)}}>
                                    <option value="">--select--</option>
                                    {this.context.csvHeaderFields.map((csvheaders, index) => {
                                        return <option value={csvheaders}>{csvheaders}</option>
                                    })}
                                    </select>
                                </div>

                                <div className="form-group col-md-4">
                                    <label className="d-block">{this.context.translateLanguage.SetimageAltText} : </label>
                                    <select className="form-control" onChange={(event)=>{this.context.setImageAltText(event.target.value)}}>
                                    <option value="">--select--</option>
                                    {this.context.csvHeaderFields.map((csvheaders, index) => {
                                        return <option value={csvheaders}>{csvheaders}</option>
                                    })}
                                    </select>
                                </div>

                                <div className="form-group col-md-4">
                                    <label className="d-block">{this.context.translateLanguage.SetimageDescription} : </label>
                                    <select className="form-control" onChange={(event)=>{this.context.setImageDescription(event.target.value)}}>
                                    <option value="">--select--</option>
                                    {this.context.csvHeaderFields.map((csvheaders, index) => {
                                        return <option value={csvheaders}>{csvheaders}</option>
                                    })}
                                    </select>
                                </div>

                                <div className="form-group col-md-4">
                                    <label className="d-block">{this.context.translateLanguage.Changeimagefilenameto} : </label>
                                    <select className="form-control" onChange={(event)=>{this.context.changeImageFileName(event.target.value)}}>
                                        <option value="">--select--</option>
                                        {this.context.csvHeaderFields.map((csvheaders, index) => {
                                        return <option value={csvheaders}>{csvheaders}</option>
                                    })}
                                    </select>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="form-group mt30">
                    <div className="float-left">
                        <button type="button" class="smack-btn btn-default" onClick={(event)=>{if(this.context.fromDragAndDropSection){this.context.changeActivateDragAndDropSectionState(true); this.context.changeActivateMediaHandlingSection(false); this.context.setActivateDashboard(false); this.context.backFromMediaHandlingState(true); } else{this.context.changeActivateMappingSectionState(true); this.context.changeActivateMediaHandlingSection(false); this.context.setActivateDashboard(false); this.context.backFromMediaHandlingState(true);}}}>{this.context.translateLanguage.Back}</button>
                    </div>
                    <div className="float-right">
                    {(this.state.loading) ? 
                        this.context.loaderText
                        :
                        <button type="button" className="smack-btn smack-btn-primary" onClick={(event)=>{this.sendMediaHandlingConfiguration(); }} >{this.context.translateLanguage.Continue}</button>
                        }
                        
                    </div>
                </div>

            </div>

        </div>
    </div>



    )
}
}

export default MediaHandling;