import React, { Component } from 'react';
import axios from 'axios';
import {AppContext} from '../../../context.js'
import { toast } from 'react-toastify';

class UploadFromFtpSftp extends Component {
    static contextType = AppContext;
    constructor(props) {
        super(props);
		this.state = {
            hostName: '',
            hostPort: '',
            hostUserName: '',
            hostPassword: '',
            hostPath: '',
            connectionType: '',
            loading: false,
            showUploadThroughFtp: true,
            showImportSection: false,
            newItem: true,
            existingItem: false,
            postType: [],
			taxonomy: [],
			file_name:'',
			file_size: ''
		}
		this.templateName = [];
		this.module = [];
		this.createdTime = [];
		this.matchedCounts = [];
	}
	
	componentDidMount() {
		this.context.setSelectedTabCookies("import-update");
	}

	getAcfFreeFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if(fields[i]['acf_fields'] != undefined && fields[i]['acf_fields'] != null) {
				return fields[i].acf_fields;
			}
		}
	}

	getAcfGroupFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['acf_group_fields'] != undefined && fields[i]['acf_group_fields'] != null) {
				return fields[i].acf_group_fields;
			}
		}
	}

	getAcfProFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['acf_pro_fields'] != undefined && fields[i]['acf_pro_fields'] != null) {
				return fields[i].acf_pro_fields;
			}
		}

	}

	getAcfRepeaterFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['acf_repeater_fields'] != undefined && fields[i]['acf_repeater_fields'] != null) {
				return fields[i].acf_repeater_fields;
			}
		}

	}

	getWordPressDefaultCoreFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['core_fields'] != undefined && fields[i]['core_fields'] != null) {
				return fields[i].core_fields;
			}
		}
	}

	getTermsAndTaxonomies(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['terms_and_taxonomies'] != undefined && fields[i]['terms_and_taxonomies'] != null) {
				return fields[i].terms_and_taxonomies
			}
		}
	}

	getTypesFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['types_fields'] != undefined && fields[i]['types_fields'] != null) {
				return fields[i].types_fields
			}
		}
	}

	getPodsFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['pods_fields'] != undefined && fields[i]['pods_fields'] != null) {
				return fields[i].pods_fields
			}
		}
	}

	getCustomFieldSuite(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['custom_fields_suite_fields'] != undefined && fields[i]['custom_fields_suite_fields'] != null) {
				return fields[i].custom_fields_suite_fields
			}
		}
	}

	getAllInOneSeoFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['all_in_one_seo_fields'] != undefined && fields[i]['all_in_one_seo_fields'] != null) {
				return fields[i].all_in_one_seo_fields
			}
		}
	}

	getYoastSeoFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['yoast_seo_fields'] != undefined && fields[i]['yoast_seo_fields'] != null) {
				return fields[i].yoast_seo_fields
			}
		}
	}

	getBillingAndShippingInformation(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['billing_and_shipping_information'] != undefined && fields[i]['billing_and_shipping_information'] != null) {
				return fields[i].billing_and_shipping_information
			}
		}
	}

	getWordPressCustomFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['wordpress_custom_fields'] != undefined && fields[i]['wordpress_custom_fields'] != null) {
				return fields[i].wordpress_custom_fields
			}
		}
	}

	getProductMetaFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['product_meta_fields'] != undefined && fields[i]['product_meta_fields'] != null) {
				return fields[i].product_meta_fields
			}
		}
	}

	getCsvHeaderFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['csv_fields'] != undefined && fields[i]['csv_fields'] != null) {
				return fields[i].csv_fields
			}
		}
	}

	getCustomFieldsWpMembers(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['custom_fields_wp_members'] != undefined && fields[i]['custom_fields_wp_members'] != null) {
				return fields[i].custom_fields_wp_members
			}
		}
	}

	getCustomFieldsMembers(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['custom_fields_members'] != undefined && fields[i]['custom_fields_members'] != null) {
				return fields[i].custom_fields_members
			}
		}
	}

	getWpEcomCustomFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['wp_ecom_custom_fields'] != undefined && fields[i]['wp_ecom_custom_fields'] != null) {
				return fields[i].wp_ecom_custom_fields
			}
		}
	}

	getEventsManagerFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['events_manager_fields'] != undefined && fields[i]['events_manager_fields'] != null) {
				return fields[i].events_manager_fields
			}
		}
	}

	getNextgenGalleryFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['nextgen_gallery_fields'] != undefined && fields[i]['nextgen_gallery_fields'] != null) {
				return fields[i].nextgen_gallery_fields
			}
		}
	}

	getCmb2CustomFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['cmb2_fields'] != undefined && fields[i]['cmb2_fields'] != null) {
				return fields[i].cmb2_fields
			}
		}
	}
    async sendConfiguration() {
        var formData = new FormData();
	    formData.set('action','mappingfields');
	    formData.set('HashKey',this.context.hashKey);
	    formData.set('Types', this.context.selectedType);
	    formData.set('Mode', this.context.mode);
	
	    this.setState({
		    loading : true, });
		
	    const response = await axios({
		    method: 'post',
		    url: ajaxurl,
		    data: formData,
		    config: { headers: {'Content-Type': 'multipart/form-data' }}
        });
        
        if (response.status == 200)	{
			if(response.data.success) {
				console.log(response.data);
				this.setState({ showImportRecord:false });
				if(response.data.show_template === true) {
						for(var i=0; i<response.data.info.length; i++)
						{
							this.templateName.push(response.data.info[i].template_name);
							this.module.push(response.data.info[i].module);
							this.createdTime.push(response.data.info[i].created_time);
							this.matchedCounts.push(response.data.info[i].count);
						}
						this.context.setTemplateNameArray(this.templateName);
						this.context.setModulesArray(this.module);
						this.context.setCreatedTimeArray(this.createdTime);
						this.context.setMatchedCounts(this.matchedCounts);
						this.context.setCsvHeaderFields(response.data.csv_fields);
						this.context.changeActivateSaveMappingTemplateSectionState(true);
						this.context.setActivateDashboard(false);
				}
				else {
					var acf_fields = this.getAcfFreeFields(response.data.fields);
					if(acf_fields != undefined) {
						this.context.showAcfFreeFields(true);
						this.context.setAcfFreeFields(acf_fields);
					}
					var acf_group_fields = this.getAcfGroupFields(response.data.fields);
					if (acf_group_fields  != undefined) {
						this.context.showAcfGroupFields(true);
						this.context.setAcfGroupFields(acf_group_fields);
					}

					var acf_pro_fields = this.getAcfProFields(response.data.fields);
					if (acf_pro_fields != undefined) {
						this.context.showAcfProFields(true);
						this.context.setAcfProFields(acf_pro_fields);
					}

					var acf_repeater_fields = this.getAcfRepeaterFields(response.data.fields);
					if (acf_repeater_fields != undefined) {
						this.context.showAcfRepeaterFields(true);
						this.context.setAcfRepeaterFields(acf_repeater_fields);
					}

					var wordpress_default_corefields= this.getWordPressDefaultCoreFields(response.data.fields);
					if (wordpress_default_corefields != undefined) {
						this.context.showWordPressDefaultCoreFields(true);
						this.context.setWordPressDefaultCoreFields(wordpress_default_corefields);
					}
					
					var terms_and_taxonomies = this.getTermsAndTaxonomies(response.data.fields);
					if (terms_and_taxonomies != undefined) {
						this.context.showTermsAndTaxonomies(true);
						this.context.setTermsAndTaxonomies(terms_and_taxonomies);
					}

					var types_fields = this.getTypesFields(response.data.fields);
					if (types_fields != undefined) {
						this.context.showTypesFields(true);
						this.context.setTypesFields(types_fields);
					}

					var pods_fields = this.getPodsFields(response.data.fields);
					if (pods_fields != undefined) {
						this.context.showPodsFields(true);
						this.context.setPodsFields(pods_fields);
					}

					var custom_fields_suite_fields = this.getCustomFieldSuite(response.data.fields);
					if (custom_fields_suite_fields != undefined) {
						this.context.showCustomFieldSuite(true);
						this.context.setCustomFieldSuite(custom_fields_suite_fields);
					}

					var all_in_one_seo_fields = this.getAllInOneSeoFields(response.data.fields);
					if (all_in_one_seo_fields != undefined) {
						this.context.showAllInOneSeoFields(true);
						this.context.setAllInOneSeoFields(all_in_one_seo_fields)
					}

					var yoast_seo_fields = this.getYoastSeoFields(response.data.fields);
					if (yoast_seo_fields != undefined) {
						this.context.showYoastSeoFields(true);
						this.context.setYoastSeoFields(yoast_seo_fields)
					}

					var billing_and_shipping_information = this.getBillingAndShippingInformation(response.data.fields);
					if (billing_and_shipping_information != undefined) {
						this.context.showBillingAndShippingInformation(true);
						this.context.setBillingAndShippingInformation(billing_and_shipping_information);
					}
					
					var wordpress_custom_fields = this.getWordPressCustomFields(response.data.fields);
					if (wordpress_custom_fields != undefined) {
						this.context.showWordPressCustomFields(true);
						this.context.setWordPressCustomFields(wordpress_custom_fields);
					}
					if (wordpress_custom_fields == undefined) {
						this.context.showWordPressCustomFields(true);
						this.context.setWordPressCustomFields(wordpress_custom_fields);
					}

					var product_meta_fields = this.getProductMetaFields(response.data.fields);
					if (product_meta_fields != undefined) {
							this.context.showProductMetaFields(true);
							this.context.setProductMetaFields(product_meta_fields);
					}

					var custom_fields_wp_members = this.getCustomFieldsWpMembers(response.data.fields);
					if (custom_fields_wp_members != undefined) {
							this.context.showCustomFieldsWpMembers(true);
							this.context.setCustomFieldsWpMembers(custom_fields_wp_members);
					}

					var custom_fields_members = this.getCustomFieldsMembers(response.data.fields);
					if (custom_fields_members != undefined) {
							this.context.showCustomFieldsMembers(true);
							this.context.setCustomFieldsMembers(custom_fields_members);
					}

					var wp_ecom_custom_fields = this.getWpEcomCustomFields(response.data.fields);
					if(wp_ecom_custom_fields != undefined) {
							this.context.showWpEcomCustomFields(true);
							this.context.setWpEcomCustomFields(wp_ecom_custom_fields);
					}

					var events_manager_fields = this.getEventsManagerFields(response.data.fields);
					if(events_manager_fields != undefined) {
							this.context.showEventsManagerFields(true);
							this.context.setEventsManagerFields(events_manager_fields);
					}

					var nextgen_gallery_fields = this.getNextgenGalleryFields(response.data.fields);
					if(nextgen_gallery_fields != undefined) {
							this.context.showNextgenGalleryFields(true);
							this.context.setNextgenGalleryFields(nextgen_gallery_fields);
					}

					var cmb2_fields = this.getCmb2CustomFields(response.data.fields);
					if(cmb2_fields != undefined) {
							this.context.showCmb2CustomFields(true);
							this.context.setCmb2CustomFields(cmb2_fields);
					}
					
					this.context.setCsvHeaderFields(response.data.csv_fields);
					if(this.context.uploadedFileType === 'xml') {
						this.context.changeActivateXmlFileMappingSectionState(true);
					}
					else{
					this.context.changeActivateMappingSectionState(true);
					}
					this.context.setActivateDashboard(false);
			}
		} 
	}
}


    async sendFtpConfiguration() {
        var formData = new FormData();
		formData.set('action','get_ftp_url');
		formData.set('HostName',this.state.hostName);
		formData.set('HostPort', this.state.hostPort);
        formData.set('HostUserName', this.state.hostUserName);
        formData.set('HostPassword', this.state.hostPassword);
        formData.set('HostPath', this.state.hostPath);

        this.setState({
			loading : true, });
			
		const response = await axios({
			method: 'post',
			url: ajaxurl,
			data: formData,
			config: { headers: {'Content-Type': 'multipart/form-data' }}
        });
        
        if (response.status == 200)	{
            console.log('ftp');
            console.log(response);
            if(response.data.success) {
				this.setState({
					loading : false, });
                var fileName = response.data.filename;
                var fileNameWithoutExtension = fileName.slice(0,-4);
                this.context.getTemplateName(fileNameWithoutExtension);
                this.context.setHashKey(response.data.hashkey);
				this.context.setSelectedType(response.data.selectedtype);
				this.setState({
					file_name:response.data.filename,
					file_size:response.data.file_size
				});
				if (response.data.file_type === "xml") {
					this.context.uploadFileType("xml");
				}
			    this.setState({postType: response.data.posttype});
			    this.setState({taxonomy: response.data.taxonomy});
                this.setState({showImportSection: true, showUploadThroughFtp: false });
            }
            else {
                toast.error(response.data.message);
            }
        }
    }

    async sendFtpsConfiguration() {
        var formData = new FormData();
		formData.set('action','get_ftps_url');
		formData.set('HostName',this.state.hostName);
		formData.set('HostPort', this.state.hostPort);
        formData.set('HostUserName', this.state.hostUserName);
        formData.set('HostPassword', this.state.hostPassword);
        formData.set('HostPath', this.state.hostPath);

        this.setState({
			loading : true, });
			
		const response = await axios({
			method: 'post',
			url: ajaxurl,
			data: formData,
			config: { headers: {'Content-Type': 'multipart/form-data' }}
        });
        
        if (response.status == 200)	{
            console.log('ftps');
            console.log(response);
            if(response.data.success) {
                this.context.setHashKey(response.data.hashkey);
			    this.context.setSelectedType(response.data.selectedtype);
				this.setState({postType: response.data.posttype});
				this.setState({
					file_name:response.data.filename,
					file_size:response.data.file_size
				})
				if (response.data.file_type === "xml") {
					this.context.uploadFileType("xml");
				}
			    this.setState({taxonomy: response.data.taxonomy});
                this.setState({showImportSection: true, showUploadThroughFtp: false });
            }
        }
    }

    async sendSftpConfiguration() {
        var formData = new FormData();
		formData.set('action','get_sftp_url');
		formData.set('HostName',this.state.hostName);
		formData.set('HostPort', this.state.hostPort);
        formData.set('HostUserName', this.state.hostUserName);
        formData.set('HostPassword', this.state.hostPassword);
        formData.set('HostPath', this.state.hostPath);

        this.setState({
			loading : true, });
			
		const response = await axios({
			method: 'post',
			url: ajaxurl,
			data: formData,
			config: { headers: {'Content-Type': 'multipart/form-data' }}
        });
        
        if (response.status == 200)	{
            console.log('sftp');
            console.log(response);
            if(response.data.success) {
                this.context.setHashKey(response.data.hashkey);
				this.context.setSelectedType(response.data.selectedtype);
				this.setState({
					file_name:response.data.filename,
					file_size:response.data.file_size
				});
				if (response.data.file_type === "xml") {
					this.context.uploadFileType("xml");
				}
			    this.setState({postType: response.data.posttype});
			    this.setState({taxonomy: response.data.taxonomy});
                this.setState({showImportSection: true, showUploadThroughFtp: false });
            }
        }
    }





    render() {
        return(
             <div className="col-md-9">
             {(this.state.showUploadThroughFtp) ?
                <div className="tab-content" id="v-pills-tabContent">
                    <div className="tab-pane fade show active" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
                        {/* <!-- Tab 2 Content --> */}
                        <div className="row mt30">
                            <div className="form-group col-md-6">
                                <label for="hostname">{this.context.translateLanguage.Hostname}</label>
                                <input type="text" className="form-control" onChange={(event)=>{this.setState({hostName: event.target.value})}} id="hostname" placeholder="" />
                                <small className="form-text text-muted">smackcoders.com or 54.213.74.129</small>
                            </div>
                            <div className="form-group col-md-6">
                                <label for="host-port">{this.context.translateLanguage.HostPort}</label>
                                <input type="text" className="form-control" onChange={(event)=>{this.setState({hostPort: event.target.value})}} id="host-port" placeholder="" />
                                <small className="form-text text-muted">{this.context.translateLanguage.DefaultPort} : 21</small>
                            </div>
                            <div className="form-group col-md-6">
                                <label for="host-username">{this.context.translateLanguage.HostUsername}</label>
                                <input type="text" className="form-control" onChange={(event)=>{this.setState({hostUserName: event.target.value})}} id="host-username" placeholder="" />
                                <small className="form-text text-muted">{this.context.translateLanguage.FTPUsername}</small>
                            </div>
                            <div className="form-group col-md-6">
                                <label for="host-password">Host Password</label>
                                <input type="text" className="form-control" onChange={(event)=>{this.setState({hostPassword: event.target.value})}} id="host-password" placeholder="" />
                                <small className="form-text text-muted">{this.context.translateLanguage.FTPPassword}</small>
                            </div>
                            <div className="form-group col-md-12">
                                <label for="host-path">Host Path</label>
                                <input type="text" className="form-control" onChange={(event)=>{this.setState({hostPath: event.target.value})}} id="host-path" placeholder="" />
                                <small className="form-text text-muted">/home/guest/sample.csv</small>
                            </div>
                            <div className="form-group col-md-12">
                                <label className="d-block">{this.context.translateLanguage.ConnectionType}</label>
                                <div className="form-check form-check-inline">
                                    <label className="form-check-label">
                                        <input className="connection-input" onClick={(event)=>{this.setState({connectionType: event.target.id}); console.log(event.target.id)}} type="radio" name="connection-type" id="ftp" value="checkedValue" /> FTP
                                    </label>
                                </div>
                                <div className="form-check form-check-inline">
                                    <label className="form-check-label">
                                        <input className="connection-input" type="radio" onClick={(event)=>{this.setState({connectionType: event.target.id})}} name="connection-type" id="ftps" value="checkedValue" /> FTPS (SSL)
                                    </label>
                                </div>
                                <div className="form-check form-check-inline">
                                    <label className="form-check-label">
                                        <input className="connection-input" type="radio" onClick={(event)=>{this.setState({connectionType: event.target.id})}} name="connection-type" id="sftp" value="checkedValue" /> SSH2 / SFTP
                                    </label>
                                </div>
                            </div>

                        </div>
                        {/* <!-- Tab 2 Content End--> */}
                        <div className="float-right">
						{(this.state.loading) ? 
									this.context.loaderText
									:
									<input type="button" class="smack-btn smack-btn-primary mb20" onClick={(event)=>{if(this.state.connectionType === 'ftp'){this.sendFtpConfiguration();} if(this.state.connectionType === 'ftps'){this.sendFtpsConfiguration();} if(this.state.connectionType === 'sftp'){this.sendSftpConfiguration();}}} value={this.context.translateLanguage.Continue} />
									}
                            
                        </div>

                    </div>
                </div>
                : (this.state.showImportSection) ? 
                    
				<div className="file-info-container">  
					<h3 className="file-name">{this.state.file_name} - <span className="size">{this.state.file_size}</span></h3>
                    <div class="d-flex justify-content-center mt40">
									<div className="form-check form-check-inline">
										<label class="form-check-label">
											<input className="form-check-input" onClick={(event)=>{this.setState({newItem: true, existingItem: false}); this.context.setMode(event.target.id)}} type="radio" name="post-item" id="Insert" checked={this.state.newItem} /> New Item
										</label>
									</div>
									<div className="form-check form-check-inline">
										<label className="form-check-label">
											<input className="form-check-input" onClick={(event)=>{this.setState({existingItem: true, newItem: false}); this.context.setMode(event.target.id)}} type="radio" name="post-item" id="Update" checked={this.state.existingItem} /> Existing Items
										</label>
									</div>
								</div>

								<div className="d-flex justify-content-center mt40">
									<div className="form-group">
										<label>Import each record as</label>
										{(this.state.showImportSection) ?
										<div>
                                        <select value={this.context.selectedType} className="select" onChange={(event)=>{this.context.setSelectedType(event.target.value)}} name="" id="">
											<optgroup label="PostType">
                                            {this.state.postType.map((posttype, index) => {
                                            return <option value={posttype}>{posttype}</option>
											
										})}
											</optgroup>
											<optgroup label="Taxonomy">
											{this.state.taxonomy.map((taxonomy, index) => {
											return <option value={taxonomy}>{taxonomy}</option>
										})}
											</optgroup>
										</select>
										</div> :
										<div></div> }
								</div>
								</div>
								<div className="float-right">
									<input type="button" className="smack-btn smack-btn-primary mb20" onClick={(event)=>{this.sendConfiguration();}} value="Continue" />
								</div>
				</div>
				: 
				'jj' }
            </div>
         )
    }
}


export default UploadFromFtpSftp;

