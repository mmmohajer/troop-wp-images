import React, { Component } from 'react';
import {AppContext} from '../../../context.js'
import axios from 'axios';
import { toast } from 'react-toastify';


class ProgressDisplay extends Component {
    static contextType = AppContext;
    constructor(props) {
    super(props);
		this.state = {
            loading: true,
            check: '',
            fileName: '',
            processingRecords: '',
            remainingRecords: '',
            totalRecords:'',
            fileSize: '',
            process: '',
            remainingTime: '00:00:00',
            stopWatch: '00:00:00',
            progWidth: '0',
            importStatus : 'Processing',
            enableDownload: false,
            controlImportProcess:true,
            rollBackProgress:false,            
            }
            this.message = [];
            this.status = [];
            this.verify =[];
            this.tag = [];
            this.categories = [];
            this.loopCount = 0;
            this.remainingTime = 0;
            this.stopSeconds = 0, this.stopMinutes = 0, this.stopHours = 0;

            this.onUnload = this.onUnload.bind(this);
    }

    async onUnload(event) { // the method that will be used for both add and remove event
      console.log("STOP")
      var formData = new FormData();
	    formData.set('action','ImportStop');
	    formData.set('Stop','false');
      

      const response = await axios({
        method: 'post',
        url: ajaxurl,
        data: formData,
        config: { headers: {'Content-Type': 'multipart/form-data' }}
    });
    event.returnValue = "Hellooww"
      //this.closeImport()
    }

    componentDidMount() {
      this.context.setSelectedTabCookies("import-update");
        setInterval(function() {
          if (this.state.loading && this.state.controlImportProcess) {
            this.getProgress.bind(this)();
            this.stopWatch();
          }
        }.bind(this),1000);

        window.addEventListener("beforeunload", this.onUnload)
    }

    componentWillUnmount() {
      //window.removeEventListener("beforeunload", this.onUnload)
  }
  

    async getProgress() {
      var formData = new FormData();
	    formData.set('action','GetProgress');
	    formData.set('HashKey',this.context.hashKey);

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log("pugrees",response);

        if (response.status == 200) {
            if(response.data.success) {
              this.message = [];
              this.status = [];
              this.verify = [];
              this.tag = [];
              this.categories = [];
              
                for(var i=0; i<response.data.Info.length; i++) {
                    this.message.push(response.data.Info[i].message);
                    this.status.push(response.data.Info[i].status);
                    this.verify.push(response.data.Info[i].verify);
                    this.tag.push(response.data.Info[i].tags);
                    this.categories.push(response.data.Info[i].categories)
                }
                this.setState({fileName: response.data.file_name});
                this.setState({fileSize: response.data.filesize});
                this.setState({processingRecords: response.data.processing_records});
                this.setState({remainingRecords: response.data.remaining_records});
                this.setState({totalRecords: response.data.total_records});
                this.setState({loading : response.data.progress, });
                this.setState({importStatus : response.data.status });

                // var data = response.data;
                this.loopCount = this.loopCount+1;
                
                if (response.data.processing_records>2){
                this.remainingTime = (this.loopCount/response.data.processing_records)*response.data.remaining_records;
                
                //get Remaining Time
                this.secondsToHms(this.remainingTime);

                }

                

                //get Progress Bar
                this.loadProgress(response.data);
            }
      }

    }

    loadProgress (progressData){

      let progWidth = (progressData.processing_records/progressData.total_records)*100;

      console.log(progressData.processing_records)
      console.log(progressData.total_records)
      console.log('progress Value',progWidth)

      progWidth=Math.round(progWidth);

      if (progWidth > 0.9)
      this.setState({progWidth:progWidth})

    }

    secondsToHms(d) {
      d = Number(d);
      var h = Math.floor(d / 3600);
      var m = Math.floor(d % 3600 / 60);
      var s = Math.floor(d % 3600 % 60);
  
      
      if(h.toString().length < 2){
           h= "0"+h;
      }
      if(m.toString().length < 2){
        m= "0"+m;
      }
      if(s.toString().length < 2){
        s= "0"+s;
      }

      var tempTime = h +":"+  m +":"+ s;

      this.setState({remainingTime:tempTime})      
  }

  stopWatch() {
    
    this.stopSeconds++;
    if (this.stopSeconds >= 60) {
        this.stopSeconds = 0;
        this.stopMinutes++;
        if (this.stopMinutes >= 60) {
            this.stopMinutes = 0;
            this.stopHours++;
        }
    }

    if(this.stopHours.toString().length < 2){
      this.stopHours= "0"+this.stopHours;
    }
    if(this.stopMinutes.toString().length < 2){
      this.stopMinutes= "0"+this.stopMinutes;
    }
    if(this.stopSeconds.toString().length < 2){
      this.stopSeconds= "0"+this.stopSeconds;
    }

    //var tempStopWatch = (hours > 9 ? hours : "0" + hours) : "00") + ":" + (minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00") + ":" + (seconds > 9 ? seconds : "0" + seconds);
    

    var tempStopWatch = this.stopHours + ":" + this.stopMinutes + ":" + this.stopSeconds;

    
   //console.log("stop",hours ? (hours > 9 ? hours : "0" + hours) : "00") + ":" + (minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00") + ":" + (seconds > 9 ? seconds : "0" + seconds);
   this.setState({stopWatch:tempStopWatch})
   //console.log("StopWatch",tempStopWatch);
}

  async accessImportProcess(value){

    var stop = '';
      
      if(value === "Pause"){ 
        this.setState({ controlImportProcess:false}) 

        stop= "false"
      
      }else{ 
        
        this.setState({        
        controlImportProcess:true        
      })

      stop= "true"

    }


      console.log('Control First',this.state.controlImportProcess)

      var formData = new FormData();
	    formData.set('action','ImportState');
      formData.set('State',stop);
      formData.set('HashKey',this.context.hashKey);

      const response = await axios({
        method: 'post',
        url: ajaxurl,
        data: formData,
        config: { headers: {'Content-Type': 'multipart/form-data' }}
      });

      console.log("control Resume",response);

      if(response.status == 200){
          (response.data.import_state) ? this.setState({loading:false}) : this.setState({loading:true})
          console.log( 'control State',response.data.import_state)
        
      }
      
    }


    closeImport(){
      this.context.changeActivateProgressDisplay(false)
      this.context.setSelectedTab('import-update');
      this.context.setActivateDashboard(true);
    }

    async startRollBackMode(){

        console.log(this.context.hashKey);
            
          this.setState({rollBackProgress:true})

          var formData = new FormData();
          formData.set('action','rollback_now');
          formData.set('HashKey',this.context.hashKey);

          const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
          });

          this.setState({rollBackProgress:false})

          var data = response.data;

          if (data.success){
            this.context.setRollBackMode(false)
            toast.success(data.message);
          }else{
            toast.error(data.message);
          }

          
          console.log(response)
    }

    
    render() {
            let progWidth = {
              width:this.state.progWidth+ '%'
            };  
            
            let displayBtn = {
              display: (this.state.loading && this.context.importLogDataLink == "" && this.state.controlImportProcess) ? 'none' : 'block'
            }

            const rollLoaderStyle = {
              marginLeft: "25px",
              marginRight: "0",
              bottom:"5px", padding: "0"
            }
    
        return(
          
            <div className="wp-ultimate-csv-importer">
      {/* <!-- tab menu section start--> */}
      <div className=" container">
        <div className="importer-log">
          <div className="card csv-importer-panel mt40 col-md-12">
            <div className="card-body">
                <h4 className="text-center">{this.context.translateLanguage.Import} {this.state.importStatus}</h4>

              <div className="row justify-content-center">
                <div className="mt30 ">
                  
                  { (this.state.importStatus === "Completed") ? 
                  <React.Fragment>
                  <input
                  type="button"
                  className="smack-btn btn-default"
                  value="Close"
                  onClick={(event) => {this.closeImport()}}
                  /> 
                  {(this.context.rollBackMode) ? 
                  <React.Fragment>
                  <input
                  type="button"
                  className="ml20 smack-btn smack-btn-danger"
                  value="RoleBack Now"
                  onClick={(event) => {this.startRollBackMode()}}
                  /> { (this.state.rollBackProgress)? <div className="btn ajax-loader loading" style={rollLoaderStyle}></div> : '' } </React.Fragment> : ''}
                  </React.Fragment> 
                  :

                  (!this.state.controlImportProcess) ?
                  <input
                    type="button"
                    className="smack-btn smack-btn-primary"
                    value="Resume"
                    onClick={(event) => {this.accessImportProcess(event.target.value)}}
                  />
                  :
                  <input
                    type="button"
                    className="smack-btn smack-btn-warning"
                    value="Pause"
                    onClick={(event) => {this.accessImportProcess(event.target.value)}}
                  />

                  }
                </div>
              </div>

              <table className="table mt40">
                <tbody>
                  <tr>
                    <td className="text-left">{this.context.translateLanguage.FileName}: <span>{this.state.fileName}</span></td>
                    <td className="text-right">{this.context.translateLanguage.FileSize}: <span>{this.state.fileSize}</span></td>
                  </tr>
                  <tr>
                    <td className="text-left">{this.context.translateLanguage.Process}: <span>{this.context.mode}</span></td>
                    <td className="text-right">
                      {this.context.translateLanguage.Totalnoofrecords}: <span>{this.state.totalRecords}</span>
                    </td>
                  </tr>
                  <tr>
                    <td className="text-left">
                    <span className="font-weight-normal text-success"
                        >{this.context.translateLanguage.CurrentProcessingRecord}: <span>{this.state.processingRecords}</span></span
                      >
                    </td>
                    <td className="text-right">
                      <span className="font-weight-normal text-danger"
                        >{this.context.translateLanguage.RemainingRecord}: <span>{this.state.remainingRecords}</span></span
                      >
                    </td>
                  </tr>
                </tbody>
              </table>
              <div className="card-body">

                        <div className="importing-details">
                            <div className="progress-status">{(this.state.importStatus === 'Processing') ? 'In Progress' : ''}</div>
                            <div className="import-progress">
                                <div className="progress-loading">{this.state.progWidth+"%"} {this.context.translateLanguage.Completed}</div>
                                <div className="progress-timing"><i className="csv-icon-schedule"></i> {this.context.translateLanguage.TimeElapsed}: <span> {this.state.stopWatch} / </span>{this.state.remainingTime} ({this.context.translateLanguage.approximate})</div>
                            </div>
                        </div>

                       
                        <div className="progress mt10 mb40">
                            <div className="progress-bar" style={progWidth} role="progressbar" aria-valuenow="10" aria-valuemin="0"
                             aria-valuemax="100"></div>
                        </div>
                        

                        <div className="d-flex justify-content-center">
                            <a className="smack-btn smack-btn-primary" href={this.context.importLogDataLink} style={displayBtn} download ><i className="csv-icon-download-cloud mr10"></i>{this.context.translateLanguage.DownloadLog}</a>
                        </div>
                    </div>
            </div>
          </div>
        </div>
      </div>
    </div>
        )
    }
}

export default ProgressDisplay;

