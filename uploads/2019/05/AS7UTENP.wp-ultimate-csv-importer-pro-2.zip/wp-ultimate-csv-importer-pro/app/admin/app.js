import React, { Component } from 'react';
import MainTabs from './uploader/index.js'; 
export default class App extends Component {
	constructor(props) {
        	super(props);
	}


	render() {
		return (<MainTabs />);
	}
}
