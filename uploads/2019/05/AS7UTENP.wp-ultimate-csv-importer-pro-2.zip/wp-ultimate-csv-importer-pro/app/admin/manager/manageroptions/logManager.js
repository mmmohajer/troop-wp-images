import React, { Component } from 'react';
import axios from 'axios';
import {AppContext} from '../../../context.js';

class LogManager extends Component {
    static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
            loading: false,
            logs: [],
            downloadLogLink: ''

        }
	}

    componentDidMount() {
        this.displayLogs();

        //set Cookies for Manager Page
        this.context.setSelectedTabCookies("manager")  
    }

    async displayLogs() {
        var formData = new FormData();
        formData.set('action','display_log');

        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);

        this.setState({ loading : false, });

        if(response.status == 200 && response.data.success) {
            this.setState({ logs:response.data.info });
            console.log(this.state.logs);
            this.setState({ loading : false, });
       } 
    }


    async downloadLog(filename,revision) {
        var formData = new FormData();
        formData.set('action', 'download_log');
        formData.set('filename', filename);
        formData.set('revision', revision);

        
        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });
        
        console.log(response);

        if(response.status == 200) {
           // window.location = "http://localhost/csvimporter/wp-content/uploads/Smack_CSV_Uploads/6ec38e341a001569c0048dd4c97a89ca.log";
           //window.open("http://localhost/csvimporter/wp-content/uploads/Smack_CSV_Uploads/6ec38e341a001569c0048dd4c97a89ca.log");

        //    var file_path = 'http://localhost/csvimporter/wp-content/uploads/Smack_CSV_Uploads/6ec38e341a001569c0048dd4c97a89ca.log';
        //    var a = document.createElement('A');
        //    a.href = file_path;
        //    a.download = file_path.substr(file_path.lastIndexOf('/') + 1);
        //    document.body.appendChild(a);
        //    a.click();
        //    document.body.removeChild(a);

            console.log(response.data.log_link);

            this.setState({downloadLogLink:response.data.log_link})


            document.getElementById('downloadFile').click();

           
       } 
    }


    render() {
        const trPad = {
            padding:"20px 0 10px 0"
          };
        return(
            <div className="col-sm-8 col-md-9">
                    <div className="setting-tab-pane setting-tabpane5 active">
                                <div className="row justify-content-center">
                                    <div className="col-md-12 mt20">
                                        <h1 className="main-heading">Log Info</h1>

                                        <table className="table log-manager">
                                            <thead>
                                                <tr>
                                                    <th>{this.context.translateLanguage.FileName}</th>
                                                    <th>{this.context.translateLanguage.Module}</th>
                                                    <th>{this.context.translateLanguage.Inserted}</th>
                                                    <th>{this.context.translateLanguage.Updated}</th>
                                                    <th>{this.context.translateLanguage.Skipped}</th>
                                                    <th className="text-center">{this.context.translateLanguage.Download}</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                            {(this.state.loading) ?
                                    <tr><td colspan="6"><div className="loader loader-1 mt15"></div></td></tr>
                                    : 
                                    ( this.state.logs.length !== 0) ? this.state.logs.map((log, index) => 
                                    
                                                <tr style={trPad}>
                                                    <td >{ log.filename } <br />
                                                    <b>{this.context.translateLanguage.Revision}: </b> { log.revision }						
                                                    </td>
                                                    <td >{log.module}</td>
                                                    <td>{ log.inserted }</td>
                                                    <td>{ log.updated }</td>
                                                    <td>{ log.skipped }</td>
                                                    <td className="text-center">
                                                    <div className="download-icon">
                                                        <a className="action-icon text-success text-bold" onClick={(event)=>{this.downloadLog(log.filename,log.revision);}} data-toggle="tooltip" title="Download"><i className="csv-icon-download-cloud"></i></a>                                                        
                                                    </div>
                                                    </td>
                                            </tr> )  :                                                
                                                <tr>
                                                    <td colspan="6">
                                                        <span className="text-danger">{this.context.translateLanguage.NoLogRecordFound}</span>
                                                    </td>
                                                </tr>  }
                                            </tbody>
                                        </table>

                                        <a id="downloadFile" className='hidden' href={this.state.downloadLogLink} download>{this.context.translateLanguage.Download}</a>
 
                                    </div>
                                </div>
                            </div>
            </div>
        )
    }
}

export default LogManager;
