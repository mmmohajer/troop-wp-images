import React, {Component} from 'react';
var moment = require('moment');
import axios from 'axios';
import { toast } from 'react-toastify';
import {AppContext} from '../../../context.js';


class FileManager extends Component {
    static contextType = AppContext;
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            events: []
        }
    }

    componentDidMount() {
        this.displayEvents();

        //set Cookies for Manager Page
        this.context.setSelectedTabCookies("manager")
    }

    async displayEvents() {
        var formData = new FormData();
        formData.set('action','display_events');

        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

         console.log(response);

         this.setState({ loading : false, });

        if(response.status == 200 && response.data.success) {
            this.setState({ events:response.data.info });
            //console.log(this.state.events);
       } 
    }


    // Download Revision File
    async downloadRevisionFile(filename,index){
        let options = document.getElementById('revisionSelect-'+index).value;
        console.log(options);

        if (options === " "){
            alert("Please Select any Revision");
            return;
        }

        var formData = new FormData();
        formData.set('action', 'download_file');
        formData.set('filename',filename);
        formData.set('revision',options);

        // this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });
        
        console.log(response);

        if(response.status == 200 && response.data.success == true) {
            window.location.href = response.data.file_link;        
        }
        else{
            toast.error(response.data.message);  
           }
    }


    // Download File ZIP
    async downloadFileZip(filename) {
        var formData = new FormData();
        formData.set('action', 'download_all_file');
        formData.set('filename',filename);

        console.log(filename);

        // this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });
        
        console.log(response);

        if(response.status == 200 && response.data.success == true) {
            window.location.href = response.data.ziplink;        
       } else{
        toast.error(response.data.message);  
       }
    }


    // Download Revision File
    async deleteRevisionFile(filename,index){
        let options = document.getElementById('revisionSelect-'+index).value;
        console.log(options);

        if (options === " "){
            alert("Please Select any Revision");
            return;
        }

        var formData = new FormData();
        formData.set('action', 'delete_file');
        formData.set('filename',filename);
        formData.set('revision',options);

        // this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });
        
        console.log(response);
        
        

        if(response.status == 200) {
            toast.success('Record Deleted Successfully');                    
       }
    }



    async deleteAllRecords(eventone,params){
        
        var formData = new FormData();
        formData.set('action', params);
        formData.set('filename',eventone.filename);
        formData.set('type',eventone.purpose);

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });
        
        console.log(response);

        if(response.status == 200 && response.data.success == true) {
            toast.success(response.data.message);       
        } else{
         toast.error(response.data.notice);  
        }

    }

    render() {
        const vStyle = {
            verticalAlign:"middle"
          };

          const dataWidth = {
            width:"45%"
          };
        return (
            <div className="col-sm-8 col-md-9">
                <div className="setting-tab-pane setting-tabpane1 active ">
                    <div className="row justify-content-center">
                        <div className="col-md-12 mt20">
                            <h1 className="main-heading">{this.context.translateLanguage.FileManager}</h1>

                            <div className="table-responsive">
                                <table className="table table-manager">
                                    <thead>
                                        <tr>
                                            <th>{this.context.translateLanguage.EventInfo}</th>
                                            <th>{this.context.translateLanguage.EventDate}</th>
                                            <th className="text-center">{this.context.translateLanguage.Actions}</th>
                                        </tr>
                                    </thead>
                                    <tbody>              
                                    
                                    {(this.state.loading) ?
                                    <tr><td colspan="6"><div className="loader loader-1 mt15"></div></td></tr>
                                    :  ( this.state.events.length !== 0) ? this.state.events.map((eventone, index) =>                                    
                                            <tr>
                                                <td style={dataWidth}>
                                                    <p><span class="text-label">{this.context.translateLanguage.FileName} : </span>{ eventone.filename }</p>
                                                    <p><span class="text-label">{this.context.translateLanguage.Date} : </span> {  moment(eventone.date).format('lll') }</p>
                                                    <p><span class="text-label">{this.context.translateLanguage.Purpose} : </span> { eventone.purpose }</p>
                                                    <p><span class="text-label">{this.context.translateLanguage.Revision} : </span> <select id={"revisionSelect-"+index}>
                                                            <option value=" ">--{this.context.translateLanguage.Select}--</option>
                                                            { eventone.revisions.map((revision, index) => <option value={revision}>{revision}</option>)}                                                            
                                                            </select></p>                                                                                                                              
                                                    </td>
                                                    <td style={vStyle}>
                                                        <p><span class="text-label">{this.context.translateLanguage.Inserted} : </span> { eventone.inserted }</p>
                                                        <p><span class="text-label">{this.context.translateLanguage.Updated} : </span> { eventone.updated }</p>
                                                        <p><span class="text-label">{this.context.translateLanguage.Skipped} : </span> { eventone.skipped }</p>                                                                    
                                                    </td>
                                                    <td style={vStyle}>
                                                        <ul class="list-inline">
                                                            <li class="list-inline-item"><a class="action-icon text-success" data-toggle="tooltip" onClick={(event)=>{this.downloadRevisionFile(eventone.filename,index);}} title="Download a specific file with revision"><i class="csv-icon-download-cloud"></i></a></li>
                                                            <li class="list-inline-item"><a class="action-icon text-success" data-toggle="tooltip" onClick={(event)=>{this.downloadFileZip(eventone.filename);}} title="Download all files as a zip"><i class="csv-icon-file-zip-o"></i></a></li>
                                                            <li class="list-inline-item"><a class="action-icon text-danger" data-toggle="tooltip" onClick={(event)=>{this.deleteRevisionFile(eventone.filename,index);}} title="Delete a specific file with revision"><i class="csv-icon-delete1"></i></a></li>
                                                            <li class="list-inline-item"><a class="action-icon text-danger" data-toggle="tooltip" onClick={(event)=>{this.deleteAllRecords(eventone,'delete_all_records');}} title="Delete all records"><i class="csv-icon-database1"></i></a></li>
                                                            <li class="list-inline-item"><a class="action-icon text-danger" data-toggle="tooltip" onClick={(event)=>{this.deleteAllRecords(eventone,'delete_all_file');}} title="Delete all files &amp; records"><i class="csv-icon-highlight_off" ></i></a></li>
                                                            <li class="list-inline-item"><a class="action-icon text-danger" data-toggle="tooltip" onClick={(event)=>{this.deleteAllRecords(eventone,'trash_records');}} title="Trash all records"><i class="csv-icon-trash-2"></i></a></li>
                                                        </ul>
                                                    </td>
                                            </tr> ) : <tr><td colspan="6"><span className="text-danger">{this.context.translateLanguage.Noeventsfound}</span></td></tr>
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default FileManager;
