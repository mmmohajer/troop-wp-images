import React, {Component} from 'react';
import axios from 'axios';
var moment = require('moment');
import { toast } from 'react-toastify';
import {AppContext} from '../../../context.js';

class Templates extends Component {
    static contextType = AppContext;
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            templates: []
        }
    }

    componentDidMount() {
		// if(!this.context.fromTemplateMappingSection){
			this.context.changeActivateTemplateSectionState(true);
			this.displayTemplates();
		// }

		//set Cookies for Manager Page
        this.context.setSelectedTabCookies("manager")
	}
	
	componentWillUnmount() {
		if(!this.context.fromTemplateMappingSection){
			this.context.activateTemplateSectionState = false;
			this.context.changeActivateTemplateSectionState(this.context.activateTemplateSectionState);
			this.context.activateDashboard = true;
			this.context.setActivateDashboard(this.context.activateDashboard);
			console.log(this.context.activateTemplateSectionState);
			console.log(this.context.activateDashboard);
			console.log('template component out');
		}
	}

    getAcfFreeFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if(fields[i]['acf_fields'] != undefined && fields[i]['acf_fields'] != null) {
				return fields[i].acf_fields;
			}
		}
	}
	
	getAcfGroupFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['acf_group_fields'] != undefined && fields[i]['acf_group_fields'] != null) {
				return fields[i].acf_group_fields;
			}
		}
	}

	getAcfProFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['acf_pro_fields'] != undefined && fields[i]['acf_pro_fields'] != null) {
				return fields[i].acf_pro_fields;
			}
		}

	}

	getAcfRepeaterFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['acf_repeater_fields'] != undefined && fields[i]['acf_repeater_fields'] != null) {
				return fields[i].acf_repeater_fields;
			}
		}

	}

	getWordpessDefaultCorefields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['core_fields'] != undefined && fields[i]['core_fields'] != null) {
				return fields[i].core_fields;
			}
		}
	}

	getTermsAndTaxonomies(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['terms_and_taxonomies'] != undefined && fields[i]['terms_and_taxonomies'] != null) {
				return fields[i].terms_and_taxonomies
			}
		}
	}

	getTypesFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['types_fields'] != undefined && fields[i]['types_fields'] != null) {
				return fields[i].types_fields
			}
		}
	}

	getPodsFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['pods_fields'] != undefined && fields[i]['pods_fields'] != null) {
				return fields[i].pods_fields
			}
		}
	}

	getCustomFieldSuite(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['custom_fields_suite_fields'] != undefined && fields[i]['custom_fields_suite_fields'] != null) {
				return fields[i].custom_fields_suite_fields
			}
		}
	}

	getAllInOneSeoFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['all_in_one_seo_fields'] != undefined && fields[i]['all_in_one_seo_fields'] != null) {
				return fields[i].all_in_one_seo_fields
			}
		}
	}

	getYoastSeoFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['yoast_seo_fields'] != undefined && fields[i]['yoast_seo_fields'] != null) {
				return fields[i].yoast_seo_fields
			}
		}
	}

	getBillingAndShippingInformation(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['billing_and_shipping_information'] != undefined && fields[i]['billing_and_shipping_information'] != null) {
				return fields[i].billing_and_shipping_information
			}
		}
	}

	getWordPressCustomFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['wordpress_custom_fields'] != undefined && fields[i]['wordpress_custom_fields'] != null || fields[i]['wordpress_custom_fields'] == null && fields[i]['wordpress_custom_fields'] == undefined) {
				return fields[i].wordpress_custom_fields
			}
		}
	}

	getProductMetaFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['product_meta_fields'] != undefined && fields[i]['product_meta_fields'] != null) {
				return fields[i].product_meta_fields
			}
		}
	}

	getCsvHeaderFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['csv_fields'] != undefined && fields[i]['csv_fields'] != null) {
				return fields[i].csv_fields
			}
		}
	}

	getCustomFieldsWpMembers(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['custom_fields_wp_members'] != undefined && fields[i]['custom_fields_wp_members'] != null) {
				return fields[i].custom_fields_wp_members
			}
		}
	}

	getCustomFieldsMembers(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['custom_fields_members'] != undefined && fields[i]['custom_fields_members'] != null) {
				return fields[i].custom_fields_members
			}
		}
	}

	getWpEcomCustomFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['wp_ecom_custom_fields'] != undefined && fields[i]['wp_ecom_custom_fields'] != null) {
				return fields[i].wp_ecom_custom_fields
			}
		}
	}

	getEventsManagerFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['events_manager_fields'] != undefined && fields[i]['events_manager_fields'] != null) {
				return fields[i].events_manager_fields
			}
		}
	}

	getNextgenGalleryFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['nextgen_gallery_fields'] != undefined && fields[i]['nextgen_gallery_fields'] != null) {
				return fields[i].nextgen_gallery_fields
			}
		}
	}

	getCmb2CustomFields(fields) {
		for(var i=0; i<fields.length; i++) {
			if (fields[i]['cmb2_fields'] != undefined && fields[i]['cmb2_fields'] != null) {
				return fields[i].cmb2_fields
			}
		}
	}


    async displayTemplates() {
        var formData = new FormData();
        formData.set('action','displayTemplates');

        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        //console.log(response);

        if(response.status == 200 && response.data.success) {
            this.setState({ templates:response.data.info });
			console.log(this.state.templates);
			console.log("Display Templates");
            this.setState({ loading : false, });
       } 
       
    }

    // Edit Template Function

    async editTemplate(templateName, modules, index) {
		var formData = new FormData();
        formData.set('action','templateinfo');
        formData.set('TemplateName', templateName);
		formData.set('Types', modules);
        formData.set('HashKey',"");
        
        this.setState({
            loading : true, });
            
        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        if (response.status == 200)	{
			console.log(response.data);
			if(response.data.success) {
				this.setState({loading: false})
                this.context.setCsvHeaderFields(response.data.csv_fields);

				var acf_fields = this.getAcfFreeFields(response.data.fields);
				if(acf_fields != undefined) {
						this.context.showAcfFreeFields(true);
						this.context.setAcfFreeFields(acf_fields);
				}
								
				var acf_group_fields = this.getAcfGroupFields(response.data.fields);
				if (acf_group_fields  != undefined) {
					this.context.showAcfGroupFields(true);
					this.context.setAcfGroupFields(acf_group_fields);
				}

				var acf_pro_fields = this.getAcfProFields(response.data.fields);
				if (acf_pro_fields != undefined) {
					this.context.showAcfProFields(true);
					this.context.setAcfProFields(acf_pro_fields);
				}

				var acf_repeater_fields = this.getAcfRepeaterFields(response.data.fields);
				if (acf_repeater_fields != undefined) {
					this.context.showAcfRepeaterFields(true);
					this.context.setAcfRepeaterFields(acf_repeater_fields);
				}

				var wordpress_default_corefields= this.getWordpessDefaultCorefields(response.data.fields);
				if (wordpress_default_corefields != undefined) {
					this.context.showWordPressDefaultCoreFields(true);
					this.context.setWordPressDefaultCoreFields(wordpress_default_corefields);
				}
				
				var terms_and_taxonomies = this.getTermsAndTaxonomies(response.data.fields);
				if (terms_and_taxonomies != undefined) {
					this.context.showTermsAndTaxonomies(true);
					this.context.setTermsAndTaxonomies(terms_and_taxonomies);
				}

				var types_fields = this.getTypesFields(response.data.fields);
				if (types_fields != undefined) {
					this.context.showTypesFields(true);
					this.context.setTypesFields(types_fields);
				}

				var pods_fields = this.getPodsFields(response.data.fields);
				if (pods_fields != undefined) {
					this.context.showPodsFields(true);
					this.context.setPodsFields(pods_fields);
				}

				var custom_fields_suite_fields = this.getCustomFieldSuite(response.data.fields);
				if (custom_fields_suite_fields != undefined) {
					this.context.showCustomFieldSuite(true);
					this.context.setCustomFieldSuite(custom_fields_suite_fields);
				}

				var all_in_one_seo_fields = this.getAllInOneSeoFields(response.data.fields);
				if (all_in_one_seo_fields != undefined) {
					this.context.showAllInOneSeoFields(true);
					this.context.setAllInOneSeoFields(all_in_one_seo_fields)
				}

				var yoast_seo_fields = this.getYoastSeoFields(response.data.fields);
				if (yoast_seo_fields != undefined) {
					this.context.showYoastSeoFields(true);
					this.context.setYoastSeoFields(yoast_seo_fields)
				}

				var billing_and_shipping_information = this.getBillingAndShippingInformation(response.data.fields);
				if (billing_and_shipping_information != undefined) {
					this.context.showBillingAndShippingInformation(true);
					this.context.setBillingAndShippingInformation(billing_and_shipping_information);
				}
				
				var wordpress_custom_fields = this.getWordPressCustomFields(response.data.fields);
				if (wordpress_custom_fields != undefined) {
					this.context.showWordPressCustomFields(true);
					this.context.setWordPressCustomFields(wordpress_custom_fields);
				}
				if (wordpress_custom_fields == undefined) {
					this.context.showWordPressCustomFields(true);
					this.context.setWordPressCustomFields(wordpress_custom_fields);
				}

				var product_meta_fields = this.getProductMetaFields(response.data.fields);
				if (product_meta_fields != undefined) {
						this.context.showProductMetaFields(true);
						this.context.setProductMetaFields(product_meta_fields);
				}

				var custom_fields_wp_members = this.getCustomFieldsWpMembers(response.data.fields);
				if (custom_fields_wp_members != undefined) {
						this.context.showCustomFieldsWpMembers(true);
						this.context.setCustomFieldsWpMembers(custom_fields_wp_members);
				}

				var custom_fields_members = this.getCustomFieldsMembers(response.data.fields);
				if (custom_fields_members != undefined) {
						this.context.showCustomFieldsMembers(true);
						this.context.setCustomFieldsMembers(custom_fields_members);
				}

				var wp_ecom_custom_fields = this.getWpEcomCustomFields(response.data.fields);
				if(wp_ecom_custom_fields != undefined) {
						this.context.showWpEcomCustomFields(true);
						this.context.setWpEcomCustomFields(wp_ecom_custom_fields);
				}

				var events_manager_fields = this.getEventsManagerFields(response.data.fields);
				if(events_manager_fields != undefined) {
						this.context.showEventsManagerFields(true);
						this.context.setEventsManagerFields(events_manager_fields);
				}

				var nextgen_gallery_fields = this.getNextgenGalleryFields(response.data.fields);
				if(nextgen_gallery_fields != undefined) {
						this.context.showNextgenGalleryFields(true);
						this.context.setNextgenGalleryFields(nextgen_gallery_fields);
				}

				var cmb2_fields = this.getCmb2CustomFields(response.data.fields);
				if(cmb2_fields != undefined) {
						this.context.showCmb2CustomFields(true);
						this.context.setCmb2CustomFields(cmb2_fields);
				}
				
				var mappedFields = [];

				if((response.data.mapping_type === "") || (response.data.mapping_type === null) || (response.data.mapping_type === "normal")) {
					if(response.data.already_mapped['CORE']) {
						var fieldname = response.data.already_mapped.CORE;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							for(var key in fieldname) {
								for(j=0; j<this.context.wordPressCoreFields.length; j++) {
									if(this.context.wordPressCoreFields[j].name === key) {
										if((this.context.csvHeaderFields[i] === fieldname[key])) {
												alreadyMappedFields =`{"wp_name":"${this.context.wordPressCoreFields[j].name}","csv_header":"${fieldname[key]}","type":"core"}`
												mappedFields.push(JSON.parse(alreadyMappedFields));
										}																	
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.wordPressCoreFields.length; j++) {
								if(this.context.wordPressCoreFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.wordPressCoreFields[j].name}","csv_header":"${fieldname[key]}","type":"core"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}						
					}
							
									
					if(response.data.already_mapped['ACF']) {
						var fieldname = response.data.already_mapped.ACF;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {								
								for(var j=0; j<this.context.acfFreeFields.length; j++) {
									if(this.context.acfFreeFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.acfFreeFields[j].name}","csv_header":"${fieldname[key]}","type":"acffree"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.acfFreeFields.length; j++) {
								if(this.context.acfFreeFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.acfFreeFields[j].name}","csv_header":"${fieldname[key]}","type":"acffree"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}		
					}				
					if(response.data.already_mapped['ACF']) {
						var fieldname = response.data.already_mapped.ACF;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.acfProFields.length; j++) {
									if(this.context.acfProFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.acfProFields[j].name}","csv_header":"${fieldname[key]}","type":"acf"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.acfProFields.length; j++) {
								if(this.context.acfProFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.acfProFields[j].name}","csv_header":"${fieldname[key]}","type":"acf"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}		
					}			
					if(response.data.already_mapped['RF']) {
						var fieldname = response.data.already_mapped.RF;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.acfRepeaterFields.length; j++) {
									if(this.context.acfRepeaterFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.acfRepeaterFields[j].name}","csv_header":"${fieldname[key]}","type":"acfrepeater"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.acfRepeaterFields.length; j++) {
								if(this.context.acfRepeaterFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.acfRepeaterFields[j].name}","csv_header":"${fieldname[key]}","type":"acfrepeater"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}		
					}		
					if(response.data.already_mapped['GF']) {
						var fieldname = response.data.already_mapped.GF;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.acfGroupFields.length; j++) {
									if(this.context.acfGroupFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.acfGroupFields[j].name}","csv_header":"${fieldname[key]}","type":"acfgroupfields"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.acfGroupFields.length; j++) {
								if(this.context.acfGroupFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.acfGroupFields[j].name}","csv_header":"${fieldname[key]}","type":"acfgroupfields"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}		
					}
					if(response.data.already_mapped['TYPES']) {
						var fieldname = response.data.already_mapped.TYPES;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.typesFields.length; j++) {
									if(this.context.typesFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.typesFields[j].name}","csv_header":"${fieldname[key]}","type":"toolsettypes"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.typesFields.length; j++) {
								if(this.context.typesFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.typesFields[j].name}","csv_header":"${fieldname[key]}","type":"toolsettypes"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}		
					}		
					if(response.data.already_mapped['PODS']) {
						var fieldname = response.data.already_mapped.PODS;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.podsFields.length; j++) {
									if(this.context.podsFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.podsFields[j].name}","csv_header":"${fieldname[key]}","type":"podstypesfields"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.podsFields.length; j++) {
								if(this.context.podsFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.podsFields[j].name}","csv_header":"${fieldname[key]}","type":"podstypesfields"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}	
					}		
					if(response.data.already_mapped['CFS']) {
						var fieldname = response.data.already_mapped.CFS;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.customFieldSuiteFields.length; j++) {
									if(this.context.customFieldSuiteFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.customFieldSuiteFields[j].name}","csv_header":"${fieldname[key]}","type":"customfieldsuitefields"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.customFieldSuiteFields.length; j++) {
								if(this.context.customFieldSuiteFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.customFieldSuiteFields[j].name}","csv_header":"${fieldname[key]}","type":"customfieldsuitefields"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}	
					}		
					if(response.data.already_mapped['AIOSEO']) {
						var fieldname = response.data.already_mapped.AIOSEO;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.allInOneSeoFields.length; j++) {
									if(this.context.allInOneSeoFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.allInOneSeoFields[j].name}","csv_header":"${fieldname[key]}","type":"allinoneseo"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.allInOneSeoFields.length; j++) {
								if(this.context.allInOneSeoFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.allInOneSeoFields[j].name}","csv_header":"${fieldname[key]}","type":"allinoneseo"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}	
					}		
					if(response.data.already_mapped['YOASTSEO']) {
						var fieldname = response.data.already_mapped.YOASTSEO;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.yoastSeoFields.length; j++) {
									if(this.context.yoastSeoFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.yoastSeoFields[j].name}","csv_header":"${fieldname[key]}","type":"yoastseo"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.yoastSeoFields.length; j++) {
								if(this.context.yoastSeoFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.yoastSeoFields[j].name}","csv_header":"${fieldname[key]}","type":"yoastseo"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}	
					}		
					if(response.data.already_mapped['BSI']) {
						var fieldname = response.data.already_mapped.BSI;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.billingAndShippingInformation.length; j++) {
									if(this.context.billingAndShippingInformation[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {
											this.alreadyMappedState = true;										
											alreadyMappedFields =`{"wp_name":"${this.context.billingAndShippingInformation[j].name}","csv_header":"${fieldname[key]}","type":"billingandshippinginformation"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.billingAndShippingInformation.length; j++) {
								if(this.context.billingAndShippingInformation[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.billingAndShippingInformation[j].name}","csv_header":"${fieldname[key]}","type":"billingandshippinginformation"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}	
					}		
					if(response.data.already_mapped['WPMEMBERS']) {
						var fieldname = response.data.already_mapped.WPMEMBERS;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.customFieldsWpMembersFields.length; j++) {
									if(this.context.customFieldsWpMembersFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {	
											this.alreadyMappedState = true;									
											alreadyMappedFields =`{"wp_name":"${this.context.customFieldsWpMembersFields[j].name}","csv_header":"${fieldname[key]}","type":"customfieldswpmember"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.customFieldsWpMembersFields.length; j++) {
								if(this.context.customFieldsWpMembersFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.customFieldsWpMembersFields[j].name}","csv_header":"${fieldname[key]}","type":"customfieldswpmember"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}	
					}
					if(response.data.already_mapped['MULTIROLE']) {
						var fieldname = response.data.already_mapped.MULTIROLE;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.customFieldsMembersFields.length; j++) {
									if(this.context.customFieldsMembersFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;	
											alreadyMappedFields =`{"wp_name":"${this.context.customFieldsMembersFields[j].name}","csv_header":"${fieldname[key]}","type":"customfieldsmember"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.customFieldsMembersFields.length; j++) {
								if(this.context.customFieldsMembersFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.customFieldsMembersFields[j].name}","csv_header":"${fieldname[key]}","type":"customfieldsmember"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}	
					}		
					if(response.data.already_mapped['ECOMMETA']) {
						var fieldname = response.data.already_mapped.ECOMMETA;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.productMetaFields.length; j++) {
									if(this.context.productMetaFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;	
											alreadyMappedFields =`{"wp_name":"${this.context.productMetaFields[j].name}","csv_header":"${fieldname[key]}","type":"productmetafields"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.productMetaFields.length; j++) {
								if(this.context.productMetaFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.productMetaFields[j].name}","csv_header":"${fieldname[key]}","type":"productmetafields"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}	
					}	
					if(response.data.already_mapped['WPECOMMETA']) {
						var fieldname = response.data.already_mapped.WPECOMMETA;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.wpEcomCustomFields.length; j++) {
									if(this.context.wpEcomCustomFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.wpEcomCustomFields[j].name}","csv_header":"${fieldname[key]}","type":"wpecomcustomfields"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.wpEcomCustomFields.length; j++) {
								if(this.context.wpEcomCustomFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.wpEcomCustomFields[j].name}","csv_header":"${fieldname[key]}","type":"wpecomcustomfields"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}	
					}	
					if(response.data.already_mapped['EVENTS']) {
						var fieldname = response.data.already_mapped.EVENTS;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.eventsManagerFields.length; j++) {
									if(this.context.eventsManagerFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.eventsManagerFields[j].name}","csv_header":"${fieldname[key]}","type":"eventsmanagerfields"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.eventsManagerFields.length; j++) {
								if(this.context.eventsManagerFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.eventsManagerFields[j].name}","csv_header":"${fieldname[key]}","type":"eventsmanagerfields"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}	
					}
					if(response.data.already_mapped['NEXTGEN']) {
						var fieldname = response.data.already_mapped.NEXTGEN;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.nextgenGalleryFields.length; j++) {
									if(this.context.nextgenGalleryFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.nextgenGalleryFields[j].name}","csv_header":"${fieldname[key]}","type":"nextgengalleryfields"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.nextgenGalleryFields.length; j++) {
								if(this.context.nextgenGalleryFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.nextgenGalleryFields[j].name}","csv_header":"${fieldname[key]}","type":"nextgengalleryfields"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}	
					}	
					if(response.data.already_mapped['CMB2']) {
						var fieldname = response.data.already_mapped.CMB2;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.cmb2CustomFields.length; j++) {
									if(this.context.cmb2CustomFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;
											alreadyMappedFields =`{"wp_name":"${this.context.cmb2CustomFields[j].name}","csv_header":"${fieldname[key]}","type":"cmb2customfields"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.cmb2CustomFields.length; j++) {
								if(this.context.cmb2CustomFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.cmb2CustomFields[j].name}","csv_header":"${fieldname[key]}","type":"cmb2customfields"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}	
					}	
					/*if(response.data.already_mapped['CORECUSTFIELDS']) {
						var fieldname = response.data.already_mapped.CORECUSTFIELDS;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.wordPressCustomFields.length; j++) {
										if(this.context.wordPressCustomFields[j].name === key) {
											if(this.context.csvHeaderFields[i] === fieldname[key]) {
												this.alreadyMappedState = true;										
												alreadyMappedFields =`{"wp_name":"${this.context.wordPressCustomFields[j].name}","csv_header":"${fieldname[key]}","type":"wordpresscutomfields"}`
												mappedFields.push(JSON.parse(alreadyMappedFields));
											}
										}
								}								
							}
							if(!this.alreadyMappedState) {
								for(var key in fieldname) {
									for(j=0; j<this.context.wordPressCustomFields.length; j++) {
										if(this.context.wordPressCustomFields[j].name === key) {
											if((this.context.csvHeaderFields[i] !== fieldname[key]) && (fieldname[key] !== "")) {
												alreadyMappedFields =`{"wp_name":"${this.context.wordPressCustomFields[j].name}","csv_header":"${fieldname[key]}","type":"wordpresscutomfields"}`
												mappedFields.push(JSON.parse(alreadyMappedFields));
											}
										}
									}
								}
							} 		
						}
					} */
					
					if(response.data.already_mapped['COREUSERCUSTFIELDS']) {
						var fieldname = response.data.already_mapped.COREUSERCUSTFIELDS;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								if(fieldname[key] === this.context.csvHeaderFields[i]) {
									this.context.totalRows = this.context.totalRows + 1;
									this.context.totalCustomFields.push(this.context.totalRows);
									this.context.wordPressUserCustomFields[this.context.totalRows-1] = key;
									alreadyMappedFields =`{"wp_name":"${this.context.wordPressUserCustomFields[this.context.totalRows-1]}","csv_header":"${fieldname[key]}","type":"wordpressusercustomfields"}`
									mappedFields.push(JSON.parse(alreadyMappedFields));
								}
							}
						}
					}	
					if(response.data.already_mapped['TERMS']) {
						var fieldname = response.data.already_mapped.TERMS;
						var alreadyMappedFields={};
						for(var i=0; i<this.context.csvHeaderFields.length; i++) {
							this.alreadyMappedState = false;
							for(var key in fieldname) {
								for(var j=0; j<this.context.termsAndTaxonomiesFields.length; j++) {
									if(this.context.termsAndTaxonomiesFields[j].name === key) {
										if(this.context.csvHeaderFields[i] === fieldname[key]) {										
											this.alreadyMappedState = true;	
											alreadyMappedFields =`{"wp_name":"${this.context.termsAndTaxonomiesFields[j].name}","csv_header":"${fieldname[key]}","type":"termsandtaxonomies"}`
											mappedFields.push(JSON.parse(alreadyMappedFields));
										}
									}
								}
							}
						}
						for(var key in fieldname) {
							for(j=0; j<this.context.termsAndTaxonomiesFields.length; j++) {
								if(this.context.termsAndTaxonomiesFields[j].name === key) {
									var count = 0;
									for(var k=0; k<this.context.csvHeaderFields.length; k++) {
										if((fieldname[key] !== "") && (this.context.csvHeaderFields[k] !== fieldname[key])) {
											count = count + 1
										}
									}
									if(count == this.context.csvHeaderFields.length + 1) {
										alreadyMappedFields =`{"wp_name":"${this.context.termsAndTaxonomiesFields[j].name}","csv_header":"${fieldname[key]}","type":"termsandtaxonomies"}`
										mappedFields.push(JSON.parse(alreadyMappedFields));
									}									
								}
							}
						}		
					}
            			
				this.context.saveMappedFields(mappedFields);
				this.context.setCsvHeaderFields(response.data.csv_fields);
				this.context.changeUseExistingMappingState(true);
				this.context.changeCreateNewMappingState(false);
                this.context.changeActivateSaveMappingTemplateSectionState(false);
                this.context.changeActivateMappingSectionState(true);
				this.context.changeActivateTemplateSectionState(false);
				this.context.selectedTemplateInManager(templateName);
				this.context.selectedEditedTemplateInManager(templateName);
				this.context.selectedModuleInManager(modules);
				this.context.selectedEditedTemplateInManager(templateName);
				this.context.fromTemplateMappingSectionState(true);	
					
			} 

			if(response.data.mapping_type === "advanced") {
				if(response.data.already_mapped['CORE']) {
					var fieldname = response.data.already_mapped.CORE;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.wordPressCoreFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.wordPressCoreFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.wordPressCoreFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.wordPressCoreFields[i].name}","csv_header":"${fieldname[key]}","type":"core"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.wordPressCoreFields[i].name}","csv_header":"","type":"core"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.wordPressCoreFields[i]["csvheader"] = "";
						}
					}
				}
				if(response.data.already_mapped['ACF']) {
					var fieldname = response.data.already_mapped.ACF;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.acfFreeFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.acfFreeFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.acfFreeFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.acfFreeFields[i].name}","csv_header":"${fieldname[key]}","type":"acffree"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.acfFreeFields[i].name}","csv_header":"","type":"acffree"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.acfFreeFields[i]["csvheader"] = "";
						}
					}
				}

				if(response.data.already_mapped['ACF']) {
					var fieldname = response.data.already_mapped.ACF;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.acfProFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.acfProFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.acfProFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.acfProFields[i].name}","csv_header":"${fieldname[key]}","type":"acf"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.acfProFields[i].name}","csv_header":"","type":"acf"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.acfProFields[i]["csvheader"] = "";
						}
					}
				}

				if(response.data.already_mapped['RF']) {
					var fieldname = response.data.already_mapped.RF;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.acfRepeaterFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.acfRepeaterFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.acfRepeaterFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.acfRepeaterFields[i].name}","csv_header":"${fieldname[key]}","type":"acfrepeater"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.acfRepeaterFields[i].name}","csv_header":"","type":"acfrepeater"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.acfRepeaterFields[i]["csvheader"] = "";
						}
					}
				}

				if(response.data.already_mapped['GF']) {
					var fieldname = response.data.already_mapped.GF;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.acfGroupFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.acfGroupFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.acfGroupFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.acfGroupFields[i].name}","csv_header":"${fieldname[key]}","type":"acfgroupfields"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.acfGroupFields[i].name}","csv_header":"","type":"acfgroupfields"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.acfGroupFields[i]["csvheader"] = "";
						}
					}
				}

				if(response.data.already_mapped['TYPES']) {
					var fieldname = response.data.already_mapped.TYPES;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.typesFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.typesFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.typesFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.typesFields[i].name}","csv_header":"${fieldname[key]}","type":"toolsettypes"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.typesFields[i].name}","csv_header":"","type":"toolsettypes"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.typesFields[i]["csvheader"] = "";
						}
					}
				}

				if(response.data.already_mapped['PODS']) {
					var fieldname = response.data.already_mapped.PODS;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.podsFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.podsFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.podsFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.podsFields[i].name}","csv_header":"${fieldname[key]}","type":"podstypesfields"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.podsFields[i].name}","csv_header":"","type":"podstypesfields"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.podsFields[i]["csvheader"] = "";
						}
					}
				}	
				
				if(response.data.already_mapped['CFS']) {
					var fieldname = response.data.already_mapped.CFS;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.customFieldSuiteFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.customFieldSuiteFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.customFieldSuiteFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.customFieldSuiteFields[i].name}","csv_header":"${fieldname[key]}","type":"customfieldsuitefields"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.customFieldSuiteFields[i].name}","csv_header":"","type":"customfieldsuitefields"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.customFieldSuiteFields[i]["csvheader"] = "";
						}
					}
				}
				
				if(response.data.already_mapped['AIOSEO']) {
					var fieldname = response.data.already_mapped.AIOSEO;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.allInOneSeoFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.allInOneSeoFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.allInOneSeoFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.allInOneSeoFields[i].name}","csv_header":"${fieldname[key]}","type":"allinoneseo"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.allInOneSeoFields[i].name}","csv_header":"","type":"allinoneseo"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.allInOneSeoFields[i]["csvheader"] = "";
						}
					}
				}	
				
				if(response.data.already_mapped['YOASTSEO']) {
					var fieldname = response.data.already_mapped.YOASTSEO;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.yoastSeoFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.yoastSeoFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.yoastSeoFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.yoastSeoFields[i].name}","csv_header":"${fieldname[key]}","type":"yoastseo"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.yoastSeoFields[i].name}","csv_header":"","type":"yoastseo"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.yoastSeoFields[i]["csvheader"] = "";
						}
					}
				}	
				
				if(response.data.already_mapped['BSI']) {
					var fieldname = response.data.already_mapped.BSI;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.billingAndShippingInformation.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.billingAndShippingInformation[i].name === key) {
								this.alreadyMappedState = true;
								this.context.billingAndShippingInformation[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.billingAndShippingInformation[i].name}","csv_header":"${fieldname[key]}","type":"billingandshippinginformation"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.billingAndShippingInformation[i].name}","csv_header":"","type":"billingandshippinginformation"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.billingAndShippingInformation[i]["csvheader"] = "";
						}
					}
				}	

				if(response.data.already_mapped['WPMEMBERS']) {
					var fieldname = response.data.already_mapped.WPMEMBERS;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.customFieldsWpMembersFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.customFieldsWpMembersFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.customFieldsWpMembersFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.customFieldsWpMembersFields[i].name}","csv_header":"${fieldname[key]}","type":"customfieldswpmember"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.customFieldsWpMembersFields[i].name}","csv_header":"","type":"customfieldswpmember"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.customFieldsWpMembersFields[i]["csvheader"] = "";
						}
					}
				}

				if(response.data.already_mapped['MULTIROLE']) {
					var fieldname = response.data.already_mapped.MULTIROLE;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.customFieldsMembersFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.customFieldsMembersFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.customFieldsMembersFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.customFieldsMembersFields[i].name}","csv_header":"${fieldname[key]}","type":"customfieldsmember"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.customFieldsMembersFields[i].name}","csv_header":"","type":"customfieldsmember"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.customFieldsMembersFields[i]["csvheader"] = "";
						}
					}
				}	
				
				if(response.data.already_mapped['ECOMMETA']) {
					var fieldname = response.data.already_mapped.ECOMMETA;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.productMetaFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.productMetaFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.productMetaFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.productMetaFields[i].name}","csv_header":"${fieldname[key]}","type":"productmetafields"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.productMetaFields[i].name}","csv_header":"","type":"productmetafields"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.productMetaFields[i]["csvheader"] = "";
						}
					}
				}	
				
				if(response.data.already_mapped['WPECOMMETA']) {
					var fieldname = response.data.already_mapped.WPECOMMETA;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.wpEcomCustomFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.wpEcomCustomFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.wpEcomCustomFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.wpEcomCustomFields[i].name}","csv_header":"${fieldname[key]}","type":"wpecomcustomfields"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.wpEcomCustomFields[i].name}","csv_header":"","type":"wpecomcustomfields"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.wpEcomCustomFields[i]["csvheader"] = "";
						}
					}
				}		
				
				if(response.data.already_mapped['EVENTS']) {
					var fieldname = response.data.already_mapped.EVENTS;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.eventsManagerFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.eventsManagerFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.eventsManagerFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.eventsManagerFields[i].name}","csv_header":"${fieldname[key]}","type":"eventsmanagerfields"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.eventsManagerFields[i].name}","csv_header":"","type":"eventsmanagerfields"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.eventsManagerFields[i]["csvheader"] = "";
						}
					}
				}	
				
				if(response.data.already_mapped['NEXTGEN']) {
					var fieldname = response.data.already_mapped.NEXTGEN;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.nextgenGalleryFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.nextgenGalleryFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.nextgenGalleryFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.nextgenGalleryFields[i].name}","csv_header":"${fieldname[key]}","type":"nextgengalleryfields"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.nextgenGalleryFields[i].name}","csv_header":"","type":"nextgengalleryfields"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.nextgenGalleryFields[i]["csvheader"] = "";
						}
					}
				}	
				
				if(response.data.already_mapped['CMB2']) {
					var fieldname = response.data.already_mapped.CMB2;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.cmb2CustomFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.cmb2CustomFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.cmb2CustomFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.cmb2CustomFields[i].name}","csv_header":"${fieldname[key]}","type":"cmb2customfields"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.cmb2CustomFields[i].name}","csv_header":"","type":"cmb2customfields"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.cmb2CustomFields[i]["csvheader"] = "";
						}
					}
				}	
				
				/*if(response.data.already_mapped['CORECUSTFIELDS']) {
					var fieldname = response.data.already_mapped.CORECUSTFIELDS;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.wordPressCustomFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.wordPressCustomFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.wordPressCustomFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.wordPressCustomFields[i].name}","csv_header":"${fieldname[key]}","type":"wordpresscustomfields"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.wordPressCustomFields[i].name}","csv_header":"","type":"wordpresscustomfields"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.wordPressCustomFields[i]["csvheader"] = "";
						}
					}
				}*/


				if(response.data.already_mapped['COREUSERCUSTFIELDS']) {
					var fieldname = response.data.already_mapped.COREUSERCUSTFIELDS;
					var alreadyMappedFields={};
					// for(var i=0; i<this.context.wordPressUserCustomFields.length; i++) {
					// 	this.alreadyMappedState = false;
						var i=0;
						for(var key in fieldname) {
							this.context.totalCustomFields.push(i);
							this.context.wordPressUserCustomFields.push({ "name": key, "csvheader": fieldname[key] });
							// this.context.wordPressUserCustomFields[i]["csvheader"] = fieldname[key];
							// this.context.wordPressUserCustomFields[i]["name"] = key;
							alreadyMappedFields =`{"wp_name":"${key}","csv_header":"${fieldname[key]}","type":"wordpressusercustomfields"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							i = i+1;
						}
						
						
						// if(!this.alreadyMappedState) {
						// 	alreadyMappedFields =`{"wp_name":"${this.context.wordPressUserCustomFields[i].name}","csv_header":"","type":"wordpressusercustomfields"}`
						// 	mappedFields.push(JSON.parse(alreadyMappedFields));
						// 	this.context.wordPressUserCustomFields[i]["csvheader"] = "";
						// }
				}
					
				
				if(response.data.already_mapped['TERMS']) {
					var fieldname = response.data.already_mapped.TERMS;
					var alreadyMappedFields={};
					for(var i=0; i<this.context.termsAndTaxonomiesFields.length; i++) {
						this.alreadyMappedState = false;
						for(var key in fieldname) {
							if(this.context.termsAndTaxonomiesFields[i].name === key) {
								this.alreadyMappedState = true;
								this.context.termsAndTaxonomiesFields[i]["csvheader"] = fieldname[key];
								alreadyMappedFields =`{"wp_name":"${this.context.termsAndTaxonomiesFields[i].name}","csv_header":"${fieldname[key]}","type":"termsandtaxonomies"}`
								mappedFields.push(JSON.parse(alreadyMappedFields));
							}
						}
						if(!this.alreadyMappedState) {
							alreadyMappedFields =`{"wp_name":"${this.context.termsAndTaxonomiesFields[i].name}","csv_header":"","type":"termsandtaxonomies"}`
							mappedFields.push(JSON.parse(alreadyMappedFields));
							this.context.termsAndTaxonomiesFields[i]["csvheader"] = "";
						}
					}
				}
				this.context.saveMappedFields(mappedFields);
				this.context.setCsvHeaderFields(response.data.csv_fields);
				this.context.changeUseExistingMappingState(true);
				this.context.changeCreateNewMappingState(false);
				this.context.selectedTemplateInManager(templateName);
				this.context.selectedEditedTemplateInManager(templateName);
				this.context.selectedModuleInManager(modules);
				this.context.selectedEditedTemplateInManager(templateName);
				this.context.fromTemplateMappingSectionState(true);	
                this.context.changeActivateSaveMappingTemplateSectionState(false);
                this.context.changeActivateDragAndDropSectionState(true);
				this.context.changeActivateTemplateSectionState(false);
				
			}


			
			
        }           
	}
}

    // Delete Template Function
    
    async deleteTemplate(templateName,index){
        var formData = new FormData();
        formData.set('action','deleteTemplate');
        formData.set('TemplateName',templateName);

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        if(response.status == 200 && response.data.success) {
            console.log(response);
            let templates = this.state.templates;
            templates.splice(index, 1);
            this.setState ({ templates });
            toast.success('Template Deleted Successfully');        
       } 
    }

    
    render() {
        return (
            ((this.context.activateTemplateSectionState) && (!this.context.activateMappingSection)) ?
            <div className="col-sm-8 col-md-9">
                <div className="setting-tab-pane setting-tabpane4 active">
                    <div className="row justify-content-center">
                        <div className="col-md-12 mt20">
                            <h1 className="main-heading">{this.context.translateLanguage.TemplateInfo}</h1>

                            <table className="table table-manager">
                                <thead>
                                    <tr>
                                        <th>{this.context.translateLanguage.TemplateName}</th>
                                        <th>{this.context.translateLanguage.Module}</th>
                                        <th>{this.context.translateLanguage.CreatedTime}</th>
                                        <th className="text-center">{this.context.translateLanguage.Actions}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                {/* {(this.state.loading) ?
                                    <tr><td colspan="4"><div className="loader loader-1 mt15"></div></td></tr>

									:  */}
									{( this.state.templates.length !== 0) ? this.state.templates.map((template, index) =>                                    
                                    <tr>
                                    <td>{ template.template_name }</td>
                                    <td>{ template.module }</td>
                                    <td>{  moment(template.created_time).format('lll') }</td>
                                    <td>
                                        <ul className="list-inline">
                                            <li className="list-inline-item">
                                                <a className="action-icon" data-toggle="tooltip" onClick={(event)=>{this.editTemplate(template.template_name,template.module,index);}} title="Edit">
                                                    <i className="csv-icon-edit-2"></i>
                                                </a>
                                            </li>
                                            <li className="list-inline-item" onClick={(event)=>{this.deleteTemplate(template.template_name,index);}}>
                                                <a className="action-icon" data-toggle="tooltip" title="Delete">
                                                    <i className="csv-icon-trash-2"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </td>
                                </tr> ) : <tr>
                                                    <td colspan="6">
                                                        <span className="text-danger">{this.context.translateLanguage.NoTemplateFound}</span>
                                                    </td>
                                                </tr> }
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            : ""
            
        
        
        )
    }
}

export default Templates;
