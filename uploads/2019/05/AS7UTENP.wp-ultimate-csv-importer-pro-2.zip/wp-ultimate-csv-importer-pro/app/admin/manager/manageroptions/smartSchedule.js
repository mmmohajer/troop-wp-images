import React, {Component} from 'react';
var moment = require('moment');
import axios from 'axios';
import { toast } from 'react-toastify';
import DatePicker from "react-datepicker";
import {AppContext} from '../../../context.js';


class SmartSchedule extends Component {
    static contextType = AppContext;
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            scheduleData: [],
            scheduled_time: '',
            scheduled_date: '',
            frequency: '',
            CreatedTime: ''

        }
        this.handleChange = this.handleChange.bind(this);        
    }

    componentDidMount() {
        this.displaySmartSchedule();

        //set Cookies for Manager Page
        this.context.setSelectedTabCookies("manager")  
    }

    handleChange(scheduled_date) {
        //this.state.editData.scheduled_date = scheduled_date
        this.setState({ scheduled_date: scheduled_date });
    }

   
        

    async displaySmartSchedule() {
        var formData = new FormData();
        formData.set('action','display_schedule');
        formData.set('Type','Import');

        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);

        this.setState({ loading : false, });

        if(response.status == 200 && response.data.success) {
            this.setState({ scheduleData:response.data.info });
            // console.log(this.state.scheduleData);
       } 
    }


    async deleteSchedule(CreatedTime,index){
        var formData = new FormData();
        formData.set('action','delete_schedule');
        formData.set('CreatedTime',CreatedTime);
        formData.set('Type','Import');

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        if(response.status == 200 && response.data.success) {
           console.log(response);
            let scheduleData = this.state.scheduleData;
            scheduleData.splice(index, 1);
            this.setState ({ scheduleData });
            toast.success('Scheduled Import Deleted Successfully');
        
       } 
    }

    async editSchedule(CreatedTime,index){
        var formData = new FormData();
        formData.set('action','edit_schedule');
        formData.set('CreatedTime',CreatedTime);
        formData.set('Type','Import');

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);
        
        if(response.status == 200) {
            //this.setState({editData:response.data})
            this.setState(response.data);
            this.setState({CreatedTime:CreatedTime})
        }

        //console.log(this.state.editData);
        document.getElementById('triggerSchedule').click();
    }

    async updateSchedule(){
        
        //console.log(moment(this.state.editData.scheduled_date).format('YYYY-MM-DD'));
        //formData.set('date', moment(this.state.selectedDate).format('MM/DD/YYYY'));

        var formData = new FormData();
        formData.set('action','update_schedule');        
        formData.set('Type','Import');
        formData.set('CreatedTime',this.state.CreatedTime);
        formData.set('ScheduledTime',this.state.scheduled_time);
        formData.set('ScheduledDate', moment(this.state.scheduled_date).format('YYYY-MM-DD'));        
        formData.set('Frequency',this.state.frequency);

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);

        if(response.status == 200 && response.data.success) {           
            toast.success('Schedule Updated Successfully');            
        } else{
            toast.info("Not Updated");
        }

        this.displaySmartSchedule();
    }

    render() {
        const vStyle = {
            verticalAlign:"middle"
          };
        const dataWidth = {
            width:"40%"
          };
        return (
            <div className="col-sm-8 col-md-9">
                <div className="setting-tab-pane setting-tabpane2 active">
                    <div className="row justify-content-center">
                        <div className="col-md-12 mt20">
                            <h1 className="main-heading">{this.context.translateLanguage.ScheduleInfo}</h1>

                            <div className="table-responsive">
                                <table className="table table-manager">
                                    <thead>
                                        <tr>
                                            <th style={dataWidth}>{this.context.translateLanguage.EventInfo}</th>
                                            <th>{this.context.translateLanguage.EventDate}</th>
                                            <th className="text-center">{this.context.translateLanguage.EventStatus}</th>
                                            <th className="text-center">{this.context.translateLanguage.Actions}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    {(this.state.loading) ?
                                    <tr><td colspan="4"><div className="loader loader-1 mt15"></div></td></tr>
                                    : ( this.state.scheduleData.length !== 0) ? this.state.scheduleData.map((schedule, index) => 
                                    <tr>
                                        <td style={dataWidth}>
                                            <p><span className="text-label">{this.context.translateLanguage.FileName} :</span> {schedule.filename } </p>
                                            <p><span className="text-label">{this.context.translateLanguage.Purpose} :</span> {schedule.module }</p>                                                                
                                        </td>
                                        <td>
                                            <p><span className="text-label">{this.context.translateLanguage.ScheduledDate} :</span> { moment(schedule.scheduled_date).format('ll')}</p>
                                            <p><span className="text-label">{this.context.translateLanguage.ScheduledTime} :</span> {schedule.scheduled_time }</p>                                                                
                                        </td>
                                        <td className="text-center" style={vStyle}><span className="badge badge-info">{schedule.status}</span></td>
                                        <td className="text-center" style={vStyle}>
                                            <ul className="list-inline">
                                                <li className="list-inline-item"><a className="action-icon" data-toggle="tooltip" onClick={()=>{this.editSchedule(schedule.created_time,index);}} title="Edit"><i className="csv-icon-edit-2"></i></a></li>
                                                <li className="list-inline-item"><a className="action-icon" data-toggle="tooltip" onClick={()=>{this.deleteSchedule(schedule.created_time,index);}} title="Delete"><i className="csv-icon-trash-2"></i></a></li>
                                            </ul>
                                        </td>
                                    </tr>  ) : 
                                    <tr>
                                        <td colspan="4">
                                            <span className="text-danger">{this.context.translateLanguage.Youhavenotscheduledanyevent}</span>
                                        </td>
                                    </tr> }
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
                {/* <!-- upload media model start --> */}
                <button type="button" className="d-none" data-toggle="modal" data-target="#edit_schedule_data" id="triggerSchedule"></button>
                <div id="edit_schedule_data" className="modal fade"  role="dialog">
                    <div className="modal-dialog modal-lg modal-dialog-centered">          
                        {/* <!-- Modal content--> */}
                        <div className="modal-content">
                            <div className="modal-header">
                            <h1 class="main-heading">{this.context.translateLanguage.EditSchedule}</h1>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div className="modal-body my-2"> 

                            <div class="row">
                                <div className="col-md-8 offset-md-2">
                            
                                <div class="form-group">
                                    <label for="schedule-date">{this.context.translateLanguage.Date} </label>
                                    {/* <input type="text" value={this.state.scheduled_date} class="form-control"  /> */}
                                    <DatePicker className="form-control" selected={this.state.scheduled_date} id="schedule-date" onChange={this.handleChange} />                                
                                </div>
                                <div class="form-group">
                                    <label for="schedule-time">{this.context.translateLanguage.Time}</label>
                                    <input type="text" value={this.state.scheduled_time} class="form-control" onChange={(event) => {this.setState({scheduled_time:event.target.value});}} id="schedule-time" />
                                    <small id="emailHelp"  class="form-text text-muted">21:43</small>
                                </div>
                                <div class="form-group">
                                    <label for="schedule-frequency">{this.context.translateLanguage.Frequency}</label>
                                    <select  class="form-control" value={this.state.frequency} name="" onChange={(event) => {this.setState({frequency:event.target.value});}}  id="schedule-frequency">
                                    <option value="OneTime">{this.context.translateLanguage.OneTime}</option>
                                            <option value="Daily">{this.context.translateLanguage.Daily}</option>
                                            <option value="Weekly">{this.context.translateLanguage.Weekly}</option>
                                            <option value="Monthly">{this.context.translateLanguage.Monthly}</option>
                                            <option value="Hourly">{this.context.translateLanguage.Hourly}</option>
                                            <option value="Every 30 mins">{this.context.translateLanguage.Every30mins}</option>
                                            <option value="Every 15 mins">{this.context.translateLanguage.Every15mins}</option>
                                            <option value="Every 10 mins">{this.context.translateLanguage.Every10mins}</option>
                                            <option value="Every 5 mins">{this.context.translateLanguage.Every5mins}</option>
                                    </select>                                
                                </div> 

                            </div>    

                            </div>            
                                        
                            
                            </div>

                            <div class="modal-footer">
                                <button type="button" onClick={() => {this.updateSchedule();}} data-dismiss="modal" class="smack-btn smack-btn-primary">{this.context.translateLanguage.SaveChanges}</button>                                
                            </div>
                        </div>
                    
                    </div>
            </div>
            {/* <!-- upload media model closed --> */}
            </div>
            
        )
    }
}

export default SmartSchedule;
