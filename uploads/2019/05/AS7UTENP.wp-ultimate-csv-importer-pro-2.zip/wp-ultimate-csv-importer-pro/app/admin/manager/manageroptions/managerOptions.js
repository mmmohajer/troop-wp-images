import React, { Component } from 'react';
import FileManager from './fileManager.js'
import SmartSchedule from './smartSchedule.js'
import ScheduledExport from './scheduledExport.js'
import Templates from './templates.js'
import LogManager from './logManager.js'
import MappingSection from '../../uploader/uploadoptions/mappingSection.js';
import DragAndDropSection from '../../uploader/uploadoptions/dragAndDropSection.js';
import {AppContext} from '../../../context.js';

// import UploadFromDesktop from './uploadFromDesktop.js'
// import UploadFromFtpSftp from './uploadFromFtpSftp.js'
// import UploadFromUrl from './uploadFromUrl.js'
// import UploadFromServer from './uploadFromServer.js'

class ManagerOptions extends Component {
	static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
		    fileManagerTabActive: 'active',
		    smartScheduleTabActive: '',
		    scheduledExportTabActive: '',
		    templatesTabActive: '',
		    logManagerTabActive: ''
		}
	}

	componentDidMount() {
		this.context.setSelectedTabCookies("manager");
	}
		
	showManagerOptions (){
		return(
			<div className="setting-tab-section col-sm-4 col-md-3">
                <ul className="setting-tab">
                <li data-setting="setting-tabpane1" className={`setting-tab-list ${this.state.fileManagerTabActive}`} onClick={(event)=>{this.setState({fileManagerTabActive: 'active', smartScheduleTabActive:'', scheduledExportTabActive: '', templatesTabActive: '', logManagerTabActive: ''})}}><i className="csv-icon-hard-drive1"
                        aria-hidden="true"></i>
                    {this.context.translateLanguage.FileManager}</li>
                <li data-setting="setting-tabpane2" className={`setting-tab-list ${this.state.smartScheduleTabActive}`} onClick={(event)=>{this.setState({smartScheduleTabActive: 'active', fileManagerTabActive: '', scheduledExportTabActive: '', templatesTabActive: '', logManagerTabActive: ''})}}><i className="csv-icon-calendar2"
                        aria-hidden="true"></i>
                    {this.context.translateLanguage.SmartSchedule}</li>
                <li data-setting="setting-tabpane3" className={`setting-tab-list ${this.state.scheduledExportTabActive}`} onClick={(event)=>{this.setState({scheduledExportTabActive: 'active', fileManagerTabActive: '',smartScheduleTabActive:'',templatesTabActive: '', logManagerTabActive: ''})}}><i className="csv-icon-calendar2"
                        aria-hidden="true"></i>{this.context.translateLanguage.ScheduledExport}</li>
                <li data-setting="setting-tabpane4" className={`setting-tab-list ${this.state.templatesTabActive}`} onClick={(event)=>{this.setState({templatesTabActive: 'active', fileManagerTabActive: '', smartScheduleTabActive: '', scheduledExportTabActive: '', logManagerTabActive: ''})}}><i className="csv-icon-layout"
                        aria-hidden="true"></i>{this.context.translateLanguage.Templates}</li>
                <li data-setting="setting-tabpane5" className={`setting-tab-list ${this.state.logManagerTabActive}`} onClick={(event)=>{this.setState({logManagerTabActive: 'active', fileManagerTabActive:'', smartScheduleTabActive: '', scheduledExportTabActive: '',templatesTabActive: ''})}}><i className="csv-icon-layers"
                        aria-hidden="true"></i>{this.context.translateLanguage.LogManager}</li>
            	</ul>
            </div>
			
		)
	}

	render() {
		return(
			((this.context.activateMappingSection) && (!this.context.activateTemplateSectionState)) ? <MappingSection /> :
			((this.context.activateDragAndDropSection) && (!this.context.activateTemplateSectionState)) ? <DragAndDropSection /> :
			<div id="mapping-accordion">
				<div className="card csv-importer-panel mt20">
	    			<div className="row">
					{ this.showManagerOptions()  }
					{(this.state.fileManagerTabActive === "active") ? <FileManager /> : 
					 (this.state.smartScheduleTabActive === "active") ? <SmartSchedule /> :
					 (this.state.scheduledExportTabActive === "active") ? <ScheduledExport /> : 
					 (this.state.templatesTabActive === "active") ? <Templates /> :
					 (this.state.logManagerTabActive === "active") ? <LogManager /> : <div> {this.context.translateLanguage.NotSelectedAnyTab} </div> } 
				
				 	 
					</div>
				</div>
		   	</div>
		);

	}

}

export default ManagerOptions;

