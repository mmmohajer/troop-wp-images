import React, { Component } from 'react';
import {AppContext} from '../../../context.js';

class Documentation extends Component {
    static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
			
		}
    }
    componentDidMount(){
        //set Cookies for Setting Page
        this.context.setSelectedTabCookies("settings")
    }

    render() {
        return(
            <div className="col-sm-8 col-md-9">
             <div className="setting-tab-pane setting-tabpane4 active">
                                <div className="row justify-content-center">
                                    <div className="col-md-10 mt20" >
                                        <h1 className="main-heading">{this.context.translateLanguage.Documentation}</h1>
                                        <div className="embed-responsive embed-responsive-16by9">
                                            <iframe className="embed-responsive-item" src="https://www.youtube.com/embed/GbDlQcbnNJY"
                                                allowfullscreen></iframe>
                                        </div>
                                      

                                        <h1 className="main-heading">{this.context.translateLanguage.SmackcodersGuidelines}</h1>

                                        <ul className="list-unstyled">
                                            <li><a href="https://goo.gl/OAVF9u" target="_blank">{this.context.translateLanguage.DevelopmentNews} </a></li>
                                            <li><a href="https://goo.gl/kKWPui" target="_blank">{this.context.translateLanguage.WhatsNew} </a></li>
                                            <li><a href="https://goo.gl/hyU5G1" target="_blank">{this.context.translateLanguage.Documentation} </a></li>
                                            <li><a href="https://goo.gl/OgW9PJ" target="_blank">{this.context.translateLanguage.YoutubeChannel} </a></li>
                                            <li><a href="https://goo.gl/smw3WV" target="_blank">{this.context.translateLanguage.OtherWordPressPlugins} </a></li>
                                        </ul>

                                        {/* <div class="container">
                                            <div class="row justify-content-center">

                                                <div class="col-md-4">
                                                    <div class="set-box-container">
                                                        <a href="">
                                                            <img src="https://company-assets.freshworks.com/freshdesk-portal/build-community.png" />
                                                            <h2>Development News</h2>
                                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                        </a>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="set-box-container">
                                                        <a href="">
                                                            <img src="https://company-assets.freshworks.com/freshdesk-portal/build-community.png" />
                                                            <h2>Whats New?</h2>
                                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                        </a>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="set-box-container">
                                                        <a href="">
                                                            <img src="https://company-assets.freshworks.com/freshdesk-portal/build-community.png" />
                                                            <h2>Documentation</h2>
                                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                        </a>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="set-box-container">
                                                        <a href="">
                                                            <img src="https://company-assets.freshworks.com/freshdesk-portal/build-community.png" />
                                                            <h2>Youtube Channel</h2>
                                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                        </a>
                                                    </div>
                                                </div>

                                                <div class="col-md-4">
                                                    <div class="set-box-container">
                                                        <a href="">
                                                            <img src="https://company-assets.freshworks.com/freshdesk-portal/build-community.png" />
                                                            <h2>Other WordPress Plugins</h2>
                                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                                                        </a>
                                                    </div>
                                                </div>

                                            </div>
                                        </div> */}
                                         
                                    </div>
                                </div>
                            </div>
                        </div>
        )
    }
}

export default Documentation;
