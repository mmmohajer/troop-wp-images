import React, { Component } from 'react';
import GeneralSettings from './generalSettings.js';
import DatabaseOptimization from './databaseOptimization.js';
import SecurityAndPerformance from './securityAndPerformance.js';
import Documentation from './documentation.js';
import MediaReport from './mediaReport.js';
import {AppContext} from '../../../context.js';


// import UploadFromDesktop from './uploadFromDesktop.js'
// import UploadFromFtpSftp from './uploadFromFtpSftp.js'
// import UploadFromUrl from './uploadFromUrl.js'
// import UploadFromServer from './uploadFromServer.js'

class SettingsOptions extends Component {
	static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
		    generalSettingsTabActive: 'active',
		    databaseOptimizationTabActive: '',
		    securityAndPerformanceTabActive: '',
		    documentationTabActive: '',
		    mediaReportTabActive: ''
		}
	}
		
	showSettingsOptions () {
		return(
		    <div className="setting-tab-section col-sm-4 col-md-3">
                            <ul className="setting-tab">
                                <li data-setting="setting-tabpane1" className={`setting-tab-list ${this.state.generalSettingsTabActive}`} onClick={(event)=>{this.setState({generalSettingsTabActive: 'active', databaseOptimizationTabActive: '', securityAndPerformanceTabActive: '', documentationTabActive: '', mediaReportTabActive: ''})}} ><i className="csv-icon-cog"
                                        aria-hidden="true"></i>
                                    {this.context.translateLanguage.GeneralSettings}</li>
                                <li data-setting="setting-tabpane2" className={`setting-tab-list ${this.state.databaseOptimizationTabActive}`} onClick={(event)=>{this.setState({databaseOptimizationTabActive: 'active', generalSettingsTabActive: '', securityAndPerformanceTabActive: '', documentationTabActive: '', mediaReportTabActive: ''})}} ><i className="csv-icon-database"
                                        aria-hidden="true"></i>
                                    {this.context.translateLanguage.DatabaseOptimization}</li>
                                <li data-setting="setting-tabpane3" className={`setting-tab-list ${this.state.securityAndPerformanceTabActive}`} onClick={(event)=>{this.setState({securityAndPerformanceTabActive: 'active', generalSettingsTabActive: '', databaseOptimizationTabActive: '', documentationTabActive: '', mediaReportTabActive: ''})}} ><i className="csv-icon-settings1"
                                        aria-hidden="true"></i> {this.context.translateLanguage.SecurityandPerformance}</li>
                                <li data-setting="setting-tabpane4" className={`setting-tab-list ${this.state.documentationTabActive}`} onClick={(event)=>{this.setState({documentationTabActive: 'active', generalSettingsTabActive: '', databaseOptimizationTabActive: '', securityAndPerformanceTabActive: '', mediaReportTabActive: ''})}} ><i className="csv-icon-file-text"
                                        aria-hidden="true"></i> {this.context.translateLanguage.Documentation}</li>
                                <li data-setting="setting-tabpane5" className={`setting-tab-list ${this.state.mediaReportTabActive}`} onClick={(event)=>{this.setState({mediaReportTabActive: 'active', generalSettingsTabActive: '', databaseOptimizationTabActive: '', securityAndPerformanceTabActive: '', documentationTabActive: ''})}} ><i className="csv-icon-file-text-o"
                                        aria-hidden="true"></i> {this.context.translateLanguage.MediaReport}</li>
                            </ul>
                        </div>
		)
	}

	render() {
		return(
			<div id="mapping-accordion">
				<div className="card csv-importer-panel mt20">
	    			<div className="row">
					{ this.showSettingsOptions()  }
					{(this.state.generalSettingsTabActive === "active") ? <GeneralSettings /> : 
					 (this.state.databaseOptimizationTabActive === "active") ? <DatabaseOptimization /> :
					 (this.state.securityAndPerformanceTabActive === "active") ? <SecurityAndPerformance /> : 
					 (this.state.documentationTabActive === "active") ? <Documentation /> :
					 (this.state.mediaReportTabActive === "active") ? <MediaReport /> : <div> not selected </div> } 
				 
				 	 
					</div>
				</div>
		   	</div>
		);

	}

}

export default SettingsOptions;

