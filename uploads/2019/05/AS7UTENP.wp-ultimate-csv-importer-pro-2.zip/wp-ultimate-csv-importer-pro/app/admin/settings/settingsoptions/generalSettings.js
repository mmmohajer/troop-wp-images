import React, {Component} from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import {AppContext} from '../../../context.js';
import Cookies from 'universal-cookie';

class GeneralSettings extends Component {
    static contextType = AppContext;
    constructor(props) {
        super(props);
        this.state = {
            loading: false,
            drop_table:false,
            send_log_email:false,
            send_user_password:false,
            woocomattr:false
        }
    }

    componentDidMount() {
        this.displayGeneralSettings();
        
        //set Cookies for Setting Page
        this.context.setSelectedTabCookies("settings")
    }

    async displayGeneralSettings() {
        var formData = new FormData();
        formData.set('action','get_options');

        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

         console.log(response);

         this.setState({ loading : false, });

        //  (response.data.options['drop_table'] === true) ? this.setState({drop_table:true}) : this.setState({drop_table:false});

        if ((response.data.options !== undefined) && (response.data.options !== null)){
            
        }
        this.setState(response.data.options);
        
        
         //console.log(response.data.options['author_editor_access']);

        //  if (response.data.options['author_editor_access']){
             
        //  }

        if(response.status == 200 && response.data.success) {
            //this.setState({ events:response.data.info });
            //console.log(this.state.events);
       } 
    }

    async updateGeneralSetting(event,_settingValue){
        if (_settingValue === "drop_table"){
            this.setState({drop_table:event.target.checked});
        }else if (_settingValue === "send_log_email"){
            this.setState({send_log_email:event.target.checked});
        }else if (_settingValue === "send_user_password"){
            this.setState({send_user_password:event.target.checked});
        }else if (_settingValue === "woocomattr"){
            this.setState({woocomattr:event.target.checked});
        }
        

        console.log(event.target.checked);

        
        
        var formData = new FormData();
        formData.set('action', 'settings_options');
        formData.set('option', _settingValue);
        formData.set('value', event.target.checked);
        //formData.set('value', false);

        // var checkValue = {};
        // checkValue[`${_settingValue}`] = event.target.checked;
        // this.setState(checkValue);


        console.log(this.state[_settingValue]);

        
        
        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log("Response", response);

        this.setState({ loading : false, });

        if(response.status == 200 && (response.data.success)) {
            toast.success('Settings Successfully Updated');
        }
    }

    render() {    
        return (            
            <div className="col-sm-8 col-md-9">
                <div className="setting-tab-pane setting-tabpane1 active">
                    <div className="row justify-content-center">
                        <div className="col-md-10 mt20">
                            <h1 className="main-heading">{this.context.translateLanguage.GeneralSettings} </h1>
                            <div className="form-group row">
                                <div className="col-xs-12 col-sm-8 col-md-8 nopadding">
                                    <h4>{this.context.translateLanguage.DropTable}</h4>
                                    <small className="form-text text-muted">{this.context.translateLanguage.Ifenabledplugindeactivationwillremoveplugindatathiscannotberestored}</small>
                                </div>
                                <div className="col-xs-12 col-sm-4 col-md-3">                                
                                    <div className="form-group col-md-6 fieldset">
                                            <h1>{this.state.drop_table}</h1>
                                        <input type="checkbox" className="form-control" id="drop-table-check" checked={this.state.drop_table}  onChange={(event)=>{this.updateGeneralSetting(event,"drop_table");}} />
                                        <label className="switch-ios" for="drop-table-check">  
                                            <i></i>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div className="form-group row">
                                <div className="col-xs-12 col-sm-8 col-md-8 nopadding">
                                    <h4>{this.context.translateLanguage.Scheduledlogmails}</h4>
                                    <small className="form-text text-muted">{this.context.translateLanguage.Enabletogetscheduledlogmails}</small>
                                </div>
                                <div className="col-xs-12 col-sm-4 col-md-3">
                                    <div className="form-group col-md-6 fieldset">
                                        <input type="checkbox" className="ios-switch" checked={this.state.send_log_email} onClick={(event)=>{this.updateGeneralSetting(event,"send_log_email");}} id="scheduled-log-check"/>
                                        <label className="switch-ios" for="scheduled-log-check">
                                            <i></i>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div className="form-group row">
                                <div className="col-xs-12 col-sm-8 col-md-8 nopadding">
                                    <h4>{this.context.translateLanguage.Sendpasswordtouser}</h4>
                                    <small className="form-text text-muted">{this.context.translateLanguage.Enabletosendpasswordinformationthroughemail}</small>
                                </div>
                                <div className="col-xs-12 col-sm-4 col-md-3">
                                    <div className="form-group col-md-6 fieldset">
                                        <input type="checkbox" className="ios-switch" checked={this.state.send_user_password} onClick={(event)=>{this.updateGeneralSetting(event,"send_user_password");}} id="send-information"/>
                                        <label className="switch-ios" for="send-information">
                                            <i></i>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div className="form-group row">
                                <div className="col-xs-12 col-sm-8 col-md-8 nopadding">
                                    <h4>{this.context.translateLanguage.WoocommerceCustomattribute}</h4>
                                    <small className="form-text text-muted">{this.context.translateLanguage.Enablestoregisterwoocommercecustomattribute}</small>
                                </div>
                                <div className="col-xs-12 col-sm-4 col-md-3">
                                    <div className="form-group col-md-6 fieldset">
                                        <input type="checkbox" className="ios-switch" checked={this.state.woocomattr} onClick={(event)=>{this.updateGeneralSetting(event,"woocomattr");}} id="register-woocommerce"/>
                                        <label className="switch-ios" for="register-woocommerce">
                                            <i></i>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            {/* <div className="form-group row">
                                <div className="col-xs-12 col-sm-8 col-md-8 nopadding">
                                    <h4>CMB2 Meta Fields prefix</h4>
                                    <small className="form-text text-muted">Mention the prefix of your fields.</small>
                                </div>
                                <div className="col-xs-12 col-sm-4 col-md-3 text-center">
                                    <div className="mt20">
                                        <input type="text" placeholder="Your Prefix" class="form-control"/>
                                    </div>
                                </div>
                            </div> */}
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default GeneralSettings;
