import React, { Component } from 'react';
import axios from 'axios';
import {AppContext} from '../../../context.js';

class DatabaseOptimization extends Component {
    static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {            
                orphaned:false,
                unassignedTags:false,
                postpagerevisions:false,
                autodraftedpostpage:false,
                postpagetrash:false,
                spamcomments:false,
                trashedcomments:false,
                unapprovedcomments:false,
                pingbackcomments:false,
                trackbackcomments:false,
                tempData:{}			
		}
    }

    componentDidMount(){
        //set Cookies for Setting Page
        this.context.setSelectedTabCookies("settings")
    }
    
    async getCheckBoxValue(event,params){
        var checkValue = {};
        checkValue[`${params}`] = event.target.checked;
        this.setState(checkValue,()=> {
            // console.log("orphaned",this.state.orphaned);
            // console.log("unassignedTags",this.state.unassignedTags);
            // console.log("postpagerevisions",this.state.postpagerevisions);
            // console.log("autodraftedpostpage",this.state.autodraftedpostpage);
            // console.log("postpagetrash",this.state.postpagetrash);
            // console.log("spamcomments",this.state.spamcomments);
            // console.log("trashedcomments",this.state.trashedcomments);
            // console.log("unapprovedcomments",this.state.unapprovedcomments);
            // console.log("pingbackcomments",this.state.pingbackcomments);
            // console.log("trackbackcomments",this.state.trackbackcomments);
        });
    }

    async dbOptimization(){
        var formData = new FormData();
        formData.set('action', 'database_optimization_process');            
        formData.set("orphaned",this.state.orphaned);
        formData.set("unassignedTags",this.state.unassignedTags);
        formData.set("postpagerevisions",this.state.postpagerevisions);
        formData.set("autodraftedpostpage",this.state.autodraftedpostpage);
        formData.set("postpagetrash",this.state.postpagetrash);
        formData.set("spamcomments",this.state.spamcomments);
        formData.set("trashedcomments",this.state.trashedcomments);
        formData.set("unapprovedcomments",this.state.unapprovedcomments);
        formData.set("pingbackcomments",this.state.pingbackcomments);
        formData.set("trackbackcomments",this.state.trackbackcomments);        
        
        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log("Response", response);

        this.setState({ loading : false, });

        // var p = response.data;

        // var test = {};

        // for (var key in p) {
        //     if (p.hasOwnProperty(key)) {
        //         console.log(key + " -> " + p[key]);
        //         if (p[key] !== "non_affected"){
        //             test[key]=p[key];
        //         }else{
        //             test[key]=false;
        //         }
        //     }
        // }

        this.setState({tempData:response.data});
        //this.setState({tempData:test});

        console.log(this.state.orphaned);

        console.log(this.state);

        document.getElementById('triggerLog').click();

              
    }

    render() {
        return(
            <div className="col-sm-8 col-md-9">
           <div className="setting-tab-pane setting-tabpane2 active dboptimization">
                                <div className="row justify-content-center">
                                    <div className="col-md-10 mt20">
                                        <h1 className="main-heading pb5">{this.context.translateLanguage.DatabaseOptimization}</h1>
                                        <p className="text-danger text-dboptimization" >{this.context.translateLanguage.PleasemakesurethatyoutakenecessarybackupbeforeproceedingwithdatabaseoptimizationThedatalostcantbereverted}</p>
                                        <div className="row mt40">
                                            <div className="col-md-6">
                                                <ul className="database-optimization">
                                                    <li><label><input type="checkbox" checked={this.state.orphaned} onClick={(event)=>{this.getCheckBoxValue(event,"orphaned");}} className="mr10" />{this.context.translateLanguage.DeleteallorphanedPostPageMeta}</label></li>
                                                    <li><label><input type="checkbox" checked={this.state.unassignedTags} onClick={(event)=>{this.getCheckBoxValue(event,"unassignedTags");}} className="mr10" />{this.context.translateLanguage.Deleteallunassignedtags}</label></li>
                                                    <li><label><input type="checkbox" checked={this.state.postpagerevisions} onClick={(event)=>{this.getCheckBoxValue(event,"postpagerevisions");}} className="mr10" />{this.context.translateLanguage.DeleteallPostPagerevisions}</label></li>
                                                    <li><label><input type="checkbox" checked={this.state.autodraftedpostpage} onClick={(event)=>{this.getCheckBoxValue(event,"autodraftedpostpage");}} className="mr10" />{this.context.translateLanguage.DeleteallautodraftedPostPage}</label></li>
                                                    <li><label><input type="checkbox" checked={this.state.postpagetrash} onClick={(event)=>{this.getCheckBoxValue(event,"postpagetrash");}} className="mr10" />{this.context.translateLanguage.DeleteallPostPageintrash}</label></li>
                                                </ul>
                                            </div>
                                            <div className="col-md-6">
                                                <ul className="database-optimization">
                                                    <li><label><input type="checkbox" checked={this.state.trashedcomments} onClick={(event)=>{this.getCheckBoxValue(event,"trashedcomments");}} className="mr10" />{this.context.translateLanguage.DeleteallCommentsintrash}</label></li>
                                                    <li><label><input type="checkbox" checked={this.state.unapprovedcomments} onClick={(event)=>{this.getCheckBoxValue(event,"unapprovedcomments");}} className="mr10" />{this.context.translateLanguage.DeleteallUnapprovedComments}</label></li>
                                                    <li><label><input type="checkbox" checked={this.state.pingbackcomments} onClick={(event)=>{this.getCheckBoxValue(event,"pingbackcomments");}} className="mr10" />{this.context.translateLanguage.DeleteallPingbackComments}</label></li>
                                                    <li><label><input type="checkbox" checked={this.state.trackbackcomments} onClick={(event)=>{this.getCheckBoxValue(event,"trackbackcomments");}} className="mr10" />{this.context.translateLanguage.DeleteallTrackbackComments}</label></li>
                                                    <li><label><input type="checkbox" checked={this.state.spamcomments} onClick={(event)=>{this.getCheckBoxValue(event,"spamcomments");}} className="mr10" />{this.context.translateLanguage.DeleteallSpamComments}</label></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div className="clearfix"></div>
                                        <div className="row mt20">
                                            <div className="col-md-4 offset-md-8">
                                                <input id="database_optimization" onClick={() => {this.dbOptimization();}} className="action smack-btn smack-btn-warning"
                                                    type="button" value={this.context.translateLanguage.RunDBOptimizer} />
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            {/* <!-- upload media model start --> */}
                <button type="button" className="d-none" data-toggle="modal" data-target="#display_db_log" id="triggerLog"></button>
                <div id="display_db_log" className="modal fade"  role="dialog">
                    <div className="modal-dialog modal-lg modal-dialog-centered">          
                        {/* <!-- Modal content--> */}
                        <div className="modal-content">
                            <div className="modal-header">
                            <h1 class="main-heading">{this.context.translateLanguage.DatabaseOptimizationLog}</h1>
                            <button type="button" className="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div className="modal-body my-2"> 
                                        
                            {(this.state.tempData.orphaned !== "non_affected" ) ? <p>( {this.state.tempData.orphaned} ) {this.context.translateLanguage.noofOrphanedPostPagemetahasbeenremoved}</p>  : "" }
                            {(this.state.tempData.unassignedTags !== "non_affected" ) ? <p>( {this.state.tempData.unassignedTags} ) {this.context.translateLanguage.noofUnassignedtagshasbeenremoved}</p>  : "" }
                            {(this.state.tempData.postpagerevisions !== "non_affected" ) ? <p>( {this.state.tempData.postpagerevisions} ) {this.context.translateLanguage.noofPostPagerevisionhasbeenremoved}</p>  : "" }
                            {(this.state.tempData.autodraftedpostpage !== "non_affected" ) ? <p>( {this.state.tempData.autodraftedpostpage} ) {this.context.translateLanguage.noofAutodraftedPostPagehasbeenremoved}</p>  : "" }
                            {(this.state.tempData.postpagetrash !== "non_affected" ) ? <p>( {this.state.tempData.postpagetrash} ) {this.context.translateLanguage.noofPostPageintrashhasbeenremoved}</p>  : "" }
                            {(this.state.tempData.spamcomments !== "non_affected" ) ? <p>( {this.state.tempData.spamcomments} ) {this.context.translateLanguage.noofSpamcommentshasbeenremoved}</p>  : "" }
                            {(this.state.tempData.trashedcomments !== "non_affected" ) ? <p>( {this.state.tempData.trashedcomments} ) {this.context.translateLanguage.noofCommentsintrashhasbeenremoved}</p>  : "" }
                            {(this.state.tempData.unapprovedcomments !== "non_affected" ) ? <p>( {this.state.tempData.unapprovedcomments} ) {this.context.translateLanguage.noofUnapprovedcommentshasbeenremoved}</p>  : "" }
                            {(this.state.tempData.pingbackcomments !== "non_affected" ) ? <p>( {this.state.tempData.pingbackcomments} ) {this.context.translateLanguage.noofPingbackcommentshasbeenremoved}</p>  : "" }
                            {(this.state.tempData.trackbackcomments !== "non_affected" ) ? <p>( {this.state.tempData.trackbackcomments} ) {this.context.translateLanguage.noofTrackbackcommentshasbeenremoved}</p>  : "" }
                            
                            </div>

                            
                        </div>
                    
                    </div>
            </div>
            {/* <!-- upload media model closed --> */}
                        </div>

                        
        )
    }
}

export default DatabaseOptimization;
