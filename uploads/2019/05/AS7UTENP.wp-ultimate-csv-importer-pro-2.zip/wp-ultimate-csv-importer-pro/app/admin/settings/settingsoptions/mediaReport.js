import React, {Component} from 'react';
import axios from 'axios';
import {AppContext} from '../../../context.js';

class MediaReport extends Component {
    static contextType = AppContext;
    constructor(props) {
        super(props);
        this.state = {
            mediaData:[]
        }

    }

    componentDidMount() {
        this.displayMediaReport(); 
        //set Cookies for Setting Page
        this.context.setSelectedTabCookies("settings")       
    }

    async displayMediaReport() {
        var formData = new FormData();
        formData.set('action','media_report');

        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log('Media Report',response.data);

        this.setState({ loading : false, });

        var mediaData = [];

        var len = response.data.count.length;

        //console.log(len);

        for (var i=0; i<len; i++){

            mediaData.push({
                file_name: response.data.file_name[i],
                count:response.data.count[i],
                image_type: response.data.image_type[i],
                module: response.data.module[i],
                status: response.data.status[i],
            });
        }

        //console.log(mediaData);

        if(response.status == 200) {
            this.setState({mediaData:mediaData});
       }
       console.log(this.state.mediaData); 
    }

    render() {

        var status = '';

        if(this.state.mediaData.status ==='Completed' ){
            status = 'success'
        }else if(this.state.mediaData.status ==='pending' ){
            status = 'pending'
        }


        return (
            <div className="col-sm-8 col-md-9">
                <div className="setting-tab-pane media setting-tabpane5 active">
                    <div className="row justify-content-center">
                        <div className="col-md-12 mt20">
                            <h1 className="main-heading">{this.context.translateLanguage.MediaReport}</h1>
                            <div className="table-responsive">
                                <table className="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>{this.context.translateLanguage.FileName}</th>
                                            <th>{this.context.translateLanguage.Count}</th>
                                            <th>{this.context.translateLanguage.ImageType}</th>
                                            <th>{this.context.translateLanguage.Module}</th>
                                            <th>{this.context.translateLanguage.Status}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                    {(this.state.loading) ?
                                    <tr><td colspan="6"><span className="text-danger">{this.context.translateLanguage.Loading}</span></td></tr>
                                    : 
                                    ( this.state.mediaData.length !== 0) ? this.state.mediaData.map((data, index) => 
                                    
                                                <tr>
                                                    <td >{ data.file_name } </td>
                                                    <td >{ data.count } </td>
                                                    <td >{data.image_type}</td>
                                                    <td>{ data.module }</td>
                                                    <td><div className={`${(this.state.mediaData.status ==='Completed') ? 'success' : 'pending'}`}>{ data.status }</div></td>
                                                                                                        
                                                </tr> )  :                                                
                                                <tr>
                                                    <td colspan="6">
                                                        <span className="text-danger">{this.context.translateLanguage.NoLogRecordFound}</span>
                                                    </td>
                                                </tr>  }
                                        
                                        
                                        {/* <tr>
                                            <td>1</td>
                                            <td>2</td>
                                            <td>
                                                <div className="success">Success</div>
                                            </td>
                                            <td>
                                                4
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td>2</td>
                                            <td>
                                                <div className="pending">Pending</div>

                                            </td>
                                            <td>
                                                4
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td>2</td>
                                            <td>
                                                <div className="error">Error</div>

                                            </td>
                                            <td>
                                                4
                                            </td>
                                        </tr> */}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        )
    }
}

export default MediaReport;
