import React, { Component } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import {AppContext} from '../../../context.js';

class SecurityAndPerformance extends Component {
    static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
            loading: false,
            securityData: [],
            author_editor_access:false
        }
    }

    componentDidMount() {
        this.displaySecurityPerformance();
        this.displayGeneralSettings();
        //set Cookies for Setting Page
        this.context.setSelectedTabCookies("settings")
    }

    async displayGeneralSettings() {
        var formData = new FormData();
        formData.set('action','get_options');

        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);

        this.setState({ loading : false, });       
        this.setState(response.data.options);
    }
    
    async updateGeneralSetting(event){
        this.setState({author_editor_access:event.target.checked});
        
        var formData = new FormData();
        formData.set('action', 'settings_options');
        formData.set('option', 'author_editor_access');
        formData.set('value', event.target.checked);
        
        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log("Response", response);

        this.setState({ loading : false, });

        if(response.status == 200 && (response.data.success)) {
            toast.success('Settings Successfully Updated');
        }
    }

    async displaySecurityPerformance() {
        var formData = new FormData();
        formData.set('action','security_performance');

        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);
        this.setState({ loading : false, });

        if(response.status == 200) {
           this.setState({ securityData:response.data });
           console.log(this.state.securityData);
        } 
    }

    render() {
        const dataWidth = {
            width:"25%"
          };
        return(
            <div className="col-sm-8 col-md-9">
           <div className="setting-tab-pane setting-tabpane3 active">
                                <div className="row justify-content-center">
                                    <div className="col-md-10 mt20">
                                        <h1 className="main-heading pb5">{this.context.translateLanguage.SecurityandPerformance} </h1>

                                        {/* <!-- Allow authors/editors to import Start --> */}
                                        <div className="form-group row mt30">
                                            <div className="col-xs-12 col-sm-7 col-md-7 nopadding">
                                                <h4>{this.context.translateLanguage.Allowauthorseditorstoimport}</h4>
                                                <small className="form-text text-muted">{this.context.translateLanguage.Thisenablesauthorseditorstoimport}</small>
                                            </div>
                                            <div className="col-xs-12 col-sm-4 col-md-3 ">
                                                <div className="form-group col-md-6 fieldset">
                                                    <input type="checkbox" className="ios-switch" checked={this.state.author_editor_access} onClick={(event)=>{this.updateGeneralSetting(event);}} id="two" />
                                                    <label className="switch-ios inline" for="two"><i></i></label>
                                                </div>
                                            </div>
                                        </div>
                                        {/* <!-- Allow authors/editors to import End --> */}

                                        {/* <!-- Max/Min required start--> */}
                                        <table className="table table-striped">
                                            <tbody>
                                                <tr>
                                                    <th colspan="3">
                                                        <h5 className="text-capitalize">{this.context.translateLanguage.MinimumrequiredphpinivaluesIniconfiguredvalues}</h5>
                                                    </th>
                                                </tr>
                                                <tr>
                                                    <th>
                                                        <label>{this.context.translateLanguage.Variables}</label>
                                                    </th>
                                                    <th className="ini-configured-values">
                                                        <label>{this.context.translateLanguage.SystemValues}</label>
                                                    </th>
                                                    <th className="min-requirement-values">
                                                        <label>{this.context.translateLanguage.MinimumRequirements}</label>
                                                    </th>
                                                </tr>
                                                <tr>
                                                    <td>post_max_size </td>
                                                    <td className="ini-configured-values">{ (this.state.securityData.post_max_size !== "") ? this.state.securityData.post_max_size : "-" }</td>
                                                    <td className="min-requirement-values">10M</td>
                                                </tr>
                                                <tr>
                                                    <td>auto_append_file</td>
                                                    <td className="ini-configured-values"> { (this.state.securityData.auto_append_file !== "") ? this.state.securityData.auto_append_file : "-" } </td>
                                                    <td className="min-requirement-values">-</td>
                                                </tr>
                                                <tr>
                                                    <td>auto_prepend_file </td>
                                                    <td className="ini-configured-values">{ (this.state.securityData.auto_prepend_file !== "") ? this.state.securityData.auto_prepend_file : "-" }</td>
                                                    <td className="min-requirement-values">-</td>
                                                </tr>
                                                <tr>
                                                    <td>upload_max_filesize </td>
                                                    <td className="ini-configured-values">{ (this.state.securityData.upload_max_filesize !== "") ? this.state.securityData.upload_max_filesize : "-" }</td>
                                                    <td className="min-requirement-values">2M</td>
                                                </tr>
                                                <tr>
                                                    <td>file_uploads </td>
                                                    <td className="ini-configured-values">{ (this.state.securityData.file_uploads !== "") ? this.state.securityData.file_uploads : "-" }</td>
                                                    <td className="min-requirement-values">1</td>
                                                </tr>
                                                <tr>
                                                    <td>allow_url_fopen </td>
                                                    <td className="ini-configured-values">{ (this.state.securityData.allow_url_fopen !== "") ? this.state.securityData.allow_url_fopen : "-" }</td>
                                                    <td className="min-requirement-values">1</td>
                                                </tr>
                                                <tr>
                                                    <td>max_execution_time </td>
                                                    <td className="ini-configured-values">{ (this.state.securityData.max_execution_time !== "") ? this.state.securityData.max_execution_time : "-" }</td>
                                                    <td className="min-requirement-values">3000</td>
                                                </tr>
                                                <tr>
                                                    <td>max_input_time </td>
                                                    <td className="ini-configured-values">{ (this.state.securityData.max_input_time !== "") ? this.state.securityData.max_input_time : "-" }</td>
                                                    <td className="min-requirement-values">3000</td>
                                                </tr>
                                                <tr>
                                                    <td>max_input_vars </td>
                                                    <td className="ini-configured-values">{ (this.state.securityData.max_input_vars !== "") ? this.state.securityData.max_input_vars : "-" }</td>
                                                    <td className="min-requirement-values">3000</td>
                                                </tr>
                                                <tr>
                                                    <td>memory_limit </td>
                                                    <td className="ini-configured-values">{ (this.state.securityData.wp_memory_limit !== "") ? this.state.securityData.wp_memory_limit : "-" }</td>
                                                    <td className="min-requirement-values">99M</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        {/* <!-- Max/Min requiredend--> */}
                                        {/* <!-- Extension modules start--> */}
                                        <h4 class="mt30">{this.context.translateLanguage.RequiredtoenabledisableLoadersExtentionsandmodules}</h4>
                                        <table className="table table-striped">
                                            <tbody>
                                                <tr>
                                                    <td>PDO</td>
                                                    <td>{ (this.state.securityData.PDO !== "") ? this.state.securityData.PDO : "-" }</td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td>Curl </td>
                                                    <td>{ (this.state.securityData.curl !== "") ? this.state.securityData.curl : "-" }</td>
                                                    <td></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        {/* <!-- Extension modules end--> */}
                                        {/* <!-- Debug info start--> */}
                                        <h4 className="mt30">{this.context.translateLanguage.DebugInformation}</h4>
                                        <table className="table table-striped">
                                            <tbody>
                                                <tr>
                                                    <td className="debug-info-name" style={dataWidth}>WordPress Version</td>
                                                    <td>{ (this.state.securityData.wp_version !== "") ? this.state.securityData.wp_version : "-" }</td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td className="debug-info-name">PHP Version</td>
                                                    <td>{ (this.state.securityData.php_version !== "") ? this.state.securityData.php_version : "-" }</td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td className="debug-info-name">MySQL Version</td>
                                                    <td>{ (this.state.securityData.db_version !== "") ? this.state.securityData.db_version : "-" }</td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td className="debug-info-name">Server SoftWare</td> 
                                                    <td>{ (this.state.securityData.server_software !== "") ? this.state.securityData.server_software : "-" }</td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td className="debug-info-name">Your User Agent</td>
                                                    <td>{ (this.state.securityData.http_agent !== "") ? this.state.securityData.http_agent : "-" }</td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td className="debug-info-name">WPDB Prefix</td>
                                                    <td>{ (this.state.securityData.db_prefix !== "") ? this.state.securityData.db_prefix : "-" }</td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td className="debug-info-name">WP Multisite Mode</td>
                                                    <td>{ (this.state.securityData.wp_multi_site !== "") ? this.state.securityData.wp_multi_site : "-" } </td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td className="debug-info-name">WP Memory Limit</td>
                                                    <td>{ (this.state.securityData.wp_memory_limit !== "") ? this.state.securityData.wp_memory_limit : "-" }</td>
                                                    <td></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        {/* <!-- Debug info end--> */}


                                    </div>
                                </div>
                            </div>
       
                        </div>
        )
    }
}

export default SecurityAndPerformance;
