import React, { Component } from 'react';

export default class Uploaded extends Component {
	constructor(props) {
            super(props);
            this.state = {
                avariable : 0,
                bvariable : 0,
                output : 0
            };
    }
    
    onButtonClick(adding){
        this.setState({output: this.state.avariable + this.state.bvariable});
    }
    addFunction(event){
        this.setState({avariable: event.target.value});
    }

    addedFunction(events){
        this.setState({bvariable: event.target.value});
    }

    render() {
		return (
            <div>
                <input type = "text" onChange={this.addFunction.bind(this)}></input>
                <input type = "text" onChange={this.addedFunction.bind(this)}></input>
                <div>{this.state.output}</div>
                <button onClick={this.onButtonClick.bind(this)}>Add</ button>
            </div>
    
        );
	}
}