import React, { Component } from 'react';
import ExportDataFilters from './exportDataFilters.js';
import ExportDownloadOption from './exportDownloadOption.js';
import axios from 'axios';
import {AppContext} from '../../../context.js';
import { toast } from 'react-toastify';

class ExportOptions extends Component {
    static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
            displayCustomPosts: 'none',
            displayTaxonomies: 'none',
            customPostType: [],
            taxonomies: [],
            loading: false,
            moduleRecordCount:"0 Data"
            
        }

        this.selectCustom = false;
        this.selectTaxonomy = false;
    }
    componentDidMount() {
        this.context.setSelectedTabCookies("export");
        this.getPostTypes();
        this.getTaxonomies();
        //this.getModuleCount();
        // (document.getElementById("exportbtn").length >0)
        // document.getElementById("exportbtn").disabled = true;
  
    }

    async getModuleCount(moduleName){
            
            var formData = new FormData();
            formData.set('action','total_records');
            formData.set('module',moduleName);
            
            if (moduleName === "CustomPosts"){
                var e = document.getElementById("custom-post");
                var strUser = e.options[e.selectedIndex].value;

                //this.setState({ displayCustomPosts: 'block' });

                 if (this.selectCustom){   

                    if (strUser != ""){
                        //alert(strUser) 
                        formData.set('optionalType',strUser);
                    }else{
                        toast.error("Select a Custom Post Type")
                        return;
                    }
                }
                this.selectCustom = true;
            }else{
                this.setState({ displayCustomPosts: 'none' });
            }

            if (moduleName === "Taxonomies"){
                var e = document.getElementById("taxonomies");
                var strUser = e.options[e.selectedIndex].value;

                //this.setState({ displayCustomPosts: 'block' });

                 if (this.selectTaxonomy){   

                    if (strUser != ""){
                        //alert(strUser) 
                        formData.set('optionalType',strUser);
                    }else{
                        toast.error("Select a Custom Post Type")
                        return;
                    }
                }
                this.selectTaxonomy = true;
            }else{
                this.setState({ displayTaxonomies: 'none' });
            }
        
        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

       

        if(response.status === 200){
            console.log('count',response);

            this.setState({ loading : false, });



            if (moduleName != ""){            
                this.setState({moduleRecordCount:response.data + " " +  moduleName})
             }else{
                this.setState({moduleRecordCount:response.data + " Data"})
             }

            if (response.data > 0){
                document.getElementById("exportbtn").disabled = false;
            }else{
                document.getElementById("exportbtn").disabled = true;
            }

            
            
        }


    }
        
    async getPostTypes() {
        var formData = new FormData();
        formData.set('action','get_post_types');
        
        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);
        if(response.status == 200) {
            this.setState({ loading : false, });
            this.setState({customPostType: response.data.custom_post_type});               
        }
    }

    async getTaxonomies() {
        var formData = new FormData();
        formData.set('action','get_taxonomies');

        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);
        if(response.status == 200) {
            this.setState({ loading : false, });
            this.setState({taxonomies: response.data.taxonomies}); 
        }        
    }

    getExportOption(){
        (this.context.exportModule != "") ? this.context.setExportDataFilterSection(true) : toast.error('Select any module to export')
    }
    
	showExportOptions (){
        const loaderGap = {
            marginTop : '-5px',
            marginRight : "-25px"
        }
		return(
            <div className="row pr30 pl30" >
		    <h1 class="main-heading pr15 pl15 col-md-12 mt20">{this.context.translateLanguage.Selectyourmoduletoexportthedata}  <div className="float-right">{ (this.state.loading) ? <div className="btn ajax-loader loading" style={loaderGap}></div> : ""}  <span className="exportData">{this.state.moduleRecordCount} Found</span></div></h1>
            <div className='clearfix'></div>
            
                        <div className="export-section col-md-6" id="radiogroups" >
                            <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="posts" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('Post'); this.context.setOptionalType(event.target.value);}} id="Posts" />
                                <label for="Posts">Post</label>
                            </div>
                            <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="pages" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('Page'); this.context.setOptionalType(event.target.value);}} id="Pages" />
                                <label for="Pages">Page</label>
                            </div>
                            <div className="form-group row">
                                <div className="col-md-4">
                                    <input type="radio" name="export" className="ios-switch" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('CustomPosts'); var checkBox = document.getElementById("CustomPosts"); this.setState({displayCustomPosts: "block"}) }} id="CustomPosts" />
                                    <label for="CustomPosts">Custom Post</label>
                                </div>
                                <div className="col-md-8" style={{display: "" + this.state.displayCustomPosts}}>
                                
                                    <select className="select" onChange={()=> {this.getModuleCount('CustomPosts')}} onClick={(event)=>{this.context.setOptionalType(event.target.value); }} name="" id="custom-post">
                                        <option value="">-select-</option>
                                        {this.state.customPostType.map((customposttype,index) => {
                                        return(
                                        <option value={customposttype}>{customposttype}</option>
                                        )})}
                                    </select>
                                </div>
                            </div>
                             <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="post_tag" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('Tags'); this.context.setOptionalType(event.target.value); }} id="Tags" />
                                <label for="Tags">Tags</label>
                            </div>
                            <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="category" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('Category'); this.context.setOptionalType(event.target.value);}} id="Categories" />
                                <label for="Categories">Category</label> 
                            </div>
                            <div className="form-group row" >
                                <div className="col-md-4">
                                    <input type="radio" name="export" value="taxonomy" className="ios-switch" onClick={(event)=>{var checkBox = document.getElementById('Taxonomies'); this.getModuleCount('Taxonomies'); this.context.setExportModule(event.target.id); console.log(checkBox); if(checkBox.checked){this.setState({displayTaxonomies: "block"});} else{this.setState({displayTaxonomies: "none"});}}} id="Taxonomies" />
                                    <label for="Taxonomies">Taxonomies</label>
                                </div>
                                <div className="col-md-8" style={{display: "" + this.state.displayTaxonomies}}>
                                    <select className="select" onChange={()=> {this.getModuleCount('Taxonomies')}} onClick={(event)=>{this.context.setOptionalType(event.target.value)}} name="" id="taxonomies">
                                        <option value="">-select-</option>
                                        {this.state.taxonomies.map((taxonomies, index) => {
                                        return(
                                        <option value={taxonomies}>{taxonomies}</option>
                                        )})}
                                    </select>
                                </div>
                            </div>
                             <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="users" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('Users'); this.context.setOptionalType(event.target.value); }} id="Users" />
                                <label for="Users">Users</label>
                            </div>
                            <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="comments" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('Comments'); this.context.setOptionalType(event.target.value); }} id="Comments" />
                                <label for="Comments">Comments</label>
                            </div>
                            <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="wpcr3_review" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('CustomerReviews'); this.context.setOptionalType(event.target.value); }} id="CustomerReviews" />
                                <label for="CustomerReviews">Customer Reviews</label>
                            </div>
                        </div>
                        <div className="export-section col-md-6">
                            <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="eshop" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('Eshop'); this.context.setOptionalType(event.target.value); }} id="Eshop" />
                                <label for="Eshop">Eshop</label>
                            </div>
                            <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="wpsc-product" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('WPeCommerce'); this.context.setOptionalType(event.target.value);}} id="WPeCommerce" />
                                <label for="WPeCommerce">Wp-eCommerce</label>
                            </div>
                            <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="wpsc-product" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('WPeCommerceCoupons'); this.context.setOptionalType(event.target.value);}} id="WPeCommerceCoupons" />
                                <label for="WPeCommerceCoupons">Wp-eCommerce Coupons</label>
                            </div>
                             <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="product" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('WooCommerce'); this.context.setOptionalType(event.target.value); }} id="WooCommerce" />
                                <label for="WooCommerce">Woo-Commerce</label>
                            </div>
                            <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="product" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('WooCommerceOrders'); this.context.setOptionalType(event.target.value); }} id="WooCommerceOrders" />
                                <label for="WooCommerceOrders">Woo-Commerce Orders</label> 
                            </div>
                             <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="product" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('WooCommerceCoupons'); this.context.setOptionalType(event.target.value); }} id="WooCommerceCoupons" />
                                <label for="WooCommerceCoupons">Woo-Commerce Coupons</label>
                            </div>
                            <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="product" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('WooCommerceRefunds'); this.context.setOptionalType(event.target.value); }} id="WooCommerceRefunds" />
                                <label for="WooCommerceRefunds">Woo-Commerce Refunds</label>
                            </div>
                            <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="product" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('WooCommerceVariations'); this.context.setOptionalType(event.target.value); }} id="WooCommerceVariations" />
                                <label for="WooCommerceVariations">Woo-Commerce Variations</label>
                            </div>
                            <div className="form-group">
                                <input type="radio" name="export" className="ios-switch" value="product" onClick={(event)=>{this.context.setExportModule(event.target.id); this.getModuleCount('Marketpress'); this.context.setOptionalType(event.target.value); }} id="Marketpress" />
                                <label for="Marketpress">Marketpress</label>
                            </div>
                        </div>
                        <div className="col-md-12">
                            <div className="float-right">
                                <input type="button" className="smack-btn smack-btn-primary mb20" id='exportbtn' onClick={(event)=>{this.getExportOption()}} value={this.context.translateLanguage.Continue} />
                            </div>
                        </div>
                    </div>

		)
	}

	render() {
		return(
            
            		<div id="mapping-accordion">
           			 <div className="card csv-importer-panel mt20">
                        {console.log(this.context.activateExportDataFilter)}
                    {(this.context.activateExportDataFilter) ? <ExportDataFilters /> : (this.context.activateExportDownloadOptionSection) ? <ExportDownloadOption /> : this.showExportOptions()}
                    
					
					{/* {(this.state.fileManagerTabActive === "active") ? <FileManager /> : 
					 (this.state.smartScheduleTabActive === "active") ? <SmartSchedule /> :
					 (this.state.scheduledExportTabActive === "active") ? <ScheduledExport /> : 
					 (this.state.templatesTabActive === "active") ? <Templates /> :
					 (this.state.logManagerTabActive === "active") ? <LogManager /> : <div> not selected </div> }  */}
				
				 	 
					</div>
				</div>
		   	
		);

	}

}

export default ExportOptions;
