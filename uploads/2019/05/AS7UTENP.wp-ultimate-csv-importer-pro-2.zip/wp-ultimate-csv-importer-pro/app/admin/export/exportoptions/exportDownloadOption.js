import React, { Component } from 'react';
import axios from 'axios';
import {AppContext} from '../../../context.js';

class ExportDownloadOption extends Component {
    static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
            progressBar: [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1],
            progress: "",
        }
    }

    componentDidMount() {
        this.context.setSelectedTabCookies("export");
        this.displayProgress();
    }

    displayProgress() {
        for(var i=0; i<this.state.progressBar.length; i++) {
            this.state.progressBar[i] = this.state.progressBar[i] * 1000
            this.setState({progress: this.state.progressBar[i]});
        }
    }

    render() {
        return(
               // <div className="card csv-importer-panel mt40 col-md-12">

                    <div className="card-body">

                        <div className="importing-details">
                            <div className="progress-status">In Progress</div>
                            <div className="import-progress">
                                <div className="progress-loading">70% to Complete</div>
                                <div className="progress-timing"><i className="csv-icon-schedule"></i> 00:00</div>
                            </div>
                        </div>

                       
                        <div className="progress mt10 mb40">
                            <div className="progress-bar" role="progressbar" style={{width: this.state.progress}} aria-valuenow="10" aria-valuemin="0"
                             aria-valuemax="100"></div>
                        </div>

                        <div className="d-flex justify-content-center">
                            <a href={this.context.receivedExportedFileUrl} className="smack-btn smack-btn-primary" onClick={(event)=>{window.location.href}}><i className="csv-icon-download-cloud mr10"></i>Download</a>
                        </div>

                    </div>

                // </div> 

        )
    }
}

export default ExportDownloadOption;

