import React, { Component } from 'react';
import DatePicker from "react-datepicker";
import {AppContext} from '../../../context.js'
var moment = require('moment');
import axios from 'axios';
import { toast } from 'react-toastify';

import "react-datepicker/dist/react-datepicker.css";

class ExportDataFilters extends Component {
    static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
            startDate: new Date(),
            endDate: new Date(),
            scheduleDate: new Date(),
            displaySplitTheRecord: "none",
            displayExportDataWithAutoDelimiters: "none",
            displayExportDataForSpecifiedPeriod: "none",
            displayExportDataWithSpecificStatus: "none",
            displayExportDataBySpecificAuthors: "none",
            displayExportDataBasedOnSpecificInclusions: "none",
            displayIsScheduleThisExport: "none",
            display5: "none",
            display6: "none",
            exportFileName: '',
            recordLimit: '',
            delimiters: '',
            otherdelimiterss: '',
            specificStatus: '',
            specificAuthors: 1,
            exportType: 'csv',
            isSplitTheRecord: false,
            isExportDataWithDelimiter: false,
            isExportDataForSpecificPeriod: false,
            isExportDataWithSpecificStatus: false,
            isExportDataBySpecificAuthors: false,
            isExportDataBasedOnSpecificInclusion: false,
            wordPressCoreFields: [],
            acfGroupFields: [],
            acfProFields: [],
            acfRepeaterFields: [],
            termsAndTaxonomies: [],
            typesFields: [],
            podsFields: [],
            customFieldsSuiteFields: [],
            allInOneSeoFields: [],
            yoastSeoFields: [],
            billingAndShippingInformation: [],
            wordPressCustomFields: [],
            productMetaFields: [],
            customFieldsWpMembersFields: [],
            customFieldsMembersFields: [],
            wpEcomCustomFields: [],
            exportMode: "normal",
            loading: false,
            exportedFilePath: "",
            scheduleFrequency: "OneTime",
            scheduleTime: "",
            hostName: "",
            hostPort: "",
            hostUserName: "",
            hostPassword: "",
            hostPath: "",
            displayNormalExport: "block",
            offset: 0,
            exportProgress: '0',
            totalExportRecord: 0,
            stopWatch: '00:00:00',
            activeDowloadTab: false,
            exportSuccess:true,
            showDownloadBtn:false,
        }
        this.stopSeconds = 0, this.stopMinutes = 0, this.stopHours = 0;
        this.checkedFields = [];
        this.setEnabledField = true;
        this.exclusionHeaders = [];
        this.handleChangeStart = this.handleChangeStart.bind(this);
        this.handleChangeEnd = this.handleChangeEnd.bind(this);
        this.handleChangeSchedule = this.handleChangeSchedule.bind(this);
        this.userName = [];
        this.userId = [];
    }
    handleChangeStart(date) {
        this.setState({
          startDate: date,
        });
    }
    handleChangeEnd(date) {
        this.setState({
            endDate: date
        });
    }
    handleChangeSchedule(date) {
        this.setState({
            scheduleDate: date
        })
    }
    componentDidMount() {
        this.context.setSelectedTabCookies("export");
        this.getFields();
        this.getAuthors();
        this.updateFieldsConfiguration();
        this.getUtcTimeZones();
        setInterval(function() {
            if (!this.state.exportSuccess) {
              this.stopWatch(); 
            }           
          }.bind(this),1000);
    }

    async sendExportScheduleConfiguration() {
        var delimiterObject = { is_check: this.state.isExportDataWithDelimiter , delimiter: this.state.delimiters, optional_delimiter: this.state.otherDelimiters };
        var specificPeriodObject = { is_check: this.state.isExportDataForSpecificPeriod, from: moment(this.state.startDate).format('YYYY-MM-DD'), to: moment(this.state.endDate).format('YYYY-MM-DD') };
        var specificStatusObject = { is_check: this.state.isExportDataWithSpecificStatus, status: this.state.specificStatus };
        var specificAuthors = { is_check: this.state.isExportDataBySpecificAuthors, author: this.state.specificAuthors };
        var conditions = {
            delimiter : delimiterObject,
            specific_period : specificPeriodObject,
            specific_status : specificStatusObject,
            specific_authors : specificAuthors
        }
        console.log('conditions');
        console.log(JSON.stringify(conditions));
        console.log('delimiter');
        console.log(delimiterObject);
        var headers = {};
        for(var i=0; i<this.checkedFields.length; i++) {
            var header = {}
            header[this.checkedFields[i]] = this.setEnabledField
            this.exclusionHeaders.push(header);
            headers[this.checkedFields[i]] = this.setEnabledField;
        }
        console.log(headers);
        var eventExclusion = { is_check: this.state.isExportDataBasedOnSpecificInclusion, exclusion_headers: headers}
        var formData = new FormData();
        formData.set('action','parseDataToScheduleExport');
        formData.set('module',this.context.exportModule);
        formData.set('optionalType',this.context.optionalType);
        formData.set('exp_type', this.state.exportType);
        formData.set('conditions', JSON.stringify(conditions));
        formData.set('eventExclusions', JSON.stringify(eventExclusion));
        formData.set('fileName', this.state.exportFileName);
        formData.set('limit', this.state.recordLimit);
        formData.set('is_check_split',this.state.isSplitTheRecord);
        formData.set('export_mode', this.state.exportMode);
        formData.set('date', moment(this.state.scheduledDate).format('YYYY-MM-DD'));
        formData.set('host_name', this.state.hostName);
        formData.set('host_port', this.state.hostPort);
        formData.set('host_username', this.state.hostUserName);
        formData.set('host_password', this.state.hostPassword);
        formData.set('host_path', this.state.hostPath);
        formData.set('schedule_frequency', this.state.scheduleFrequency);
        formData.set('schedule_time', this.state.scheduleTime);
        formData.set('UTC', this.context.selectedCountryTime);

        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);
        if(response.status == 200) {
            if(response.data.success) {
                console.log(response.data)
                this.context.changeActivateExportDownloadOption(true);
                this.context.setExportDataFilterSection(false);
                this.context.exportedFileUrl(response.data.exported_file);
            }
        }

    }

    async sendExportConfiguration() {
        if(document.getElementById('export-file-name').value == ''){
            toast.error("Please Type Export File Name");
            document.getElementById('export-file-name').focus();
            return;
        }
        this.setState({activeDowloadTab:true})

        var delimiterObject = { is_check: this.state.isExportDataWithDelimiter , delimiter: this.state.delimiters, optional_delimiter: this.state.otherDelimiters };
        var specificPeriodObject = { is_check: this.state.isExportDataForSpecificPeriod, from: moment(this.state.startDate).format('MM/DD/YYYY'), to: moment(this.state.endDate).format('MM/DD/YYYY') };
        var specificStatusObject = { is_check: this.state.isExportDataWithSpecificStatus, status: this.state.specificStatus };
        var specificAuthors = { is_check: this.state.isExportDataBySpecificAuthors, author: this.state.specificAuthors };
        var conditions = {
            delimiter : delimiterObject,
            specific_period : specificPeriodObject,
            specific_status : specificStatusObject,
            specific_authors : specificAuthors
        }
        console.log('conditions');
        console.log(JSON.stringify(conditions));
        console.log('delimiter');
        console.log(delimiterObject);
        var headers = {};
        for(var i=0; i<this.checkedFields.length; i++) {
            var header = {}
            header[this.checkedFields[i]] = this.setEnabledField
            this.exclusionHeaders.push(header);
            headers[this.checkedFields[i]] = this.setEnabledField;
            
        }

        console.log(headers);
        //for(var i=0; i<this.checkedFields.length; i++) {
            //console.log(this.exclusionHeaders[i]);
        //}
        //console.log(this.exclusionHeaders);
        var eventExclusion = { is_check: this.state.isExportDataBasedOnSpecificInclusion, exclusion_headers: headers}
        var formData = new FormData();
        formData.set('action','parse_data');
        formData.set('module',this.context.exportModule);
        formData.set('optionalType',this.context.optionalType);
        formData.set('exp_type', this.state.exportType);
        formData.set('conditions', JSON.stringify(conditions));
        formData.set('eventExclusions', JSON.stringify(eventExclusion));
        formData.set('fileName', this.state.exportFileName);
        formData.set('limit', this.state.recordLimit);
        formData.set('is_check_split',this.state.isSplitTheRecord);
        formData.set('export_mode', this.state.exportMode);
        formData.set('offset', this.state.offset);

        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log(response);

        var progressData = response.data;
        console.log('Export Result',response.data);
        if(response.status == 200) {
            
                var new_offset =  response.data.new_offset
                var totalExportRecord=response.data.total_row_count

                if (totalExportRecord<new_offset){
                    this.setState({offset:totalExportRecord})
                }else{
                    this.setState({offset:response.data.new_offset})
                }
                
                this.setState({
                    exportSuccess:response.data.success,
                    totalExportRecord:progressData.total_row_count
                })
                

                let progWidth = (progressData.new_offset/progressData.total_row_count)*100;
  
                //console.log('progress Value',progWidth)
            
                progWidth=Math.round(progWidth);
            
                if (progWidth > 0.9)
                this.setState({exportProgress:progWidth})

                if (progWidth > 100)
                this.setState({exportProgress:'100'})

                if(response.data.success) {
                    //this.context.changeActivateExportDownloadOption(true);
                    //this.context.setExportDataFilterSection(false);
                    this.context.exportedFileUrl(response.data.exported_file);
                    this.setState({                    
                        showDownloadBtn:true               
                    })
                }
                else {
                    this.sendExportConfiguration();
                }

        }
    }

    stopWatch() {
    
        this.stopSeconds++;
        if (this.stopSeconds >= 60) {
            this.stopSeconds = 0;
            this.stopMinutes++;
            if (this.stopMinutes >= 60) {
                this.stopMinutes = 0;
                this.stopHours++;
            }
        }
    
        if(this.stopHours.toString().length < 2){
          this.stopHours= "0"+this.stopHours;
        }
        if(this.stopMinutes.toString().length < 2){
          this.stopMinutes= "0"+this.stopMinutes;
        }
        if(this.stopSeconds.toString().length < 2){
          this.stopSeconds= "0"+this.stopSeconds;
        }
    
        var tempStopWatch = this.stopHours + ":" + this.stopMinutes + ":" + this.stopSeconds;
       this.setState({stopWatch:tempStopWatch})
       
    }
    
  

    getCheckedFields(fieldsname) {
        this.checkedFields.push(fieldsname);
        console.log(this.checkedFields);
    }

    async getFields() {
        console.log(this.context.wordPressCoreFields);
        console.log(this.context.exportModule);
        var formData = new FormData();
        formData.set('action','get_export_fields');
        formData.set('Types', this.context.exportModule);
        // formData.set('Mode',this.context.mode);
        //formData.set('exp_type',this.state.exportType);


        this.setState({
            loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });
            
        if(response.status == 200) {
            console.log(response);
            if(response.data.success) {
                for(var i=0; i<response.data.fields.length; i++) {
                    if (response.data.fields[i]['acf_group_fields'] != undefined && response.data.fields[i]['acf_group_fields'] != null) {
                        this.setState({acfGroupFields: response.data.fields[i].acf_group_fields}); 
                    }
                    if (response.data.fields[i]['acf_pro_fields'] != undefined && response.data.fields[i]['acf_pro_fields'] != null) {
                        this.setState({acfProFields: response.data.fields[i].acf_pro_fields});
                    }
                    if (response.data.fields[i]['acf_repeater_fields'] != undefined && response.data.fields[i]['acf_repeater_fields'] != null) {
                        this.setState({acfRepeaterFields: response.data.fields[i].acf_repeater_fields})
                    }
                    if (response.data.fields[i]['core_fields'] != undefined && response.data.fields[i]['core_fields'] != null) {
                        this.setState({wordPressCoreFields: response.data.fields[i].core_fields});
                    }
                    if (response.data.fields[i]['terms_and_taxonomies'] != undefined && response.data.fields[i]['terms_and_taxonomies'] != null) {
                        this.setState({termsAndTaxonomies: response.data.fields[i].terms_and_taxonomies});
                    }
                    if (response.data.fields[i]['types_fields'] != undefined && response.data.fields[i]['types_fields'] != null) {
                        this.setState({typesFields: response.data.fields[i].types_fields});
                    }
                    if (response.data.fields[i]['pods_fields'] != undefined && response.data.fields[i]['pods_fields'] != null) {
                        this.setState({podsFields: response.data.fields[i].pods_fields});
                    }
                    if (response.data.fields[i]['custom_fields_suite_fields'] != undefined && response.data.fields[i]['custom_fields_suite_fields'] != null) {
                        this.setState({customFieldsSuiteFields: response.data.fields[i].custom_fields_suite_fields});
                    }
                    if (response.data.fields[i]['all_in_one_seo_fields'] != undefined && response.data.fields[i]['all_in_one_seo_fields'] != null) {
                        this.setState({allInOneSeoFields: response.data.fields[i].all_in_one_seo_fields});
                    }
                    if (response.data.fields[i]['yoast_seo_fields'] != undefined && response.data.fields[i]['yoast_seo_fields'] != null) {
                        this.setState({yoastSeoFields: response.data.fields[i].yoast_seo_fields});
                    }
                    if (response.data.fields[i]['billing_and_shipping_information'] != undefined && response.data.fields[i]['billing_and_shipping_information'] != null) {
                        this.setState({billingAndShippingInformation: response.data.fields[i].billing_and_shipping_information});
                    }
                    if (response.data.fields[i]['wordpress_custom_fields'] != undefined && response.data.fields[i]['wordpress_custom_fields'] != null) {
                        this.setState({wordPressCustomFields: response.data.fields[i].wordpress_custom_fields});
                    }
                    if (response.data.fields[i]['product_meta_fields'] != undefined && response.data.fields[i]['product_meta_fields'] != null) {
                        this.setState({productMetaFields: response.data.fields[i].product_meta_fields});
                    }
                    if (response.data.fields[i]['custom_fields_wp_members'] != undefined && response.data.fields[i]['custom_fields_wp_members'] != null) {
                        this.setState({customFieldsWpMembersFields: response.data.fields[i].custom_fields_wp_members});
                    }
                    if (response.data.fields[i]['custom_fields_members'] != undefined && response.data.fields[i]['custom_fields_members'] != null) {
                        this.setState({customFieldsMembersFields: response.data.fields[i].custom_fields_members});
                    }
                    if (response.data.fields[i]['wp_ecom_custom_fields'] != undefined && response.data.fields[i]['wp_ecom_custom_fields'] != null) {
                        this.setState({wpEcomCustomFields: response.data.fields[i].wp_ecom_custom_fields});
                    }
                }               
            }
            
        }

    }

    async getAuthors() {
        var formData = new FormData();
        formData.set('action','get_authors');

        this.setState({
            loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        if(response.status == 200) {
            console.log('authors', response);
            for(var i=0; i<response.data.user_name.length; i++) {
                this.userName.push(response.data.user_name[i]); 
                this.userId.push(response.data.user_id[i]);
            }
            this.forceUpdate();
        }
       
    }

    async updateFieldsConfiguration() {
        var formData = new FormData();
        formData.set('action','updatefields');
        formData.set('Types', this.context.selectedType);
        formData.set('Mode', this.context.mode);
        
        this.setState({
            loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        if (response.status == 200)	{
            console.log(response);
            // for(var i=0; i<response.data.update_fields.length; i++) {
            //     this.updateFields.push(response.data.update_fields[i]);
            // }    
            this.context.setUpdateFields(response.data.update_fields);
        }
    }

    async getUtcTimeZones() {
        var formData = new FormData();
        formData.set('action','timezone');

        this.setState({
            loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        if (response.status == 200)	{
            console.log(response);
            this.context.setCountryList(response.data.offset);
            this.context.setTimeZones(response.data.timezone);
        }
    }

render() {

    let progWidth = {
        width:this.state.exportProgress+ '%'
    }
    let displayBtn = {
        display: (this.state.showDownloadBtn) ? 'block' : 'none'
    } 
   
        // <div>
        // {(this.state.showExportDownloadOption) ?
        //     <ExportDownloadOption />
             
        //  : "" }
        //  </div>
          return (
              <React.Fragment>
                <div className={`row export pt25 pb40 ${(this.state.activeDowloadTab) ? 'd-none' : 'd-block'}`}>
                    {/* <!-- Export section Starts--> */}
                        <h1 className="main-heading pr15 pl15 mb20 col-md-12">{this.context.translateLanguage.Toexportdatabasedonthefilters}</h1>

                        <div className="col-md-12">

                            <div className="form-group col-md-8 row">
                                <label>{this.context.translateLanguage.ExportFileName}</label>
                                <input type="text" class="form-control" id="export-file-name" placeholder="" onChange={(event)=>{this.setState({exportFileName: event.target.value})}}/>
                            </div>
                            <div className="form-group">
                                <h3 className="main-heading">{this.context.translateLanguage.AdvancedSettings}</h3>
                                <div className="p15">
                                    <div className="row col-md-4 p0">
                                        <label className="advanced mb10">{this.context.translateLanguage.ExportType} </label>
                                        <select className="select" name="" id="" selected="csv" onChange={(event)=>{this.setState({exportType: event.target.value})}}>
                                            <option value="csv">CSV</option>
                                            <option value="xls">XLS</option>
                                            <option value="xml">XML</option>
                                            <option value="json">JSON</option>
                                        </select>
                                    </div>
                                    <div className="row col-md-4 mt20 p0">
                                        <label className="advanced">
                                        <input type="checkbox" id="splittherecord" class="split-record" onClick={(event)=>{if(event.target.checked){this.setState({isSplitTheRecord: true, displaySplitTheRecord: "block"})} else {this.setState({isSplitTheRecord: false, displaySplitTheRecord: "none"})}}}/>
                                        {this.context.translateLanguage.SplittheRecord} </label>
                                        <input type="text" class="form-control mt10" onChange={(event)=>{this.setState({recordLimit: event.target.value})}} id="" placeholder="" style={{display: "" + this.state.displaySplitTheRecord}}/>
                                    </div>
                                </div>
                            </div>

                            {/* <div class="form-group col-md-6">
                                <div class="btn-group btn-select" role="group">
                                    <input className="btn-select-radio" id="csv" checked={this.state.exportType} type="radio" name="export_mode" onChange={(event)=>{this.setState({exportType: event.target.id}); console.log(this.state.exportType)} } />
                                    <label for="CSV">CSV</label>
                                    <input className="btn-select-radio" id="xls" checked={this.state.exportType} type="radio" name="export_mode" onChange={(event)=>{this.setState({exportType: event.target.id}); console.log(this.state.exportType)} } />
                                    <label for="XLS">XLS</label>
                                    <input className="btn-select-radio" id="xml" checked={this.state.exportType} type="radio" name="export_mode" onChange={(event)=>{this.setState({exportType: event.target.id}); console.log(this.state.exportType)} } />
                                    <label for="XML">XML</label>
                                    <input className="btn-select-radio" id="json" checked={this.state.exportType} type="radio" name="export_mode"  onChange={(event)=>{this.setState({exportType: event.target.id}); console.log(this.state.exportType)} } />
                                    <label for="JSON">JSON</label>
                                </div>
                            </div> */}

                            <hr/>

                            <h3 className="main-heading">{this.context.translateLanguage.AdvancedFilters}</h3>

                            <div className="advanced-filter">
                        		<label>
                                    <input type="checkbox" class="" id="myCheck" onClick={(event)=>{var checkBox = document.getElementById("myCheck"); if(checkBox.checked){this.setState({displayExportDataWithAutoDelimiters: "block", isExportDataWithDelimiter: true});} else{this.setState({displayExportDataWithAutoDelimiters: "none", isExportDataWithDelimiter: false})}}} />
                                    {this.context.translateLanguage.Exportdatawithautodelimiters}
                                </label>
                                <div className="col-md-8 mt15" style={{display: "" + this.state.displayExportDataWithAutoDelimiters}}>
                                    <div className="row">
                                    	<div className="form-group col-md-6">
                                    		<label>{this.context.translateLanguage.Delimiters}</label>
                                    		 <select className="select form-control" name="" id="" onClick={(event)=>{this.setState({delimiters: event.target.value});}}>
                                                <option value=",">,</option>
                                                <option value=":">:</option>
                                                <option value=";">;</option>
                                                <option value="{Tab}">Tab</option>
                                                <option value="{Space}">Space</option>
                                            </select>
                                    	</div>
                                    	<div className="form-group col-md-6">
                                    		<label>{this.context.translateLanguage.OtherDelimiters}</label>
                                    		<input type="text" name="" className="form-control" onChange={(event)=>{this.setState({otherDelimiters: event.target.value});}} />
                                    	</div>
                                    </div>
                                </div>
                            </div>

                            <div className="advanced-filter">
                                <label>
                                    <input type="checkbox" className="" id="myCheck1" onClick={(event)=>{var checkBox = document.getElementById("myCheck1"); if(checkBox.checked){this.setState({displayExportDataForSpecifiedPeriod: "block", isExportDataForSpecificPeriod: true});} else{this.setState({displayExportDataForSpecifiedPeriod: "none", isExportDataForSpecificPeriod: false})}}}/>
                                    {this.context.translateLanguage.Exportdataforthespecificperiod}
                                </label>
                                <div className="col-md-8 mt15" style={{display: "" + this.state.displayExportDataForSpecifiedPeriod}}>
                                    <div className="row">
                                        <div className="form-group col-md-6">
                                            <label for="">{this.context.translateLanguage.StartFrom}</label>
                                            {/* <input type="text" data-type="date" name="" className="form-control" /> */}
                                            <DatePicker className="form-control" selected={this.state.startDate} onChange={this.handleChangeStart} />
                                            <i className="csv-icon-calendar2 input-icon"></i>
                                        </div>
                                        <div className="form-group col-md-6">
                                            <label for="">{this.context.translateLanguage.EndTo} </label>
                                            {/* <input type="text" data-type="date" name="" className="form-control" /> */}
                                            <DatePicker className="form-control" selected={this.state.endDate} onChange={this.handleChangeEnd} />                                        
                                            <i className="csv-icon-calendar2 input-icon"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="advanced-filter">
                                <label>
                                    <input type="checkbox" className="" id="myCheck2" onClick={(event)=>{var checkBox = document.getElementById("myCheck2"); if(checkBox.checked){this.setState({displayExportDataWithSpecificStatus: "block", isExportDataWithSpecificStatus: true});} else{this.setState({displayExportDataWithSpecificStatus: "none", isExportDataWithSpecificStatus: false})}}}/>
                                    {this.context.translateLanguage.Exportdatawiththespecificstatus}
                                </label>
                                <div className="row col-md-8 mt15" style={{display: "" + this.state.displayExportDataWithSpecificStatus}}>
                                    <div className="form-group col-md-6">
                                        <label className="advanced mb10">{this.context.translateLanguage.Status}  </label>
                                        <select className="select form-control" name="" id="" onClick={(event)=>{this.setState({specificStatus: event.target.value})}}>
                                            <option value="All">{this.context.translateLanguage.All}</option>
                                            <option value="Publish">{this.context.translateLanguage.Publish}</option>
                                            <option value="Sticky">{this.context.translateLanguage.Sticky}</option>
                                            <option value="Private">{this.context.translateLanguage.Private}</option>
                                            <option value="Protected">{this.context.translateLanguage.Protected}</option>
                                            <option value="Draft">{this.context.translateLanguage.Draft}</option>
                                            <option value="Pending">{this.context.translateLanguage.Pending}</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div className="advanced-filter">
                                <label>
                                    <input type="checkbox" className="" id="myCheck3" onClick={(event)=>{var checkBox = document.getElementById("myCheck3"); if(checkBox.checked){this.setState({displayExportDataBySpecificAuthors: "block", isExportDataBySpecificAuthors: true});} else{this.setState({displayExportDataBySpecificAuthors: "none", isExportDataBySpecificAuthors: false})}}}/>
                                    {this.context.translateLanguage.Exportdatabyspecificauthors}
                                </label>
                                <div className="row col-md-8 mt15" style={{display: "" + this.state.displayExportDataBySpecificAuthors}}>
                                    <div className="form-group col-md-6">
                                        <label className="advanced mb10">{this.context.translateLanguage.Authors}  </label>
                                        <select className="select form-control" name="" id="" onClick={(event)=>{this.setState({specificAuthors: event.target.value})}}>
                                            {/* <option value="All">All</option> */}
                                            {this.userName.map((usernames, index) => {
                                                return(
                                                 <option value={this.userId[index]}>{usernames}</option>
                                            )})}
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div className="advanced-filter">
                                <label>
                                <input type="checkbox" className="" id="myCheck4" onClick={(event)=>{var checkBox = document.getElementById("myCheck4"); if(checkBox.checked){this.setState({displayExportDataBasedOnSpecificInclusions: "block", isExportDataBasedOnSpecificInclusion: true});} else{this.setState({displayExportDataBasedOnSpecificInclusions: "none", isExportDataBasedOnSpecificInclusion:false})}}}/>
                                {this.context.translateLanguage.ExportdatabasedonspecificInclusions} 
                                </label>
                                <div className="row mt20 col-md-12" style={{display: "" + this.state.displayExportDataBasedOnSpecificInclusions}}>

                                {(this.state.acfGroupFields.length !== 0) ?
                                <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="acf-group-fields" onClick={()=>{toggle_func('acf-group-fields');}}>{this.context.translateLanguage.ACFGroupFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="acf-group-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.acfGroupFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="acfgroupfields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" }

                                {(this.state.acfProFields.length !== 0) ?
                                <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="acf-pro-fields" onClick={()=>{toggle_func('acf-pro-fields');}}>{this.context.translateLanguage.ACFProFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="acf-pro-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.acfProFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="acfprofields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" }

                                {(this.state.acfRepeaterFields.length !== 0) ?
                                <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="acf-repeater-fields" onClick={()=>{toggle_func('acf-repeater-fields');}}>{this.context.translateLanguage.ACFRepeaterFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="acf-repeater-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.acfRepeaterFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="acfrepeaterfields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" }

                                    {(this.state.wordPressCoreFields.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="wordpress-core-fields" onClick={()=>{toggle_func('wordpress-core-fields');}}>{this.context.translateLanguage.WordPressCoreFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="wordpress-core-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.wordPressCoreFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="wordpresscorefields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" }

                                    {(this.state.typesFields.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="types-fields" onClick={()=>{toggle_func('types-fields');}}>{this.context.translateLanguage.TypesCustomFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="types-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.typesFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="typesfields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" }

                                    {(this.state.podsFields.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="pods-fields" onClick={()=>{toggle_func('pods-fields');}}>{this.context.translateLanguage.PodsFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="pods-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.podsFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="podsfields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" }  

                                    {(this.state.customFieldsSuiteFields.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="custom-fields-suite-fields" onClick={()=>{toggle_func('custom-fields-suite-fields');}}>{this.context.translateLanguage.CustomFieldSuite}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="custom-fields-suite-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.customFieldsSuiteFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="customfieldssuitefields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" }  

                                    {(this.state.allInOneSeoFields.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="all-in-one-seo-fields" onClick={()=>{toggle_func('all-in-one-seo-fields');}}>{this.context.translateLanguage.AllInOneSeoFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="all-in-one-seo-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.allInOneSeoFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="allinoneseofields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" } 

                                    {(this.state.yoastSeoFields.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="yoast-seo-fields" onClick={()=>{toggle_func('yoast-seo-fields');}}>{this.context.translateLanguage.YoastSeoFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="yoast-seo-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.yoastSeoFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="yoastseofields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" } 

                                    

                                    {(this.state.billingAndShippingInformation.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="billing-and-shipping-information_fields" onClick={()=>{toggle_func('billing-and-shipping-information-fields');}}>{this.context.translateLanguage.BillingAndShippingInformation}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="billing-and-shipping-information-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.billingAndShippingInformation.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="billingandshippinginformationfields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" } 

                                    
                                    {(this.state.wordPressCustomFields.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="wordpress-custom-fields" onClick={()=>{toggle_func('wordpress-custom-fields');}}>{this.context.translateLanguage.WordPressCustomFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="wordpress-custom-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.wordPressCustomFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="wordpresscustomfields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" } 


                                    {(this.state.productMetaFields.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="product-meta-fields" onClick={()=>{toggle_func('product-meta-fields');}}>{this.context.translateLanguage.ProductMetaFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="product-meta-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.productMetaFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="productmetafields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" } 

                                    {(this.state.customFieldsWpMembersFields.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="custom-fields-wp-members-fields" onClick={()=>{toggle_func('custom-fields-wp-members-fields');}}>{this.context.translateLanguage.CustomFieldsWPMemberFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="custom-fields-wp-members-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.customFieldsWpMembersFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="customfieldswpmembersfields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" } 

                                    {(this.state.customFieldsMembersFields.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="custom-fields-members-fields" onClick={()=>{toggle_func('custom-fields-members-fields');}}>{this.context.translateLanguage.CustomFieldsMemberFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="custom-fields-members-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.customFieldsMembersFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="customfieldsmembersfields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" } 

                                    {(this.state.wpEcomCustomFields.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                            <h1 className="card-header main-heading active" id="wp-ecom-custom-fields-members-fields" onClick={()=>{toggle_func('wp-ecom-custom-fields-members-fields');}}>{this.context.translateLanguage.WPECommerceCustomFields}<span class="csv-icon-angle-down float-right"></span></h1>
                                                <div className="card-body" id="wp-ecom-custom-fields-members-fields-body">
                                            
                                                    <div className="row">

                                                        { this.state.wpEcomCustomFields.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="wpecomcustomfieldsmembersfields" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                                </div>
                                    </div>
                                    : "" } 
                                    

                                    {(this.state.termsAndTaxonomies.length !== 0) ?
                                    <div className="card csv-importer-panel">
                                        <h1 className="card-header main-heading" id="terms-and-taxonomies" onClick={()=>{toggle_func('terms-and-taxonomies');}}>{this.context.translateLanguage.TermsandTaxonomies}<span className="csv-icon-angle-down float-right"></span></h1>
                                            <div className="card-body" id="terms-and-taxonomies-body">
                                            
                                                <div className="row">

                                                        { this.state.termsAndTaxonomies.map((corefields, index) => {
                                                            return(
                                                                <div className="col-md-3">
                                                                     <div className="form-group">
                                                                        <label>
                                                                           <input type="checkbox" name="" id="myCheck5" onClick={(event)=>{if(event.target.checked) { this.getCheckedFields(corefields.name); }}} />
                                                                                {corefields.label}
                                                                        </label>
                                                                        <div className="sub-title">{`[${corefields.name}]`}</div>
                                                                    </div>
                                                                </div>
                                                            )})}
                                                    </div>
                                            </div>
                                    </div>
                                    : "" }
                                

                                        </div>
                                    </div>

                            <div className="advanced-filter">
                                <label>
                                    <input type="checkbox" className="" id="myCheck6" onClick={(event)=>{var checkBox = document.getElementById("myCheck6"); if(checkBox.checked){this.setState({displayIsScheduleThisExport: "block", displayNormalExport: "none", exportMode: "schedule"});} else{this.setState({displayIsScheduleThisExport: "none", displayNormalExport: "block"});}}}/>
                                    {this.context.translateLanguage.DoyouwanttoSchedulethisExport}
                                </label>
                                <div className="mt20 col-md-12" style={{display: "" + this.state.displayIsScheduleThisExport}}>
                                    <div className="row justify-content-center">
                                    <div className="form-group col-md-6">
                                        <label className="advanced mb10">{this.context.translateLanguage.ScheduleDate}  </label>
                                        {/* <input type="text" data-type="date" name="" className="form-control" /> */}
                                        <DatePicker className="form-control" minDate={moment()} selected={this.state.scheduleDate} onChange={this.handleChangeSchedule} />
                                        <i className="csv-icon-calendar2 input-icon" ></i>
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label className="advanced mb10">{this.context.translateLanguage.ScheduleFrequency} </label>
                                        <select className="select" name="" id="" onChange={(event)=>{this.setState({scheduleFrequency: event.target.value})}} >
                                            <option value="OneTime">{this.context.translateLanguage.OneTime}</option>
                                            <option value="Daily">{this.context.translateLanguage.Daily}</option>
                                            <option value="Weekly">{this.context.translateLanguage.Weekly}</option>
                                            <option value="Monthly">{this.context.translateLanguage.Monthly}</option>
                                            <option value="Hourly">{this.context.translateLanguage.Hourly}</option>
                                            <option value="Every 30 mins">{this.context.translateLanguage.Every30mins}</option>
                                            <option value="Every 15 mins">{this.context.translateLanguage.Every15mins}</option>
                                            <option value="Every 10 mins">{this.context.translateLanguage.Every10mins}</option>
                                            <option value="Every 5 mins">{this.context.translateLanguage.Every5mins}</option>
                                        </select>
                                    </div>
                                    <div className="form-group col-md-6">
                                    <label for="">{this.context.translateLanguage.TimeZone}</label>
                                    <select className="select" name="" id="" onChange={(event)=>{this.context.selectedCountryTimeZone(event.target.value)}} >
                                    <option value="">{this.context.translateLanguage.SelectTimeZone}</option>
                                    {this.context.countryLists.map((timezones, index) => {
                                        return <option value={this.context.timeZones[index]}>{timezones}</option>
                                    })}
                                    </select>                                                                             
                                                {/* <SelectTimezone /> */}
                                </div>
                                    <div className="form-group col-md-6">
                                        <label className="advanced mb10">{this.context.translateLanguage.ScheduleTime} </label>
                                        <input type="text" name="" className="form-control" onChange={(event)=>{this.setState({scheduleTime: event.target.value})}}/>
                                        <small className="form-text text-muted">{this.context.translateLanguage.Format} : 21:30</small>
                                    </div>

                                  
                                    <div className="form-group col-md-6">
                                        <label for="hostname">{this.context.translateLanguage.Hostname}</label>
                                        <input type="text" class="form-control" onChange={(event)=>{this.setState({hostName: event.target.value})}} id="hostname" placeholder="" />
                                        <small className="form-text text-muted">smackcoders.com or 54.213.74.129</small>
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label for="host-port">{this.context.translateLanguage.HostPort}</label>
                                        <input type="text" className="form-control" onChange={(event) => {this.setState({hostPort: event.target.value})}} id="host-port" placeholder="" />
                                        <small className="form-text text-muted">{this.context.translateLanguage.DefaultPort} : 21</small>
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label for="host-username">{this.context.translateLanguage.HostUsername}</label>
                                        <input type="text" className="form-control" onChange={(event) => {this.setState({hostUserName: event.target.value})}} id="host-username" placeholder="" />
                                        <small className="form-text text-muted">{this.context.translateLanguage.FTPUsername}</small>
                                    </div>
                                    <div className="form-group col-md-6">
                                        <label for="host-password">{this.context.translateLanguage.HostPassword}</label>
                                        <input type="text" className="form-control" onChange={(event) => {this.setState({hostPassword: event.target.value})}} id="host-password" placeholder="" />
                                        <small className="form-text text-muted">{this.context.translateLanguage.FTPPassword}</small>
                                    </div>
                                    <div className="form-group col-md-12">
                                        <label for="host-path" >{this.context.translateLanguage.HostPath}</label>
                                        <input type="text" className="form-control" onChange={(event) => {this.setState({hostPath: event.target.value})}} id="host-path" placeholder="" />
                                        <small className="form-text text-muted">/home/guest/sample.csv</small>
                                    </div>
                                    </div>
                                </div>
                            </div>
                                                                
                            <div className="form-group mt30">
                                <div className="float-left">
                                    <button type="button" className="smack-btn btn-default" onClick={(event)=>{this.context.setExportDataFilterSection(false)}}>{this.context.translateLanguage.Back}</button>
                                </div>
                                <div className="float-right" style={{display: "" + this.state.displayNormalExport}}>
                                    <button type="button" className="smack-btn smack-btn-primary" onClick={(event)=>{this.sendExportConfiguration();}}>{this.context.translateLanguage.Export}</button>
                                </div>
                                <div className="float-right" style={{display: "" + this.state.displayIsScheduleThisExport}}>
                                    <button type="button" className="smack-btn smack-btn-primary" onClick={(event)=>{this.sendExportScheduleConfiguration();}}>{this.context.translateLanguage.ScheduleExport}</button>
                                </div>
                            </div>

                        </div>
                        

                    </div>
                    <div className={`card-body ${(this.state.activeDowloadTab) ? 'd-block' : 'd-none'}`}>

                    <div className="importing-details">
                        <div className="progress-status">{(this.state.exportSuccess && this.state.exportProgress > '99') ? 'In Progress' : ''}</div>
                        
                        <div className="import-progress">
                            <div className="progress-loading">{this.state.exportProgress+"%"} {this.context.translateLanguage.Completed}</div>
                            <div className="progress-timing"><i className="csv-icon-schedule"></i> {this.state.stopWatch}</div>
                        </div>
                    </div>
                    <div className="progress mt10 mb40">
                        <div className="progress-bar" role="progressbar" style={progWidth} aria-valuenow="10" aria-valuemin="0"
                         aria-valuemax="100"></div>
                    </div>
                    <p className="float-right">{this.context.translateLanguage.DataExported} : <span>{this.state.offset}</span> / {this.state.totalExportRecord} </p>

                    <div className="d-flex justify-content-center">
                        <a href={this.context.receivedExportedFileUrl} style={displayBtn} download className="smack-btn smack-btn-primary" onClick={(event)=>{window.location.href}}><i className="csv-icon-download-cloud mr10"></i>{this.context.translateLanguage.Download}</a>
                    </div>

                </div>
                </React.Fragment>
                    
        )

    }
}

export default ExportDataFilters;
