import React, { Component } from 'react';
import {AppContext} from '../../../context.js'
import axios from 'axios';
import {Line, Bar} from 'react-chartjs-2';

class DashboardGraphDisplay extends Component {
	static contextType = AppContext;
    constructor(props) {
		super(props);
		this.state = {
      loading: false,
      barChartLabel: [],
      createdValue:[],
      skippedValue:[],
      updatedValue:[],
      monthList:[],
      lineChartData:[],
      //lineChartPagesData:[]
			
    }

    this.chartOptions = {
      scales: {
           xAxes: [{
               stacked: true
           }],
           yAxes: [{
               stacked: true
           }],
           maintainAspectRatio: false,
           delay: 500
       }
    }

    this.lineOptions = {
      scales: {          
           maintainAspectRatio: false,
           delay: 500
       }
    }
    this.lineDataNew = []
  

    //this.random_color = ""
    
    
    }
    componentDidMount() {
      this.getBarData();
      this.listLastMonths();
      this.getLineData();

      //set Cookies for Dashboard Page
      this.context.setSelectedTabCookies("dashboard")  
    }

    getRandomColor() {
      var color_array = new Array("#e8e8e8", "#f5ddde", "#bee4e5", "#cfe0c7", "#f7e4bb", "#9c89b8 ", "#f0a6ca", "#efc3e6", "#f0e6ef", "#b8bedd");
      //this.random_color = color_array[_.random(color_array.length-1)];
      var random_color = color_array[Math.floor(Math.random() * color_array.length)];
      return random_color;
    }

    async getLineData() {
      var formData = new FormData();
      formData.set('action','LineChart');
      
      this.setState({
        loading : true, });

      const response = await axios({
          method: 'post',
          url: ajaxurl,
          data: formData,
          config: { headers: {'Content-Type': 'multipart/form-data' }}
      });


      if (response.status == 200)	{
        if(response.data.success) {

          console.log(response.data);

          // console.log(JSON.parse(response.data));

          
          // Store Reposnse Data to variable
          let lineVal = response.data;

          var firstArr = {
            data:[],
            label:response.data.label,
            color:[]
          };
          
         
          
          for(let i=0; i<lineVal.data.length; i++){
              //console.log(parseInt(lineVal.data[i]));
              
              var secondArr = [];
              for (let j=0; j<lineVal.data[i].length; j++){
                
                  //console.log(parseInt(lineVal.data[i][j]))

                  let test =  parseInt(lineVal.data[i][j]);
                  secondArr.push(test); 
                  //console.log('secondArr',secondArr)                   
              }

              firstArr.data.push(secondArr);
              firstArr.color.push(this.getRandomColor());
              //console.log(this.getRandomColor());
          }

          console.log(firstArr);

          this.setState({lineChartData:firstArr})


          var lineDataSet = []

          //console.log("lineDataSet",lineDataSet)

          for (var key in firstArr) {
            if (firstArr.hasOwnProperty(key)) {
                //console.log("total",key);
                
                for (let k=0; k<firstArr['label'].length; k++){
                  var lineLabel = {
                    label:"",
                    fill: true,
                    stack: 'stack1',
                    lineTension: 0.6,
                    borderCapStyle: 'round',
                    borderDashOffset: 0.0,
                    borderJoinStyle: 'miter',
                    backgroundColor: 'rgba(75,192,192,0.1)',
                    borderColor: "",
                    pointBackgroundColor: '#fff',
                    pointBorderWidth: 1,
                    pointHoverRadius: 5,
                    pointHoverBorderWidth: 2,
                    pointRadius: 1,
                    pointHitRadius: 10,
                    data:[]
                  }

                  
                    if (key === "data"){
                      //lineLabel.label =  firstArr[key][k] 
                      Object.assign(lineLabel, {data: firstArr[key][k]});
                      //lineDataSet.push(lineLabel);
                      lineDataSet.push(lineLabel);
                    }
                    if (key === "label"){
                      //console.log("Testing Data",firstArr['label'][k])
                      //lineLabel.label =  firstArr[key][k] 
                      //Object.assign(lineLabel, {label: firstArr[key][k]});
                      //lineDataSet.push(lineLabel);
                      //lineDataSet.push(lineLabel);
                      lineDataSet[k].label =  firstArr[key][k]
                    }
                    if (key === "color"){
                      var randColor = ""
                      randColor = this.getRandomColor();
                      //lineDataSet[k].push(lineLabel);
                      lineDataSet[k].borderColor =  randColor 
                      lineDataSet[k].backgroundColor = `rgba(${randColor},0.1)`
                      //Object.assign(lineLabel, {borderColor: firstArr[key][k]});                      
                    }
                }
            }
        }
        
        console.log('lineDataSet',lineDataSet)

        this.lineDataNew = lineDataSet;
        this.forceUpdate();            
        }
    }
  }
  
    async getBarData() {
        var formData = new FormData();
        formData.set('action','BarChart');
        
        this.setState({
          loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });


        if (response.status == 200 && response.data.success)	{
          //console.log("bar",response.data);

          var data = response.data;
          var test = [];
          var datasets = [];

        for (var key in data) {
            if (data.hasOwnProperty(key)) {
                //console.log("Created",data[key].created);
                if (key !== "success"){
                  test.push(key);
                }
            }
        }

        this.setState({barChartLabel:test});

        var createdValue=[], skippedValue=[], updatedValue=[];
           
        
        for (var newkey in data) {
          if (data.hasOwnProperty(newkey)) {              
              if (newkey !== "success"){
                createdValue.push(data[newkey].created)                
                skippedValue.push(data[newkey].skipped)                
                updatedValue.push(data[newkey].updated)
              }
          }
      }
      
      this.setState({
        createdValue:createdValue,
        skippedValue:skippedValue,
        updatedValue:updatedValue
      })    
          
      }
    }

    listLastMonths(){
        var theMonths = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
        var today = new Date();
        var aMonth = today.getMonth() + 1;
        var i,monthList=[];
        for (i=0; i<12; i++) {
            //document.writeln(theMonths[aMonth] + '<br>'); //here you can do whatever you want...
            
            monthList.push(theMonths[aMonth]);
            
            aMonth++;
            if (aMonth > 11) {
                aMonth = 0;
            }
        }
        
        this.setState({monthList:monthList})           
    }


  //   listLastMonths(){
  //     var theMonths = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
  //     var today = new Date();
  //     var aMonth = today.getMonth();
  //     var i,monthList=[];
  //     for (i=0; i<12; i++) {
  //         //document.writeln(theMonths[aMonth] + '<br>'); //here you can do whatever you want...
  //         monthList.push(theMonths[aMonth]);
          
  //         aMonth++;
  //         if (aMonth > 11) {
  //             aMonth = 0;
  //         }
  //     }
      
  //     this.setState({monthList:monthList})           
  // }

  
   

    render() {
      var { lineChartData } = this.state;

      this.lineData = {
        labels: this.state.monthList,
        //datasets: this.arrTest,
        datasets: this.lineDataNew
        // datasets: [
        //     {
        //     label: 'Posts',
        //     fill: true,
        //     lineTension: 0.6,
        //     backgroundColor: 'rgba(75,192,192,0.1)',
        //     borderColor: 'rgba(75,192,192,1)',
        //     borderCapStyle: 'round',
        //     borderDash: [],
        //     borderDashOffset: 0.0,
        //     borderJoinStyle: 'miter',
        //     pointBorderColor: 'rgba(75,192,192,1)',
        //     pointBackgroundColor: '#fff',
        //     pointBorderWidth: 1,
        //     pointHoverRadius: 5,
        //     pointHoverBackgroundColor: 'rgba(75,192,192,1)',
        //     pointHoverBorderColor: 'rgba(75,192,192,1)',
        //     pointHoverBorderWidth: 2,
        //     pointRadius: 1,
        //     pointHitRadius: 10,
        //     data: [0,0,0,0,0,0,0,0,0,0,2028,0]
        //   },
        //   {
        //     label: 'Pages',
        //     fill: true,
        //     lineTension: 1,
        //     backgroundColor: 'rgba(255, 99, 132,0.1)',
        //     borderColor: 'rgba(255, 99, 132,1)',
        //     borderCapStyle: 'round',
        //     borderDash: [],
        //     borderDashOffset: 0.0,
        //     borderJoinStyle: 'round',
        //     pointBorderColor: 'rgba(75,192,192,1)',
        //     pointBackgroundColor: '#fff',
        //     pointBorderWidth: 1,
        //     pointHoverRadius: 5,
        //     pointHoverBackgroundColor: 'rgba(75,192,192,1)',
        //     pointHoverBorderColor: 'rgba(220,220,220,1)',
        //     pointHoverBorderWidth: 2,
        //     pointRadius: 1,
        //     pointHitRadius: 10,
        //     data: [0,0,0,0,0,0,0,0,0,0,7,0]
        //   }    
        // ]  
      };
      this.barData = {
        labels: this.state.barChartLabel,
        datasets: [
          {
            stack: 'stack1',
            backgroundColor: 'rgba(255,99,132,1)',
            borderColor: 'rgba(255,99,132,1)',
            label: 'Inserted',
            data: this.state.createdValue,            
          },
          {
            stack: 'stack1',
            label: 'Updated',
            backgroundColor: 'rgba(44,195,193,1)',
            borderColor: 'rgba(255,99,132,1)',
            data: this.state.updatedValue   
          },
          {
            stack: 'stack1',
            label: 'Skipped',
            backgroundColor: 'rgba(50, 173, 255,1)',
            borderColor: 'rgba(50, 173, 255,1)',
            data: this.state.skippedValue  
          }
        ]
      }
        return (
          <div className=" container">
            <div className="csv-importer-panel  mt20" > 
              <div>
              <div  className="col-md-12 mb30">
              <h2 className="main-heading">{this.context.translateLanguage.ImportersActivity}</h2>
                
                <Line 
                  data={this.lineData} 
                  width={100} 
                  height={100}
                  options={this.lineOptions}
                />
                </div>
            
              <hr/>
              <div className="col-md-12">
              <h2 className="main-heading">{this.context.translateLanguage.ImportStatistics}</h2>
              
                <Bar
                  data={this.barData}
                  width='1000px'
                  height='1000px'
                  options={this.chartOptions}
                />
                </div>
            </div>
          </div> 
        </div>
        );
    }
}


export default DashboardGraphDisplay;