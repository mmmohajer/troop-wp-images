import React, {Component} from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import {AppContext} from '../../../context.js';


class SupportDisplay extends Component {
    static contextType = AppContext;
    constructor(props) {
        super(props);
        this.state = {
            supportEmail: '',
            supportType: '',
            message: '',
            newsletterEmail: ''
        }
    }

    componentDidMount(){
        //set Cookies for Support Page
        this.context.setSelectedTabCookies("support")  
    }

    async submitContactForm(event){
        //event.preventDefault();

        var formData = new FormData();
        formData.set('action', 'support_mail');
        formData.set('email', this.state.supportEmail);
        formData.set('query', this.state.supportType);
        formData.set('message', this.state.message);
        
        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log("Response", response);

        if(response.status == 200) {
            toast.success('Mail Sent Successfully');
        } 
    }

    async submitSubscriptionForm(){       

        var formData = new FormData();
        formData.set("action", "send_subscribe_email");
        formData.set("subscribe_email", this.state.newsletterEmail);        
        
        this.setState({ loading : true, });

        const response = await axios({
            method: 'post',
            url: ajaxurl,
            data: formData,
            config: { headers: {'Content-Type': 'multipart/form-data' }}
        });

        console.log("Response", response);

        if(response.status == 200) {
            toast.success('Mail Sent Successfully');
        } 
    }

    render() {
        return (            
                <div id="mapping-accordion">
                    <div className="card csv-importer-panel mt20">
                        <div className="card-body">
                            <div className="row justify-content-around">
                                <div className="col-md-12 text-center mt10 mb30">
                                    <p>{this.context.translateLanguage.LoveWPUltimateCSVImporterGivea5starreviewon} 
                                        <a className="csv-link" href="https://wordpress.org/">wordpress.org!</a>
                                    </p>
                                </div>
                                <div className="col-md-6">
                                    <div className="border-container">
                                        <h5 className="border-container-header">{this.context.translateLanguage.ContactSupport}</h5>
                                        <form method="" action="">
                                            <div className="form-group">
                                                <label>{this.context.translateLanguage.Email}</label>
                                                <input type="email" className="form-control" value={this.state.supportEmail} onChange={(event)=>{this.setState({supportEmail: event.target.value})}} />
                                            </div>
                                            <div className="form-group">
                                                <label>{this.context.Supporttype}</label>
                                                <select className="form-control" value={this.state.supportType} onClick={(event)=>{this.setState({supportType: event.target.value})}}>
                                                    <option value="bug_reporting">{this.context.translateLanguage.BugReporting}</option>
                                                    <option value="feature_enhancement">{this.context.translateLanguage.FeatureEnhancement}</option>
                                                </select>
                                            </div>
                                            <div className="form-group">
                                                <label>{this.context.translateLanguage.Message}</label>
                                                <textarea className="form-control" value={this.state.message} onChange={(event)=>{this.setState({message: event.target.value})}} rows="5"></textarea>
                                            </div>

                                            <div className="form-group d-flex justify-content-end">
                                                <input type="button" name="" onClick={(event) => { this.submitContactForm.bind(this)(event);}} className="smack-btn smack-btn-primary" value={this.context.translateLanguage.Send}/>
                                            </div>

                                        </form>

                                    </div>
                                </div>
                                <div className="col-md-6">
                                    <div className="border-container">
                                        <h5 className="border-container-header">{this.context.translateLanguage.NewsletterSubscription}</h5>
                                        <form action="" method="">
                                            <div className="form-group">
                                                <label>{this.context.translateLanguage.Email}
                                                </label>
                                                <input type="email" name="" className="form-control" value={this.state.newsletterEmail} onChange={(event)=>{this.setState({newsletterEmail: event.target.value})}}/>
                                            </div>
                                            <div className="form-group d-flex justify-content-end">
                                                <input type="button" name=""className="smack-btn smack-btn-primary" onClick={() => { this.submitSubscriptionForm();}} value={this.context.translateLanguage.Subscribe}/>
                                            </div>

                                        </form>

                                    </div>

                                    <div className="mt40 p15">
                                        <h5>{this.context.translateLanguage.Note}</h5>
                                        <div className="mt20">
                                            <i className="csv-icon-document-text text-primary mr5"></i>
                                            {this.context.translateLanguage.SubscribetoSmackcodersMailinglistafewmessagesayear}
                                        </div>
                                        <div className="mt20">
                                            <i className="csv-icon-mail text-primary mr5"></i>
                                            {this.context.translateLanguage.Pleasedraftamailto} <span className="text-primary font-weight-bold">support@smackcoders.com.</span> {this.context.translateLanguage.Ifyoudoesnotgetanyacknowledgementwithinanhour}
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>

                </div>

           
        )
    }
}

export default SupportDisplay;
