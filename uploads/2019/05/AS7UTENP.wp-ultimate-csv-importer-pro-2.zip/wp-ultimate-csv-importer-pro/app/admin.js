if (!global._babelPolyfill && !window._babelPolyfill) {
    require('babel-polyfill');
}

import React from 'react';
import ReactDOM from 'react-dom';
import AdminView from './admin/app';
import { AppProvider } from './provider';
import { ToastContainer } from 'react-toastify';


document.addEventListener('DOMContentLoaded', function() {
	console.log('Wp Ultimate CSV Importer Pro');
    //console.log(document.getElementById('wp-csv-importer-admin'));
            ReactDOM.render(        
                <div className="wp-ultimate-csv-importer">
                    <ToastContainer
                position="top-right"
                //autoClose={4000}
                autoClose={false}
                hideProgressBar
                newestOnTop
                closeOnClick
                rtl={false}
                pauseOnVisibilityChange
                draggable
                pauseOnHover
                />
                     <AppProvider><AdminView/></AppProvider>

                <p className="text-center mt40 mb20">Powered by <a className="csv-link" href="https://www.smackcoders.com?utm_source=wordpress&amp;utm_medium=plugin&amp;utm_campaign=pro_csv_importer" target="blank">Smackcoders</a></p>
                </div>
           
         , document.getElementById('wp-csv-importer-admin'));

 });
