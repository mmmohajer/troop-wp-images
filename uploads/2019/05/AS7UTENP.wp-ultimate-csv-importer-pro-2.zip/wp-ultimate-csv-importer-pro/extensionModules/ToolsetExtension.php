<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\WCSV;

if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly

class ToolsetExtension extends ExtensionHandler{
	private static $instance = null;

    public static function getInstance() {
		
		if (ToolsetExtension::$instance == null) {
			ToolsetExtension::$instance = new ToolsetExtension;
		}
		return ToolsetExtension::$instance;
    }

	/**
	* Provides Toolset fields for specific post type
	* @param string $data - selected import type
	* @return array - mapping fields
	*/
    public function processExtension($data) {
		global $wpdb;
		//$import_type = $data['Types'];
		$import_type = $data;
		$import_name_type = $this->import_name_as($import_type);
		$response = [];
		$typesFields = array();
		if($import_type == 'Users') {
			$getUserMetaFields = get_option('wpcf-usermeta');
			if(is_array($getUserMetaFields)) {
				foreach ($getUserMetaFields as $optKey => $optVal) {
					$typesFields["TYPES"][$optVal['slug']]['label'] = $optVal['name'];
					$typesFields["TYPES"][$optVal['slug']]['name'] = $optVal['slug'];
				}
			}
			// $typesFields['TYPES']['Parent_group']['label'] = 'Parent Group';
			// $typesFields['TYPES']['Parent_group']['name'] = 'Parent_Group';
			// $typesFields['TYPES']['Parent_group']['slug'] = 'Parent_Group';

		} else {

			$import_type = $this->import_post_types($import_name_type);
			$get_groups = $wpdb->get_results($wpdb->prepare("select ID from $wpdb->posts where post_type = %s", 'wp-types-group'));
			
            $get_groupsc = $wpdb->get_results($wpdb->prepare("select ID from $wpdb->posts where post_type = %s", 'wp-types-term-group'));
			///	
			if(!empty($get_groupsc && ($import_name_type == 'Categories' || $import_name_type == 'Tags' || $import_name_type == 'Taxonomies'))) {
				
				$wptermsfields = array();
				$wptermsfields = get_option('wpcf-termmeta');
				
				foreach($get_groupsc as $item => $group) {
					$lastId       = $group->ID;
					$rule_groups  =$import_type;
					$rule_groups = trim($rule_groups,',');
					$rules = explode(',', $rule_groups);
					if(in_array($import_type, $rules)) {
						$fields       = get_post_meta( $lastId, '_wp_types_group_fields', true );
						$fields       = trim($fields, ',');
						#$trim = substr( $fields, 1, - 1 );
						$types_fields = explode( ',', $fields );
						
						$count = count( $types_fields );
						if ( is_array( $types_fields ) ) {
							for ( $i = 0; $i < $count; $i ++ ) {
								// foreach ( $types_fields as $key => $value ) {
								// 	$typesFields['TYPES'][ $value ]['name']  = $value;
								// 	$typesFields['TYPES'][ $value ]['slug']  = $value;
								// 	$typesFields['TYPES'][ $value ]['label'] = $value;
								// }

								foreach($wptermsfields as $term_field_value){
									$search_value = $term_field_value['slug'] ;
									if(in_array($search_value , $types_fields)){
										$typesFields['TYPES'][ $search_value ]['name']  = $term_field_value['slug'];
										$typesFields['TYPES'][ $search_value ]['slug']  = $term_field_value['slug'];
										$typesFields['TYPES'][ $search_value ]['label'] = $term_field_value['name'];
									}
								}	
							}
						}
					}
				}
			}
			///
			if(!empty($get_groups && ($import_name_type !== 'Categories' && $import_name_type !== 'Tags' && $import_name_type !== 'Taxonomies'))) {

				$wpfields = array();
				$wpfields = get_option('wpcf-fields');
								

				foreach($get_groups as $item => $group) {
					$lastId       = $group->ID;
					
					$rule_groups  = get_post_meta( $lastId, '_wp_types_group_post_types', true );	
					$rule_groups = trim($rule_groups,',');
					$rules = explode(',', $rule_groups);

					$fields       = get_post_meta( $lastId, '_wp_types_group_fields', true );	
					$fields       = trim($fields, ',');
					#$trim = substr( $fields, 1, - 1 );
					$types_fields = explode( ',', $fields );
					
					$count        = count( $types_fields );
					if ( is_array( $types_fields ) ) {

						for ( $i = 0; $i < $count; $i ++ ) {
							
							foreach ( $types_fields as $key => $value ) {	
								//change repeatable_group to user readable format	
								$value = $this->changeRepeatableGroupName($value);

								$typesFields['TYPES'][ $value ]['name']  = $value;
								$typesFields['TYPES'][ $value ]['slug']  = $value;
								$typesFields['TYPES'][ $value ]['label'] = $value;
							}

							// foreach($wpfields as $field_value){
							// 	$search_value = $field_value['slug'] ;
							// 	//change repeatable_group to user readable format	
								
							// 	if(in_array($search_value , $types_fields)){

							// 		$typesFields['TYPES'][ $search_value ]['name']  = $field_value['slug'];
							// 		$typesFields['TYPES'][ $search_value ]['slug']  = $field_value['slug'];
							// 		$typesFields['TYPES'][ $search_value ]['label'] = $field_value['name'];
							// 	}
							// }	
						}
					}
				}

			} 
			///
			$relationship_table_name = $wpdb->prefix . "toolset_relationships";
			$get_relationship = $wpdb->get_results( "SELECT id FROM $relationship_table_name" );
			if(!empty($get_relationship)){

				if($import_name_type !== 'Categories' && $import_name_type !== 'Tags' && $import_name_type !== 'Taxonomies'){
					$typesFields['TYPES']['types_relationship']['label'] = 'Types Relationship';
					$typesFields['TYPES']['types_relationship']['name'] = 'types_relationship';
					$typesFields['TYPES']['types_relationship']['slug'] = 'types_relationship';
					
					$typesFields['TYPES']['intermediate']['label'] = 'Intermediate';
					$typesFields['TYPES']['intermediate']['name'] = 'intermediate';
					$typesFields['TYPES']['intermediate']['slug'] = 'intermediate';

					$typesFields['TYPES']['relationship_slug']['label'] = 'Relationship Slug';
					$typesFields['TYPES']['relationship_slug']['name'] = 'relationship_slug';
					$typesFields['TYPES']['relationship_slug']['slug'] = 'relationship_slug';

					$typesFields['TYPES']['Parent_group']['label'] = 'Parent Group';
					$typesFields['TYPES']['Parent_group']['name'] = 'Parent_Group';
					$typesFields['TYPES']['Parent_group']['slug'] = 'Parent_Group';
				}
			}
		}
		$tool_value = $this->convert_fields_to_array($typesFields);
		$response['types_fields'] = $tool_value;
		return $response;
			
	}

	public function changeRepeatableGroupName($value) {
        global $wpdb;
        $explode = explode('_',$value);
        if (count($explode)>1) {
            if (in_array('repeatable',$explode)) {
                $name = $wpdb->get_results("SELECT post_name FROM ".$wpdb->prefix."posts WHERE id ='{$explode[3]}'");
                return $name[0]->post_name;
            }else{
				return $value;
			}
        }else{
            return $value;
		}
	}

	/**
	* Toolset extension supported import types
	* @param string $import_type - selected import type
	* @return boolean
	*/
	public function extensionSupportedImportType($import_type ){
		if(in_array('types/wpcf.php' , $this->get_active_plugins())){
			$import_type = $this->import_name_as($import_type);
			if($import_type == 'Posts' || $import_type == 'Pages' || $import_type == 'CustomPosts' || $import_type == 'event' || $import_type == 'event-recurring' || $import_type == 'location' || $import_type == 'Users' || $import_type == 'WooCommerce' || $import_type == 'MarketPress' || $import_type == 'WPeCommerce' || $import_type == 'eShop' || $import_type == 'Taxonomies' || $import_type == 'Categories' || $import_type == 'Tags' ) {
				return true;
			}
			if($import_type == 'ticket'){
				if(in_array('events-manager/events-manager.php', $this->get_active_plugins())){
					return false;
				}else{
					return true;
				}
			}
			else{
				return false;
			}
		}
	}
}