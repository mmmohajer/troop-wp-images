<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\WCSV;

if ( ! defined( 'ABSPATH' ) )
exit; // Exit if accessed directly

class ACFImport {
	private static $acf_instance = null,$media_instance;

	public static function getInstance() {

		if (ACFImport::$acf_instance == null) {
			ACFImport::$acf_instance = new ACFImport;
			ACFImport::$media_instance = MediaHandling::getInstance();
			return ACFImport::$acf_instance;
		}
		return ACFImport::$acf_instance;
	}

	/**
     * Imports ACF Free fields
     * @param string $acf_wpname_element - acf fields
     * @param string $acf_csv_element - csv headers
	 * @param string $importAs - selected import type
	 * @param string $post_id - inserted post id
     */
	function acf_import_function($acf_wpname_element ,$acf_csv_element, $importAs , $post_id){
		$acf_wp_name = $acf_wpname_element;
		$acf_csv_name = $acf_csv_element; 
		global $wpdb;

		$helpers_instance = ImportHelpers::getInstance();

		$get_acf_fields = $wpdb->get_results($wpdb->prepare("select post_content, post_name from $wpdb->posts where post_type = %s and post_excerpt = %s", 'acf-field', $acf_wp_name ), ARRAY_A);
		foreach($get_acf_fields as $keys => $value_type){
			$get_type_field = unserialize($value_type['post_content']);	
			$field_type = $get_type_field['type'];
			$key = $get_acf_fields[0]['post_name'];
			$return_format = $get_type_field['return_format'];
			if($field_type == 'text' || $field_type == 'textarea' || $field_type == 'number' || $field_type == 'email' || $field_type == 'url' || $field_type == 'password' || $field_type == 'range' || $field_type == 'radio' || $field_type == 'true_false' || $field_type == 'time_picker' || $field_type == 'color_picker' || $field_type == 'button_group' || $field_type == 'oembed' || $field_type == 'wysiwyg'){
				$map_acf_wp_element = $acf_wp_name;
				$map_acf_csv_element = $acf_csv_name;	
			}
			if($field_type == 'date_time_picker'){

				$dt_var = trim($acf_csv_name);
				$date_time_of = \DateTime::createFromFormat('d/m/Y H:i', "$dt_var");

				if(!$date_time_of){
					return;
				}
				else{	
					$date_time_of = $date_time_of->format('Y-m-d h:i:s'); 
				}

				$map_acf_csv_element = $date_time_of;
				$map_acf_wp_element = $acf_wp_name;
			}
			if($field_type == 'date_picker'){

				$var = trim($acf_csv_name);
				$date = str_replace('/', '-', "$var");
				$date_of = date('Ymd', strtotime($date));

				$map_acf_csv_element = $date_of;
				$map_acf_wp_element = $acf_wp_name;

			}
			if($field_type == 'post_object' || $field_type == 'page_link' || $field_type == 'user' || $field_type == 'select'){
				if($get_type_field['multiple'] == 0){	
					$maps_acf_csv_name = $acf_csv_name;	
				}else{	
					$explo_acf_csv_name = explode(',',trim($acf_csv_name));	
					$maps_acf_csv_name = serialize($explo_acf_csv_name);	
				}
				$map_acf_csv_element = $maps_acf_csv_name;
				$map_acf_wp_element = $acf_wp_name;
			}
			if($field_type == 'relationship' || $field_type == 'taxonomy'){
				$relations = array();
				$check_is_valid_term = null;
				$get_relations = $acf_csv_name;
				if(!empty($get_relations)){
					$exploded_relations = explode(',', $get_relations);
					foreach ($exploded_relations as $relVal) {
						$relationTerm = trim($relVal);
						if ($field_type == 'taxonomy') {
							$check_is_valid_term = $helpers_instance->get_requested_term_details($post_id, $relationTerm);
							$relations[] = $check_is_valid_term;
						} else {
							$reldata = strlen($relationTerm);
							$checkrelid = intval($relationTerm);
							$verifiedRelLen = strlen($checkrelid);
							if ($reldata == $verifiedRelLen) {
								$relations[] = $relationTerm;
							} else {
								$relation_id = $wpdb->get_col($wpdb->prepare("select id from $wpdb->posts where post_title = %s",$relVal));
								if (!empty($relation_id)) {
									$relations[] = $relation_id[0];
								}
							}
						}
					}
				}

				$map_acf_csv_element = $relations;
				$map_acf_wp_element = $acf_wp_name;
			}		

			if($field_type == 'checkbox'){

				$explode_acf_csv_name = explode(',',trim($acf_csv_name));	
				$serial_acf_csv_name = serialize($explode_acf_csv_name);

				$map_acf_csv_element = $serial_acf_csv_name;
				$map_acf_wp_element = $acf_wp_name;
			}
			if($field_type == 'link'){

				$serial_acf_csv_name = serialize($acf_csv_name);

				$map_acf_csv_element = $serial_acf_csv_name;
				$map_acf_wp_element = $acf_wp_name;
			}
			if ($field_type == 'message') {
				$get_type_field['message'] = $acf_csv_name;
				// $get_acf_field = serialize($get_type_field);
				// $updt_query = "update $wpdb->posts set post_content ='$get_acf_field' where post_name = '$value'";
				// $wpdb->query($updt_query);
			}
			elseif ($field_type == 'image') {
				if ($return_format == 'url' || $return_format == 'array') {
					$ext = pathinfo($acf_csv_name, PATHINFO_EXTENSION);
					if($ext== 'jpg' || $ext == 'jpeg' || $ext == 'png') {
						$img_id = $wpdb->get_col($wpdb->prepare("select ID from $wpdb->posts where guid = %s AND post_type='attachment'",$acf_csv_name));
						if(!empty($img_id)) {
							$map_acf_csv_element=$img_id[0];
						}
						else {
							$map_acf_csv_element = ACFImport::$media_instance->media_handling($acf_csv_name, $post_id, $acf_wpname_element);
						}
					}
					else {
						$map_acf_csv_element = ACFImport::$media_instance->media_handling($acf_csv_name, $post_id, $acf_wpname_element);
					}
				}
				else {
					$map_acf_csv_element = ACFImport::$media_instance->media_handling($acf_csv_name, $post_id, $acf_wpname_element);
				}
				$map_acf_wp_element = $acf_wp_name;
			}
			elseif ($field_type == 'file') {
				if ($return_format == 'url' || $return_format == 'array') {
					$ext = pathinfo($acf_csv_name, PATHINFO_EXTENSION);
					if($ext=='pdf' || $ext=='mp3' || $ext == $ext ){
						$pdf_id = $wpdb->get_col($wpdb->prepare("select ID from $wpdb->posts where guid = %s AND post_type='attachment'",$acf_csv_name));
						if(!empty($pdf_id)) {
							$map_acf_csv_element=$pdf_id[0];
						}
						else {
							$map_acf_csv_element = ACFImport::$media_instance->media_handling($acf_csv_name, $post_id, $acf_wpname_element);
						}
					}
					else {
						$map_acf_csv_element = ACFImport::$media_instance->media_handling($acf_csv_name, $post_id, $acf_wpname_element);
					}
				}
				else {
					$map_acf_csv_element = ACFImport::$media_instance->media_handling($acf_csv_name, $post_id, $acf_wpname_element);
				}
				$map_acf_wp_element = $acf_wp_name;
			}
		}

		if ($importAs == 'Users') {
			update_user_meta($post_id, $map_acf_wp_element, $map_acf_csv_element);
			update_user_meta($post_id, '_' . $map_acf_wp_element, $key);
		} else {
			//update_post_meta($pID, $data_array['groupfield_slug'].'_'.$value, $data_array[$value]);
			update_post_meta($post_id, $map_acf_wp_element, $map_acf_csv_element);
			update_post_meta($post_id, '_' . $map_acf_wp_element, $key);
		}
		$listTaxonomy = get_taxonomies();
		if (in_array($importAs, $listTaxonomy)) {
			if($term_meta = 'yes'){
				add_term_meta($post_id, $map_acf_wp_element, $map_acf_csv_element);
				add_term_meta($post_id, '_' . $map_acf_wp_element, $key);
			}else{
				$option_name = $importAs . "_" . $post_id . "_" . $map_acf_wp_element;
				$option_value = $map_acf_csv_element;
				if (is_array($option_value)) {
					$option_value = serialize($option_value);
				}

				update_option("$option_name", "$option_value");
			}
		}
	}
}
