<?php
/******************************************************************************************
 * Copyright (C) Smackcoders. - All Rights Reserved under Smackcoders Proprietary License
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * You can contact Smackcoders at email address info@smackcoders.com.
 *******************************************************************************************/

namespace Smackcoders\WCSV;

if ( ! defined( 'ABSPATH' ) )
    exit; // Exit if accessed directly

class WooCommerceCoreImport {
    private static $woocommerce_core_instance = null,$media_instance;

    public static function getInstance() {
		
		if (WooCommerceCoreImport::$woocommerce_core_instance == null) {
			WooCommerceCoreImport::$woocommerce_core_instance = new WooCommerceCoreImport;
			WooCommerceCoreImport::$media_instance = new MediaHandling();
			return WooCommerceCoreImport::$woocommerce_core_instance;
		}
		return WooCommerceCoreImport::$woocommerce_core_instance;
    }


    public function woocommerce_variations_import($data_array , $mode , $check , $hash_key , $line_number) {
		global $wpdb;
		$log_table_name = $wpdb->prefix ."import_detail_log";
       
		$productInfo = '';
		$returnArr = array('MODE' => $mode , 'ID' => '');
		$product_id = isset($data_array['PRODUCTID']) ? $data_array['PRODUCTID'] : '';
		$parent_sku = isset($data_array['PARENTSKU']) ? $data_array['PARENTSKU'] : '';
		$variation_id =  isset($data_array['VARIATIONID']) ? $data_array['VARIATIONID'] : '';
		$variation_sku = isset($data_array['VARIATIONSKU']) ? $data_array['VARIATIONSKU'] : '';
		
		if($product_id != '') {
			//$variation_condition = 'insert_using_product_id';
			$variation_condition = 'update_using_variation_sku';
			#endif;
		} elseif($parent_sku != '') {
			$get_parent_product_id = $wpdb->get_results( $wpdb->prepare( "select post_id from $wpdb->postmeta where meta_value = %s order by post_id desc", $parent_sku ) );
			$count = count( $get_parent_product_id );
			#$key = $count - 1;
			$key = 0;
			if ( ! empty( $get_parent_product_id ) ) {
				$product_id = $get_parent_product_id[$key]->post_id;
				
			} else {
				$product_id = '';
			}
			$variation_condition = 'insert_using_product_sku';
		}
		// Get basic information for a product based on product id
		if($product_id != '') {
			$is_exist_product = $wpdb->get_results($wpdb->prepare("select * from $wpdb->posts where ID = %d", $product_id));
			if(!empty($is_exist_product) && $is_exist_product[0]->ID == $product_id) {
				$productInfo = $is_exist_product[0];
			} else {
				#return $returnArr;
			}
		}
		if($mode == 'Update'){
			if($check == 'VARIATIONSKU' && $check == 'VARIATIONID') {
				$variation_condition = 'update_using_variation_id_and_sku';
			} elseif ($check == 'VARIATIONID') {
				$variation_condition = 'update_using_variation_id';
			} elseif ($check == 'VARIATIONSKU') {
				$variation_condition = 'update_using_variation_sku';
			}
		}

		switch ($variation_condition) {
			case 'update_using_variation_id_and_sku':
				
				$get_variation_data = $wpdb->get_results( $wpdb->prepare( "select DISTINCT pm.post_id from $wpdb->posts p join $wpdb->postmeta pm on p.ID = pm.post_id where p.ID = %d and p.post_type = %s and pm.meta_value = %s", $variation_id, 'product_variation', $variation_sku ) );

				if ( ! empty( $get_variation_data ) && $get_variation_data[0]->post_id == $variation_id ) {
					$returnArr = $this->importVariationData( $product_id, $variation_id, 'update_using_variation_id_and_sku', $productInfo , $hash_key ,$get_variation_data );
				} else {
					$returnArr = $this->importVariationData( $product_id, $variation_id, 'default', $productInfo ,$hash_key);
				}
				break;
			case 'update_using_variation_id':
				
				$get_variation_data = $wpdb->get_results( $wpdb->prepare( "select * from $wpdb->posts where ID = %d and post_type = %s", $variation_id, 'product_variation' ) );
				if ( ! empty( $get_variation_data ) && $get_variation_data[0]->ID == $variation_id ) {
					$returnArr = $this->importVariationData( $product_id, $variation_id, 'update_using_variation_id', $productInfo ,$hash_key , $get_variation_data );
				} else {
					$returnArr = $this->importVariationData( $product_id, $variation_id, 'default', $productInfo ,$hash_key );
				}
				break;
			case 'update_using_variation_sku':
				
				$variation_data = $wpdb->get_results($wpdb->prepare("select post_id from $wpdb->postmeta where meta_value = %s order by post_id desc", $variation_sku));
				$variation_id = $variation_data[0]->post_id;
				$get_variation_data = $wpdb->get_results( $wpdb->prepare( "select * from $wpdb->posts where ID = %d and post_type = %s", $variation_id, 'product_variation' ) );
				if ( ! empty( $get_variation_data ) && $get_variation_data[0]->ID == $variation_id) {
					$returnArr = $this->importVariationData( $product_id,$variation_id, 'update_using_variation_sku', $productInfo, $hash_key ,$get_variation_data , $line_number);
				} else {
					$returnArr = $this->importVariationData( $product_id, $variation_id, 'default', $productInfo,$hash_key , $line_number);
				}
				break;
			case 'insert_using_product_id':
				$returnArr = $this->importVariationData( $product_id, $variation_id, 'insert_using_product_id', $productInfo ,$hash_key , $line_number);
				break;
			case 'insert_using_product_sku':
				$returnArr = $this->importVariationData( $product_id, $variation_id, 'insert_using_product_sku', $productInfo ,$hash_key , $line_number);
				break;
			default:
				$returnArr = $this->importVariationData( $product_id, $variation_id, 'default', $productInfo ,$hash_key , $line_number);
				break;
		}

		return $returnArr;
	}

	public function importVariationData ($product_id, $variation_id, $type, $productInfo, $hash_key, $exist_variation_data = array() , $line_number) {
		global $wpdb;
		$helpers_instance = ImportHelpers::getInstance();
		$core_instance = CoreFieldsImport::getInstance();
		global $core_instance;
		$log_table_name = $wpdb->prefix ."import_detail_log";

		$updated_row_counts = $helpers_instance->update_count($hash_key);
		$created_count = $updated_row_counts['created'];
		$updated_count = $updated_row_counts['updated'];
		$skipped_count = $updated_row_counts['skipped'];

		// Create a new variation for the specific product if product exists.
		if($type == 'default' || $type == 'insert_using_product_id' || $type == 'insert_using_product_sku') {
			
			$get_count_of_variations = $wpdb->get_results( $wpdb->prepare( "select count(*) as variations_count from $wpdb->posts where post_parent = %d and post_type = %s", $product_id, 'product_variation' ) );
			$variations_count = $get_count_of_variations[0]->variations_count;
			$menu_order_count = 0;
			if ($variations_count == 0) {
				$variations_count = '';
				$menu_order= 0 ;
			} else {
				$variations_count = $variations_count + 1;
				$menu_order_count = $variations_count - 1;
				$variations_count = '-' . $variations_count;
			}
			$get_variation_data = $wpdb->get_results($wpdb->prepare("select * from $wpdb->posts where ID = %d", $product_id));
			foreach($get_variation_data as $key => $val) {
				
				if($product_id == $val->ID){

					$variation_data = array();
					$variation_data['post_title'] = $val->post_title ;
					$variation_data['post_date'] = $val->post_date;
					$variation_data['post_type'] = 'product_variation';
					$variation_data['post_status'] = 'publish';
					$variation_data['comment_status'] = 'closed';
					$variation_data['ping_status'] = 'closed';
					$variation_data['menu_order'] = $menu_order_count;
					$variation_data['post_name'] = 'product-' . $val->ID . '-variation' . $variations_count;
					$variation_data['post_parent'] = $val->ID;
					//$variation_data['guid'] =  get_permalink($val->post_title);
				
				}
			}
			$variationid = wp_insert_post($variation_data);

			$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Variation ID: ' . $variationid;
			//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key ,$variationid);	
			$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
			
			$returnArr = array( 'ID' => $variationid, 'MODE' => 'Inserted' );
			return $returnArr;
			//Update the existing variations using variation id and sku
		} elseif ($type == 'update_using_variation_id' || $type == 'update_using_variation_sku' || $type == 'update_using_variation_id_and_sku') {
			
			foreach($exist_variation_data as $key => $val) {
				
				if($variation_id == $val->ID){
					$variation_data['ID'] = $val->ID;
					$variation_data['post_title'] = $val->post_title;
					$variation_data['post_status'] = 'publish';
					$variation_data['comment_status'] = 'open';
					$variation_data['ping_status'] = 'open';
					$variation_data['post_name'] = 'product-' . $val->ID . '-variation' . $variations_count;
					$variation_data['post_parent'] = $val->post_parent;
					//$variation_data['guid'] =  get_permalink($val->ID);
					$variation_data['post_type'] = 'product_variation';
					$variation_data['menu_order'] = $val->menu_order;
				}
			}

			wp_update_post($variation_data);

			$core_instance->detailed_log[$line_number]['Message'] = 'Updated Variation ID: ' . $variationid;
			//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key ,$variationid);	
			$fields = $wpdb->get_results("UPDATE $log_table_name SET updated = $updated_count WHERE hash_key = '$hash_key'");

			$returnArr = array( 'ID' => $variation_id, 'MODE' => 'Updated');
			return $returnArr;
		}
	}

	public function woocommerce_orders_import($data_array , $mode , $check , $hash_key , $line_number) {
		
		$returnArr = array();	
		global $wpdb;
		$helpers_instance = ImportHelpers::getInstance();
		$core_instance = CoreFieldsImport::getInstance();
		global $core_instance;

		$log_table_name = $wpdb->prefix ."import_detail_log";

		$updated_row_counts = $helpers_instance->update_count($hash_key);
		$created_count = $updated_row_counts['created'];
		$updated_count = $updated_row_counts['updated'];
		$skipped_count = $updated_row_counts['skipped'];
		
		$data_array['post_type'] = 'shop_order';
		$data_array['post_excerpt'] = $data_array['customer_note'];
		if(isset($data_array['order_status'])) {
			$data_array['post_status'] = $data_array['order_status'];}
		/* Assign order date */
		if(!isset( $data_array['order_date'] )) {
			$data_array['post_date'] = current_time('Y-m-d H:i:s');
		} else {
			if(strtotime( $data_array['order_date'] )) {
				$data_array['post_date'] = date( 'Y-m-d H:i:s', strtotime( $data_array['order_date'] ) );
			} else {
				$data_array['post_date'] = current_time('Y-m-d H:i:s');
			}
		}
		if ($mode == 'Insert') {	
			$retID = wp_insert_post( $data_array );
			$mode_of_affect = 'Inserted';
			
			if(is_wp_error($retID) || $retID == '') {
				$core_instance->detailed_log[$line_number]['Message'] = "Can't insert this Order. " . $retID->get_error_message();
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
				$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
				return array('MODE' => $mode, 'ERROR_MSG' => $retID->get_error_message());
			}
			$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Order ID: ' . $retID;
			//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
			$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");

		} else {
			if ($mode == 'Update') {
				if($check == 'ORDERID'){
					$orderid = $data_array['ORDERID'];
					$post_type = $data_array['post_type'];
					$update_query = "select ID from $wpdb->posts where ID = '$orderid' and post_type = '$post_type' order by ID DESC";
					$ID_result = $wpdb->get_results($update_query);

					if (is_array($ID_result) && !empty($ID_result)) {
						$retID = $ID_result[0]->ID;
						$data_array['ID'] = $retID;
						wp_update_post($data_array);
						$mode_of_affect = 'Updated';

						$core_instance->detailed_log[$line_number]['Message'] = 'Updated Order ID: ' . $retID;
						//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
						$fields = $wpdb->get_results("UPDATE $log_table_name SET updated = $updated_count WHERE hash_key = '$hash_key'");	
					} else{
						$retID = wp_insert_post( $data_array );
						$mode_of_affect = 'Inserted';
						
						if(is_wp_error($retID) || $retID == '') {
							$core_instance->detailed_log[$line_number]['Message'] = "Can't insert this Order. " . $retID->get_error_message();
							//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
							$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
							return array('MODE' => $mode, 'ERROR_MSG' => $retID->get_error_message());
						}
						$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Order ID: ' . $retID;
						//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
						$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
					}
				}else{
					$retID = wp_insert_post( $data_array );
					$mode_of_affect = 'Inserted';
					
					if(is_wp_error($retID) || $retID == '') {
						$core_instance->detailed_log[$line_number]['Message'] = "Can't insert this Order. " . $retID->get_error_message();
						//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
						$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
						return array('MODE' => $mode, 'ERROR_MSG' => $retID->get_error_message());
					}
					$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Order ID: ' . $retID;
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
					$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
				}
			} 
		}
		$returnArr['ID'] = $retID;
		$returnArr['MODE'] = $mode_of_affect;
		return $returnArr;
	}

	public function woocommerce_coupons_import($data_array , $mode , $check , $hash_key , $line_number) {
		
		global $wpdb; 
		$helpers_instance = ImportHelpers::getInstance();
		$core_instance = CoreFieldsImport::getInstance();
		global $core_instance;
		$log_table_name = $wpdb->prefix ."import_detail_log";

		$updated_row_counts = $helpers_instance->update_count($hash_key);
		$created_count = $updated_row_counts['created'];
		$updated_count = $updated_row_counts['updated'];
		$skipped_count = $updated_row_counts['skipped'];

		$returnArr = array();
		
		$data_array['post_type'] = 'shop_coupon';
		$data_array['post_title'] = $data_array['coupon_code'];
		$data_array['post_name'] = $data_array['coupon_code'];
		if(isset($data_array['description'])) {
			$data_array['post_excerpt'] = $data_array['description'];
		}

		/* Post Status Options */
		if ( !empty($data_array['coupon_status']) ) {
			$data_array = $helpers_instance->assign_post_status( $data_array );
		} else {
			$data_array['coupon_status'] = 'publish';
		}

		if ($mode == 'Insert') {
			$retID = wp_insert_post($data_array);
			$mode_of_affect = 'Inserted';
			
			if(is_wp_error($retID) || $retID == '') {
				$core_instance->detailed_log[$line_number]['Message'] = "Can't insert this Coupon. " . $retID->get_error_message();
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
				$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
				return array('MODE' => $mode, 'ERROR_MSG' => $retID->get_error_message());
			}
			$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Coupon ID: ' . $retID;
			//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
			$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");

		} else {
			if ($mode == 'Update') {
				if($check == 'COUPONID'){
					$coupon_id = $data_array['COUPONID'];
					$post_type = $data_array['post_type'];
					$update_query = "select ID from $wpdb->posts where ID = '$coupon_id' and post_type = '$post_type' order by ID DESC";
					$ID_result = $wpdb->get_results($update_query);

					if (is_array($ID_result) && !empty($ID_result)) {
						$retID = $ID_result[0]->ID;
						$data_array['ID'] = $retID;
						wp_update_post($data_array);
						$mode_of_affect = 'Updated';

						$core_instance->detailed_log[$line_number]['Message'] = 'Updated Coupon ID: ' . $retID;
						//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
						$fields = $wpdb->get_results("UPDATE $log_table_name SET updated = $updated_count WHERE hash_key = '$hash_key'");			
					} else{
						$retID = wp_insert_post( $data_array );
						$mode_of_affect = 'Inserted';
						
						if(is_wp_error($retID) || $retID == '') {
							$core_instance->detailed_log[$line_number]['Message'] = "Can't insert this Coupon. " . $retID->get_error_message();
							//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
							$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
							return array('MODE' => $mode, 'ERROR_MSG' => $retID->get_error_message());
						}
						$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Coupon ID: ' . $retID;
						//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
						$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
					}
				}
				else{
					$retID = wp_insert_post( $data_array );
					$mode_of_affect = 'Inserted';
					
					if(is_wp_error($retID) || $retID == '') {
						$core_instance->detailed_log[$line_number]['Message'] = "Can't insert this Coupon. " . $retID->get_error_message();
						//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
						$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
						return array('MODE' => $mode, 'ERROR_MSG' => $retID->get_error_message());
					}
					$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Coupon ID: ' . $retID;
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
					$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
				}
			} 
		}
		$returnArr['ID'] = $retID;
		$returnArr['MODE'] = $mode_of_affect;
		return $returnArr;
	}

	public function woocommerce_refunds_import($data_array , $mode , $check  ,$hash_key , $line_number) {
		$returnArr = array();
		$mode_of_affect = 'Inserted';
		global $wpdb; 
		$helpers_instance = ImportHelpers::getInstance();
		$core_instance = CoreFieldsImport::getInstance();
		global $core_instance;
		$log_table_name = $wpdb->prefix ."import_detail_log";

		$updated_row_counts = $helpers_instance->update_count($hash_key);
		$created_count = $updated_row_counts['created'];
		$updated_count = $updated_row_counts['updated'];
		$skipped_count = $updated_row_counts['skipped'];
		
		$parent_order_id = 0;
		$post_excerpt = '';
		if(isset($data_array['REFUNDID']))
			$order_id = $data_array['REFUNDID'];
		elseif(isset($data_array['post_parent']))
			$parent_order_id = $data_array['post_parent'];
		if(isset($data_array['post_excerpt']))
			$post_excerpt = $data_array['post_excerpt'];
		$get_order_id = $wpdb->get_results($wpdb->prepare("select * from $wpdb->posts where ID = %d", $parent_order_id));
		if(!empty($get_order_id)){
			$refund = $get_order_id[0]->ID;
			
			if(isset($refund)){
				$date_format = date('m-j-Y-Hi-a');
				$date_read = date('M j, Y @ H:i a');
				$data_array['post_title'] = 'Refund &ndash;' . $date_read; 
				$data_array['post_type'] = 'shop_order_refund';
				$data_array['post_parent'] = $parent_order_id;
				$data_array['post_status'] = 'wc-completed';
				//$data_array['post_excerpt'] = $post_excerpt;
				$data_array['post_name'] = 'refund-'.$date_format;
				$data_array['guid'] = site_url() . '?shop_order_refund=' . 'refund-'.$date_format;
			}
		}
		if ($mode == 'Insert') {
			$retID = wp_insert_post( $data_array );

			update_post_meta($retID , '_refund_reason' , $post_excerpt);
			
			$update_array = array();
			$update_array['ID'] = $parent_order_id;
			$update_array['post_status'] = 'wc-refunded';
			$update_array['post_modified'] = date('Y-m-d H:i:s');
			$update_array['post_modified_gmt'] = date('Y-m-d H:i:s');
			wp_update_post($update_array);

			if(is_wp_error($retID) || $retID == '') {
				$core_instance->detailed_log[$line_number]['Message'] = "Can't insert this Refund. " . $retID->get_error_message();
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
				$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
				return array('MODE' => $mode, 'ERROR_MSG' => $retID->get_error_message());
			}
			$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Refund ID: ' . $retID;
			//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
			$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");

		}
		
		if ($mode == 'Update'){
			if($check == 'REFUNDID'){
				$refund_id = $data_array['REFUNDID'];
				$update_query = "select ID from $wpdb->posts where ID = '$refund_id' and post_type = 'shop_order_refund' order by ID DESC";
				$ID_result = $wpdb->get_results($update_query);
				if (is_array($ID_result) && !empty($ID_result)) {
					$retID = $ID_result[0]->ID;
					$data_array['ID'] = $retID;
					wp_update_post($data_array);

					update_post_meta($retID , '_refund_reason' , $post_excerpt);
					$mode_of_affect = 'Updated';

					$core_instance->detailed_log[$line_number]['Message'] = 'Updated Refund ID: ' . $retID;
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
					$fields = $wpdb->get_results("UPDATE $log_table_name SET updated = $updated_count WHERE hash_key = '$hash_key'");
					// $update_array = array();
					// $update_array['ID'] = $parent_order_id;
					// $update_array['post_status'] = 'wc-refunded';
					// $update_array['post_modified'] = date('Y-m-d H:i:s');
					// $update_array['post_modified_gmt'] = date('Y-m-d H:i:s');
					// wp_update_post($update_array);
				}else{
					$retID = wp_insert_post( $data_array );
					$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Refund ID: ' . $retID;
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
					$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
	
					update_post_meta($retID , '_refund_reason' , $post_excerpt);
					
					$update_array = array();
					$update_array['ID'] = $parent_order_id;
					$update_array['post_status'] = 'wc-refunded';
					$update_array['post_modified'] = date('Y-m-d H:i:s');
					$update_array['post_modified_gmt'] = date('Y-m-d H:i:s');
					wp_update_post($update_array);
	
					if(is_wp_error($retID) || $retID == '') {
						$core_instance->detailed_log[$line_number]['Message'] = "Can't insert this Refund. " . $retID->get_error_message();
						//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
						$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
						return array('MODE' => $mode, 'ERROR_MSG' => $retID->get_error_message());
					}
				}

			}else{
				$retID = wp_insert_post( $data_array );
				update_post_meta($retID , '_refund_reason' , $post_excerpt);
				
				$update_array = array();
				$update_array['ID'] = $parent_order_id;
				$update_array['post_status'] = 'wc-refunded';
				$update_array['post_modified'] = date('Y-m-d H:i:s');
				$update_array['post_modified_gmt'] = date('Y-m-d H:i:s');
				wp_update_post($update_array);

				if(is_wp_error($retID) || $retID == '') {
					$core_instance->detailed_log[$line_number]['Message'] = "Can't insert this Refund. " . $retID->get_error_message();
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
					$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
					return array('MODE' => $mode, 'ERROR_MSG' => $retID->get_error_message());
				}
				$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Refund ID: ' . $retID;
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $retID);	
				$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
			} 
		} 
		
		$returnArr['ID'] = $retID;
		$returnArr['MODE'] = $mode_of_affect;
		return $returnArr;
	}

	public function woocommerce_categories_import($data_array , $mode , $check , $hash_key , $line_number) {
		
		global $wpdb;
		$helpers_instance = ImportHelpers::getInstance();
		$core_instance = CoreFieldsImport::getInstance();
		$media_instance = MediaHandling::getInstance();
		global $core_instance;
		
		$returnArr = array();
		$slug = $data_array['slug'];
		$name = $data_array['name'];
		$description = $data_array['description'];
		$parent = $data_array['post_parent'];
		$display_type = $data_array['display_type'];
		$featured_image = $data_array['featured_image'];
		//$conditions = $duplicateHandling['conditions'];

		$log_table_name = $wpdb->prefix ."import_detail_log";
		$updated_row_counts = $helpers_instance->update_count($hash_key);
		$created_count = $updated_row_counts['created'];
		$updated_count = $updated_row_counts['updated'];
		$skipped_count = $updated_row_counts['skipped'];

		if($check == 'TERMID') {
			$term_id = $data_array['term_id'];	
			$termid = $wpdb->get_row("select term_id from wp_terms where term_id = '$term_id' ");
		}if($check == 'name') {
			$termid = $wpdb->get_row("select term_id from wp_terms where name = '".$name."'");
		}
		if($check == 'slug') {
			$termid = $wpdb->get_row("select term_id from wp_terms where slug = '".$slug."'");
		}

		if($mode == 'Insert') {

			if (is_array($termid) && !empty($termid)) {
				$core_instance->detailed_log[$line_number]['Message'] = 'Skipped Woocommerce Categories ';
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , '');	
				$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
				$returnArr['Mode'] = $mode;
				return $returnArr;
			}else{

				$wpdb->query("insert into wp_terms(name,slug)values('".$name."','".$slug."')");
				$id = $wpdb->insert_id;
				
				if(!empty($display_type)) {
					$wpdb->query("insert into wp_termmeta(term_id,meta_key,meta_value)values('".$id."','display_type','".$display_type."') ");
				}
				
				if(!empty($parent)) {
					$result=$wpdb->get_row("select term_id from wp_terms where name ='$parent' ");
					if(!empty($result)){
						foreach($result as $key=>$result_id ){
							$pid = $result_id;	
						}				
					}	
					$wpdb->query("insert into wp_term_taxonomy(term_taxonomy_id,term_id,taxonomy,description,parent) values ('".$id."','".$id."','product_cat','".$description."','".$pid."')");	
					
					$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Product Categories ID: '.$id;
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $id);	
					$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
				}
				else
				{
					$wpdb->query("insert into wp_term_taxonomy(term_taxonomy_id,term_id,taxonomy,description) values('".$id."','".$id."','product_cat','".$description."')");
					
					$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Product Categories ID: '.$id;
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $id);	
					$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
				}
				if(isset($data_array['featured_image']) && $mode == 'Insert') {
					$feature = trim($data_array['featured_image']);
					
					if ( preg_match_all( '/\b(?:(?:https?|ftp|file):\/\/|www\.|ftp\.)[-A-Z0-9+&@#\/%=~_|$?!:,.]*[A-Z0-9+&@#\/%=~_|$]/i',$feature, $matchedlist, PREG_PATTERN_ORDER ) ) {
						//$attachid = $uci_admin->set_featureimage( $feature, $id );
						$attachid = $media_instance->media_handling( $feature, $id );
						if($attachid != '') {
							update_term_meta($id,'thumbnail_id',$attachid);
						}
					}
				}
			}
		}
			
		if($mode == 'Update') {	
			if (is_array($termid) && !empty($termid)) {	
				foreach($termid as $term=>$value) {
					$id = $value;
				}
				$wpdb->query("update wp_terms set name='".$name."',slug='".$slug."' where term_id='".$id."'");
				if(!empty($parent)) {
					$result=$wpdb->get_row("select term_id from wp_terms where name=$parent");
					if(!empty($result)){
						$pid=$result->term_id;							
					}
					$wpdb->query("update wp_term_taxonomy set term_taxonomy_id ='".$id."',term_id='".$id."',taxonomy='product_cat',description='".$description."',parent='".$pid."' where term_id='".$id."'");
					
					$core_instance->detailed_log[$line_number]['Message'] = 'Updated Product Categories ID: '.$id;
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $id);	
					$fields = $wpdb->get_results("UPDATE $log_table_name SET updated = $updated_count WHERE hash_key = '$hash_key'");
				}
				else {
					$wpdb->query("update wp_term_taxonomy set term_taxonomy_id ='".$id."',term_id='".$id."',taxonomy='product_cat',description='".$description."' where term_id='".$id."'");
					
					$core_instance->detailed_log[$line_number]['Message'] = 'Updated Product Categories ID: '.$id;
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $id);	
					$fields = $wpdb->get_results("UPDATE $log_table_name SET updated = $updated_count WHERE hash_key = '$hash_key'");
				}

				if(isset($data_array['featured_image'])) {
					$feature = trim($data_array['featured_image']);
					if ( preg_match_all( '/\b(?:(?:https?|ftp|file):\/\/|www\.|ftp\.)[-A-Z0-9+&@#\/%=~_|$?!:,.]*[A-Z0-9+&@#\/%=~_|$]/i',$feature, $matchedlist, PREG_PATTERN_ORDER ) ) {
						//$attachid = $uci_admin->set_featureimage( $feature, $id );
						$attachid = $media_instance->media_handling( $feature, $id );
						if($attachid != '') {
							update_term_meta($id,'thumbnail_id',$attachid);
						}
					}
				}
			}else{
				$wpdb->query("insert into wp_terms(name,slug)values('".$name."','".$slug."')");
				$id = $wpdb->insert_id;
				
				if(!empty($display_type)) {
					$wpdb->query("insert into wp_termmeta(term_id,meta_key,meta_value)values('".$id."','display_type','".$display_type."') ");
				}
				
				if(!empty($parent)) {
					$result=$wpdb->get_row("select term_id from wp_terms where name ='$parent' ");
					if(!empty($result)){
						foreach($result as $key=>$result_id ){
							$pid = $result_id;	
						}				
					}	
					$wpdb->query("insert into wp_term_taxonomy(term_taxonomy_id,term_id,taxonomy,description,parent) values ('".$id."','".$id."','product_cat','".$description."','".$pid."')");	
					
					$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Product Categories ID: '.$id;
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $id);
					$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
				}
				else
				{
					$wpdb->query("insert into wp_term_taxonomy(term_taxonomy_id,term_id,taxonomy,description) values('".$id."','".$id."','product_cat','".$description."')");
					
					$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Product Categories ID: '.$id;
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $id);
					$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
				}
				if(isset($data_array['featured_image']) && $mode == 'Insert') {
					$feature = trim($data_array['featured_image']);
					if ( preg_match_all( '/\b(?:(?:https?|ftp|file):\/\/|www\.|ftp\.)[-A-Z0-9+&@#\/%=~_|$?!:,.]*[A-Z0-9+&@#\/%=~_|$]/i',$feature, $matchedlist, PREG_PATTERN_ORDER ) ) {
						//$attachid = $uci_admin->set_featureimage( $feature, $id );
						$attachid = $media_instance->media_handling( $feature, $id );
						if($attachid != '') {
							update_term_meta($id,'thumbnail_id',$attachid);
						}
					}
				}

			}
		}
		$returnArr['ID'] = $id;
		return $returnArr;
	}

	public function woocommerce_attributes_import($data_array , $mode , $check , $hash_key , $line_number) {

		global $wpdb;
		$helpers_instance = ImportHelpers::getInstance();
		$core_instance = CoreFieldsImport::getInstance();
		global $core_instance;
	
		$returnArr = array();
		$name = $data_array['name'];
		$slug = $data_array['slug'];
		$attr = $data_array['default_sort_order'];
			if($attr == 'Custom ordering'){
				$attr = 'menu_order';
			}
			if($attr == 'Name (numeric)'){
				$attr = 'name_num';
			}
			if($attr == 'Term ID'){
				$attr = 'id';
			}
			if($attr == 'Name'){
				$attr = 'name';
			}
		$attribute=$data_array['enable_archive'];
			//    $conditions=$duplicateHandling['conditions'];

		$log_table_name = $wpdb->prefix ."import_detail_log";

		$updated_row_counts = $helpers_instance->update_count($hash_key);
		$created_count = $updated_row_counts['created'];
		$updated_count = $updated_row_counts['updated'];
		$skipped_count = $updated_row_counts['skipped'];

		if($check == 'name') { 
			$result = $wpdb->get_row("select attribute_id from wp_woocommerce_attribute_taxonomies where attribute_label='".$name."'");
		}
		if($check == 'slug') {
			$result = $wpdb->get_row("select attribute_id from wp_woocommerce_attribute_taxonomies where attribute_name='".$slug."'");
		}
			
			
		if($mode == 'Insert') {

			if (is_array($result) && !empty($result)) {
				$core_instance->detailed_log[$line_number]['Message'] = 'Skipped Product attribute';
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , '');
				$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
				$returnArr['Mode'] = $mode;
				return $returnArr;
			}else{

				$wpdb->query("insert into wp_woocommerce_attribute_taxonomies(attribute_label,attribute_name,attribute_type,attribute_orderby,attribute_public) values('".$name."','".$slug."','select','".$attr."','".$attribute."')");
				$id = $wpdb->insert_id;

				$existing_attributes = array();
				$existing_attributes = get_option('_transient_wc_attribute_taxonomies', true);

				$at = array( 'attribute_id'=>$id,
						'attribute_label'=>$name,
						'attribute_name'=>$slug,
						'attribute_type'=>'select',
						'attribute_orderby'=>$attr,
						'attribute_public'=>$attribute
					);

				$at=(object)$at;
				array_push($existing_attributes,$at);
				update_option('_transient_wc_attribute_taxonomies',$existing_attributes);

				$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Product attribute ID: '.$id;
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $id);
				$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
			}
			
		}
		
		if($mode == 'Update') {
           
				if (is_array($result) && !empty($result)) {
					foreach($result as $res=>$value) {
						$id = $value;
					}

					$wpdb->query("update wp_woocommerce_attribute_taxonomies set attribute_label='".$name."',attribute_name='".$slug."',attribute_type='select',attribute_orderby='".$attr."',attribute_public='".$attribute."' where attribute_id='".$id."'");
					$wpdb->query("delete from ".$wpdb->prefix."options where option_name='_transient_wc_attribute_taxonomies'");

					$at = array( 'attribute_id'=>$id,
							'attribute_label'=>$name,
							'attribute_name'=>$slug,
							'attribute_type'=>'select',
							'attribute_orderby'=>$attr,
							'attribute_public'=>$attribute
						);
					$at=(object)$at;
					$a=array($at);
					update_option('_transient_wc_attribute_taxonomies',$a);

					$core_instance->detailed_log[$line_number]['Message'] = 'Updated Product attribute ID: '.$id;
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $id);
					$fields = $wpdb->get_results("UPDATE $log_table_name SET updated = $updated_count WHERE hash_key = '$hash_key'");
					
				} else{
					$wpdb->query("insert into wp_woocommerce_attribute_taxonomies(attribute_label,attribute_name,attribute_type,attribute_orderby,attribute_public) values('".$name."','".$slug."','select','".$attr."','".$attribute."')");
					$id = $wpdb->insert_id;

					$existing_attributes = array();
					$existing_attributes = get_option('_transient_wc_attribute_taxonomies', true);

					$at = array( 'attribute_id'=>$id,
							'attribute_label'=>$name,
							'attribute_name'=>$slug,
							'attribute_type'=>'select',
							'attribute_orderby'=>$attr,
							'attribute_public'=>$attribute
						);

					$at=(object)$at;
					array_push($existing_attributes,$at);
					update_option('_transient_wc_attribute_taxonomies',$existing_attributes);

					$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Product attribute ID: '.$id;
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $id);
					$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
				}                              
			//}                                
		}
		$returnArr['ID'] = $id;
		return $returnArr;
	}

	public function woocommerce_tags_import($data_array , $mode , $check , $hash_key , $line_number) {

		global $wpdb;
		$helpers_instance = ImportHelpers::getInstance();
		$core_instance = CoreFieldsImport::getInstance();
		global $core_instance;

		$returnArr = array();
		$name = $data_array['name']; 
		$description = $data_array['description'];
		$slug = $data_array['slug'];
		//$conditions = $duplicateHandling['conditions'];

		$log_table_name = $wpdb->prefix ."import_detail_log";

		$updated_row_counts = $helpers_instance->update_count($hash_key);
		$created_count = $updated_row_counts['created'];
		$updated_count = $updated_row_counts['updated'];
		$skipped_count = $updated_row_counts['skipped'];


		if ($check == 'TERMID') {
			$term_id = $data_array['TERMID'];
			$termid =$wpdb->get_row("select term_id from wp_terms where term_id = '$term_id' ");
		}
		if($check == 'slug') {
			$termid =$wpdb->get_row("select term_id from wp_terms where slug='".$slug."'");
		}


		if($mode == 'Insert') {
			if (is_array($termid) && !empty($termid)) {

				$core_instance->detailed_log[$line_number]['Message'] = 'Skipped Product tag';
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , '');
				$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
				$returnArr['Mode'] = $mode;
				return $returnArr;
				#skipped
			}else{
				$wpdb->query("insert into wp_terms(name,slug) values ('".$name."','".$slug."')");
				$id = $wpdb->insert_id;
				$wpdb->query("insert into wp_term_taxonomy(term_taxonomy_id,term_id,taxonomy,description) values('".$id."','".$id."','product_tag','".$description."')");
				
				$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Product tag ID: '.$id;
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $id);
				$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
			}
		}
		
		if($mode == 'Update'){
			if (is_array($termid) && !empty($termid)) {
				foreach($termid as $term =>$value) {
					$id = $value;
				}
				$wpdb->query("update wp_terms set name='".$name."',slug='".$slug."' where term_id='".$id."'");
				$wpdb->query("update wp_term_taxonomy set term_taxonomy_id='".$id."',term_id='".$id."',taxonomy='product_tag',description='".$description."' where term_id='".$id."'"); 
				
				$core_instance->detailed_log[$line_number]['Message'] = 'Updated Product tag ID: '.$id;
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $id);
				$fields = $wpdb->get_results("UPDATE $log_table_name SET updated = $updated_count WHERE hash_key = '$hash_key'");
			}else{

				$wpdb->query("insert into wp_terms(name,slug) values ('".$name."','".$slug."')");
				$id = $wpdb->insert_id;
				$wpdb->query("insert into wp_term_taxonomy(term_taxonomy_id,term_id,taxonomy,description) values('".$id."','".$id."','product_tag','".$description."')");
				
				$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Product tag ID: '.$id;
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $id);
				$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
			}
		}
		$returnArr['ID'] = $id;
		return $returnArr;
	}

	public function woocommerce_product_import($data_array, $mode , $check , $hash_key , $line_number) {

		$core_instance = CoreFieldsImport::getInstance();
		$helpers_instance = ImportHelpers::getInstance();
		global $wpdb; 
		global $core_instance;

		$log_table_name = $wpdb->prefix ."import_detail_log";
		$data_array['PRODUCTSKU'] = trim($data_array['PRODUCTSKU']);
		
		$returnArr = array();
		$assigned_author = '';
		$mode_of_affect = 'Inserted';
			
		// Assign post type
		$data_array['post_type'] = 'product';
		$data_array = $core_instance->import_core_fields($data_array);
		$post_type = $data_array['post_type'];

		if($check == 'ID'){	
			$ID = $data_array['ID'];	
			$get_result =  $wpdb->get_results("SELECT ID FROM $wpdb->posts WHERE ID = '$ID' AND post_type = '$post_type' AND post_status != 'trash' order by ID DESC ");			
		}
		if($check == 'post_title'){
			$title = $data_array['post_title'];
			$get_result =  $wpdb->get_results("SELECT ID FROM $wpdb->posts WHERE post_title = '$title' AND post_type = '$post_type' AND post_status != 'trash' order by ID DESC ");		
		}
		if($check == 'post_name'){
			$name = $data_array['post_name'];
			$get_result =  $wpdb->get_results("SELECT ID FROM $wpdb->posts WHERE post_name = '$name' AND post_type = '$post_type' AND post_status != 'trash' order by ID DESC ");	
		}
		if($check == 'PRODUCTSKU'){
			$sku = $data_array['PRODUCTSKU'];
			$get_result =  $wpdb->get_results("SELECT DISTINCT p.ID FROM $wpdb->posts p join $wpdb->postmeta pm ON p.ID = pm.post_id WHERE p.post_type = 'product' AND p.post_status != 'trash' and pm.meta_value = '$sku' ");
		}

		$updated_row_counts = $helpers_instance->update_count($hash_key);
		$created_count = $updated_row_counts['created'];
		$updated_count = $updated_row_counts['updated'];
		$skipped_count = $updated_row_counts['skipped'];

		if ($mode == 'Insert') {

			if (is_array($get_result) && !empty($get_result)) {
				#skipped
				$core_instance->detailed_log[$line_number]['Message'] = "Skipped, Due to duplicate Product found!.";
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , '');
				$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
				return array('MODE' => $mode);
			}else{
				
				$post_id = wp_insert_post($data_array); 
				//$core_instance->set_format($data_array , $post_id);
				set_post_format($post_id , $data_array['post_format']);	

				if(is_wp_error($post_id) || $post_id == '') {
					# skipped
					$core_instance->detailed_log[$line_number]['Message'] = "Can't insert this Product. " . $post_id->get_error_message();
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $post_id);
					$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
					return array('MODE' => $mode);
				}else {
					//WPML support on post types
					global $sitepress;
					if($sitepress != null) {
						$helpers_instance->UCI_WPML_Supported_Posts($data_array, $post_id);
					}
				}
				$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Product ID: ' . $post_id . ', ' . $assigned_author;
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $post_id);	
				$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");
			}	
		}	
		if($mode == 'Update'){

			if (is_array($get_result) && !empty($get_result)) {
				$post_id = $get_result[0]->ID;
				$data_array['ID'] = $post_id;
				wp_update_post($data_array);
				set_post_format($post_id , $data_array['post_format']);		
				//$core_instance->set_format($data_array , $post_id);
				$core_instance->detailed_log[$line_number]['Message'] = 'Updated Product ID: ' . $post_id . ', ' . $assigned_author;
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $post_id);
				$fields = $wpdb->get_results("UPDATE $log_table_name SET updated = $updated_count WHERE hash_key = '$hash_key'");

			}else{
				$post_id = wp_insert_post($data_array); 
				set_post_format($post_id , $data_array['post_format']);

				if(is_wp_error($post_id) || $post_id == '') {
					# skipped
					$core_instance->detailed_log[$line_number]['Message'] = "Can't insert this Product. " . $post_id->get_error_message();
					//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $post_id);
					$fields = $wpdb->get_results("UPDATE $log_table_name SET skipped = $skipped_count WHERE hash_key = '$hash_key'");
					return array('MODE' => $mode);
				}
				$core_instance->detailed_log[$line_number]['Message'] = 'Inserted Product ID: ' . $post_id . ', ' . $assigned_author;
				//$helpers_instance->update_error_log($core_instance->detailed_log[$line_number]['Message'] , $hash_key , $post_id);
				$fields = $wpdb->get_results("UPDATE $log_table_name SET created = $created_count WHERE hash_key = '$hash_key'");	
			}
		}

		if(isset($data_array['featured_image'])) {
			$feature = trim($data_array['featured_image']);
			if ( preg_match_all( '/\b(?:(?:https?|ftp|file):\/\/|www\.|ftp\.)[-A-Z0-9+&@#\/%=~_|$?!:,.]*[A-Z0-9+&@#\/%=~_|$]/i',$feature, $matchedlist, PREG_PATTERN_ORDER ) ) {
				$attachid = WooCommerceCoreImport::$media_instance->media_handling($feature, $post_id,$data_array);		
			}
		}
		$returnArr['ID'] = $post_id;
		$returnArr['MODE'] = $mode_of_affect;
		if (!empty($data_array['post_author'])) {
			$returnArr['AUTHOR'] = isset($assigned_author) ? $assigned_author : '';
		}
		return $returnArr;
	}

}